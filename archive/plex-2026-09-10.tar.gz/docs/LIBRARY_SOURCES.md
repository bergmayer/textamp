# Library sources

## Implemented boundaries

```
UI: renders AppState; F3 and Settings use the same typed library choices
  App core
    sources.rs: source selection, saved account activation, library manager
    sources/manager.rs: startup directory, refresh ownership, manager sections
    sources/files.rs: generation-bound directory/media effects
    sources/navidrome/: cache-first catalog, scoped stations, DJ and remix effects
    existing queue and playback services
  Library data/access
    library/track.rs: playback metadata and explicit track origin
    library/cache.rs: scoped private metadata snapshots, bounded disk use and ordered writes
    library/{local,webdav}.rs: list a directory, prepare a file
    plex/: existing catalog, discovery, radio, recommendations and reporting
    plex/library_directory.rs: credential-free account/server/library directory
  Audio: existing decoder/player, accepting bytes or an owned file
    plex/analysis.rs: provider-independent, bounded waveform/spectral summaries
```

Folder providers do not import Plex, UI, or audio. They do not fabricate Plex
API responses. Shared Track/Media/MediaPart definitions moved out of the Plex
models; the old exports and serialized Plex fields remain compatible. Track
origin is explicit, defaults to Plex for existing caches, and includes the stable
folder source ID and relative path for files. Two sources containing identically
named files cannot collide.

Switching sources stops playback and clears the old queue, preserving the
existing Plex library-switching convention. It invalidates library/connection
generations and releases owned folder/media tasks. Completion events additionally
check their operation ID and track or navigation identity. Authentication and
queue-load results are also generation-scoped. Folder tracks do not participate
in Plex scrobbling, timeline reports, stream URL resolution, or prefetch.

MediaFile owns the remote spool through its last decoder/analysis consumer.
Seeking reopens the same file; there is no separate folder-player implementation.
Native file access uses the same audio actor and failure mailbox as existing
buffered playback. Remote transfers are bounded and cancellable. An OS-level
filesystem operation already in progress cannot be forcibly cancelled.

Settings → Libraries has Libraries, Accounts, and Add library sections. Each
section's typed list is shared by rendering, keyboard input and mouse hit testing,
including scrolling. It works before Plex authentication or a Navidrome catalog
import. Startup restores the last selected library in the normal app interface;
F3 opens a compact switch-only popup, with F2 leading to library settings. Folder names,
paths, and credentials are separate: renaming does not change identity; passwords
are private stored secrets or environment overrides, never URL components.

Saved Plex profiles use the Plex user ID when available. The legacy auth.toml
remains the active profile, while accounts/ retains independently selectable
credentials. The private `plex-libraries.json` directory retains library names
and account/server/section identities, not tokens or music catalogs. Discovery
reads saved profiles without activating them, probes up to three servers at a
time per account, and bounds each server operation to 25 seconds. Failed servers
keep their saved entries, with an inline availability warning. F5 retries discovery.
Selecting an entry activates its account and preserves the exact target server
and section across authentication. Account switching retains cache-ownership checks and
may discard/reload Plex caches when accounts change. It is not a combined offline
catalog of every account. Library view preferences now use account/server/library
keys; old unscoped settings remain read-only defaults.

Directory refreshes are independent of playback generations. Their own request
ID rejects superseded completions and orders disk writes with account removal.
Arriving results preserve the highlighted source identity. The task session owns
discovery through shutdown; the manager never starts a full music scan.

Local and WebDAV remain plain folder libraries. They list only visited
directories and download/read audio on demand, without recursive catalog scans.
Visited listings now persist across launches; root listings refresh after 72 hours,
remote subfolders after 32 days, and local listings revalidate on every visit.
Navidrome saves its complete catalog and supported extensions per account/server/
selected library; saved-account startup reads it before making server requests.
Fresh catalogs need no server handshake, stale catalogs refresh in the background,
and F5 always requests new data. Failed requests retain prior memory/disk data.
Settings → Cache reports source-specific bytes and clears both Plex and non-Plex
metadata caches without passing non-Plex identities to Plex. New-account sign-in
still verifies credentials with the server. Cached metadata does not provide offline
audio playback. No sidebar playlist presentation changes are part of this cache work.

### September 6 source-cache verification

303 tests passed, five opt-in tests ignored; strict all-target Clippy, formatting,
and diff checks passed. Tests cover local/WebDAV/SFTP cached startup with inaccessible
sources, local background revalidation, explicit root refresh, empty-result replacement,
Navidrome offline cached catalogs and genres, failed-refresh retention, account/server/
username/library isolation, stale-write and clear ordering, corrupt/oversized files,
private permissions, and provider-independent Settings cache controls.

One overlapping lint/test run invalidated a documentation-test build artifact;
the complete sequential rerun passed all eight doctests. No native playback,
Music-app automation, or live Plex/Navidrome/WebDAV/SFTP server tests were run for
this correction. Network behavior was exercised using loopback fixtures; SFTP
coverage here verifies cached browsing, not a live SSH connection. Playlist sidebar
behavior is unchanged; the user is correcting unwanted playlists on Navidrome.

Warning-free release installed atomically at `~/Applications/textamp`, without an
old-build backup. Installed and build SHA-256 match:
`d355ab6c8382187c052fb52a3524efec124acecb5fb7e1bbedfaef7800dc93fc`.

### September 6 interface correction

Normal startup again restores the last selected folder/Navidrome source, or the
existing Plex authentication/startup path. It no longer opens the library manager.
F3 is a compact switch-only popup with Enter to open, Esc to cancel, and F2 to
manage. Management is embedded directly in Settings → Libraries. Saved accounts
and discovery stay independent of the active playback source.

State/render tests cover startup selection, Settings versus switcher routing,
cancel preserving player state, selecting the active library without reloading,
modal hit regions, and layouts at 140×42, 80×24, and 40×12. The full test suite,
strict all-target Clippy and formatting checks passed. Native playback, Music-app
automation and live PTY smoke tests were deliberately not run for this correction;
the opt-in scripts were updated and syntax-checked only.

Verification: 297 tests passed, five opt-in tests ignored, zero failures; release
build completed with zero warnings. The installed `~/Applications/textamp` and
release binary have identical SHA-256
`dac78871197b7d70eb8f6f46efa3f0217d560005b2bc6459b2757af9f7eb9b98`.
Installation replaced the executable atomically without keeping an old build.

### September 6 initial library-manager verification (superseded UI)

The previous startup path skipped Plex discovery whenever a folder or Navidrome
was the default, and source switching cleared the only Plex library list. Startup
initially showed the manager before connecting a playback source, with a separate
saved directory. That startup presentation was subsequently removed at the user's
request; the independent directory remains. Setup commands and accounts no longer
share the playable library list.

The release passed the full test suite, strict all-target Clippy, formatting and
diff checks. Focused coverage includes mixed-provider startup, independent account
activation with an exact pending server/library, stale discovery/save rejection,
retained selections, modal shortcuts, and rendering/mouse hit testing at 140×42,
80×24 and 40×12. Existing visualizer rollback patches remain applicable.

Live read-only discovery found `beatles`, `music` and `spoken` on `understander`;
the server named `you` was unavailable. A private-copy PTY test verified these
Plex entries alongside Beatles WebDAV and Navidrome, all manager sections,
opening the WebDAV folder, and retaining the directory after source switching.
Release PTY tests also covered local-folder and isolated Navidrome playback,
navigation, credentials setup and terminal restoration. No personal music catalog
was scanned; AudioMuse jobs were untouched. Native MusicBee parsing is not part
of this change; a real library/export and path mapping are needed to validate it.

The warning-free release was installed atomically at `~/Applications/textamp`,
without retaining an old executable. Installed/build SHA-256:
`a80d790521b1a57be289beba2c5cc50c3964d1af5fb3e6911f6cc30a87d48fe0`.

## Free metadata, implemented and future

Implemented without an external service: embedded artist/album/title tags,
declared duration and embedded cover art. Custom biography sidecars were removed.
Folder ordering does not depend on tags. Waveforms, spectrograms, and live PCM
visualizers remain local computations, not Plex Sonic Analysis.

Biographies now prefer the current provider and use an on-demand Wikipedia
fallback. `services/biography.rs` has no Plex or UI dependency; the app's biography
effect owns provider selection and a popup-scoped cancellation lease. Results
carry library generation and request identity. Closing/changing the popup cancels
the work, and stale results cannot overwrite another artist.

Wikidata search supplies up to 20 candidates. Exact English/multilingual labels
or aliases must match (case/whitespace normalized, punctuation retained), with a
nondeprecated MusicBrainz artist ID or a conservative musical type/occupation.
More than one qualifying English-Wikipedia identity is treated as ambiguous,
not ranked by popularity. The article's `wikibase_item` must match the chosen
entity; disambiguation pages are rejected. This deliberately favors false
negatives over irrelevant biographies and cannot prove every database assertion.

The [MediaWiki parse API](https://www.mediawiki.org/wiki/API:Parsing_wikitext)
provides article HTML. An HTML5 parser retains prose, headings and lists, removes
navigation/reference/table markup, and extracts up to eight article photos.
[Imageinfo](https://www.mediawiki.org/wiki/API:Imageinfo) supplies thumbnails and
attribution. Downloads are bounded and restricted to HTTPS Wikimedia upload URLs;
redirects are disabled. Article revision, CC BY-SA attribution, author/image
license credits and source links remain visible. Images use the existing TUI
artwork renderer and left/right navigation, not an embedded web browser.

No background enrichment or filename-derived artist guesses are performed.
Explicit F4 lookup discloses the artist name to Wikimedia, with no credentials
or private paths. HTTP operations, response sizes, article length, image count
and overall time are bounded; unavailable images do not invalidate loaded text.

## Integration direction

- **Navidrome (implemented):** catalog/playback source using
  [its OpenSubsonic-compatible API](https://www.navidrome.org/docs/developers/subsonic-api/).
  Tracks have a Navidrome origin and source identity; provider adapters handle
  catalog loading and media preparation. Do not subclass or emulate Plex endpoints.
  Its standard `getArtistInfo2` response can supply biographies/images before
  considering Wikipedia. [Navidrome's metadata agents](https://www.navidrome.org/docs/usage/integration/external-services/)
  already enrich artists through configured external services; Textamp should
  consume that result rather than duplicate the server's enrichment.
- **AudioMuse-AI:** sonic matches and paths now use Navidrome's advertised
  OpenSubsonic extension, without direct AudioMuse credentials or scan control.
  A future standalone-folder integration would need a separate service keyed
  by stable track identity. Its [documented analysis pipeline](https://github.com/NeptuneHub/AudioMuse-AI/blob/main/docs/ALGORITHM.md)
  provides a potential embedding/similarity route. Analysis availability should
  not determine whether a library can be browsed or played. Server mappings,
  model compatibility, licensing and analysis job progress belong to that later
  implementation, not placeholder traits in the current player.

There is no universal “supports all Plex operations” backend trait. The current
folder contract is intentionally only listing and file access; adding catalog or
analysis capabilities later should be driven by those real APIs.

## Verification

### September 6: radio, cache size and visualizer follow-up

Metadata-based station selection now lives in `services::radio`: typed recipes
operate on the caller's catalog and exclusions without network requests or app
state. Navidrome supplies catalog data and native similarity/path requests;
existing Plex radio requests are unchanged. Folder sources retain on-demand
listing rather than acquiring an implicit full-library scan. A shared selector
test accepts folder tracks without server IDs; this does not imply that folders
already have an artist/genre/sonic index.

Navidrome stations, all six DJ modes and four remixes use the existing radio and
queue reducers. Tests cover album disc/track order, repeat exclusions, metadata
requirements, time-travel progression, scoped sonic candidates, remix undo, and
rejection of stale playback/queue results. Missing analysis is an explicit failure,
not an unrelated random recommendation. The read-only live Navidrome check passed
authentication, catalog, album/artist details, structured genres, search, playlists
and artwork. The server advertises `sonicSimilarity` but the attempted sonic
request returned API error 0 while analysis was unfinished. Successful live sonic
recommendations cannot yet be certified. No scans or server settings were changed.

The old 256 MiB serialized-cache ceiling and whole-track decoded-PCM ceiling were
both real defects for large collections/recordings. Cache snapshots now stream
through gzip, preserving atomic writes, private permissions, revision guards and
legacy reads. A fixture writes and reads more than 256 MiB of expanded JSON.
Waveform/spectrogram generation retains packet scratch space and bounded time
summaries, tested beyond the old decoded-sample ceiling and against the existing
FFT output. Source fixtures cover Navidrome HTTP media and prepared local,
WebDAV and SFTP files; all six visualizers render identically for matching input
across source types. These tests do not certify live remote-file playback or audio
hardware. Native Music automation and playback smoke tests were not invoked in
this follow-up.

The redundant Account settings section and its duplicate credential form/state
were removed. Libraries retains account management and confirmed Plex sign-out;
Cache retains cache clearing/crawling controls. F2/F3 and the main browse layout
remain intact. Settings rendering and section navigation have regression tests.

Each Plex/Navidrome library now has an independent Sonic features checkbox in
Settings (click or I). Config stores source/account/server/library-scoped opt-outs;
missing entries preserve the previous enabled behavior. One policy gates palette
and context entries, station models, the track-details pane and action dispatch.
The browse-loop lazy lookup also checks it, avoiding a suppressed request that
would otherwise starve unrelated background work. Turning it off cancels owned
multi-request sonic jobs and invalidates pending results while retaining current
music. Tests cover persistence round trips, account/server/library isolation,
keyboard/mouse routing, hidden entries, no request/task creation, and cancellation.
Folder sources never show the checkbox or sonic commands. Enabling is permission
to attempt the feature, not a claim that a server has finished analysis.

Final test run: 317 unit/integration tests and 8 doctests passed, plus the account
store's isolated subprocess check (326 passing results when summing the log).
Five opt-in live/native tests were skipped. The six sonic-preference regressions
were also rerun after using the shared radio-to-queue conversion for disabled
sonic snapshots. Formatting, strict all-target Clippy and `git diff --check` passed.
The optimized `cargo build --release --bin textamp` finished without warnings.
It replaced `/Users/bergmayer/Applications/textamp` atomically, without an old-build
backup; installed and built SHA-256 both equal
`955830793afab468bbd5aed15149019f820de38baa9d3b4467c5ee42415cb881`.
The installed executable was not launched, so existing playback was not interrupted.

Using the same Lizard 1.24.0 Rust lexical measurement, the old whole-PCM decoder
measured CCN 16 and the packet decoder measures 13. New bounded-analysis methods
measure at most 6. During this follow-up, Navidrome's combined station chooser
measured 24 before separating reusable selection; its adapter now measures 16
and the shared selector 7. This last split relocates decisions to a reusable,
testable boundary; it is not a claim of eliminating their combined complexity.
Lizard does not measure memory usage, async races, macro-expanded branches or
overall behavioral equivalence.

### Earlier implementation verification

The folder-source implementation passed 256 unit/integration tests and 8 doctests,
plus the separately enabled SFTP fixture. The biography follow-up raises this to
266 unit/integration tests and 8 doctests, with explicit live Wikimedia coverage
for Tool (band), including article text and photos. The ordinary suite skips live
Wikimedia, the SFTP fixture and the existing native Music search test.
Formatting, strict all-target Clippy,
and the release binary build passed with no warnings. Silent native file and
HTTP playback checks passed, including pause, seeking, completion and stop.
The final release passed folder-only and Plex-login terminal startup/shutdown
checks, including terminal restoration on Ctrl+C/SIGTERM. Its dynamic dependencies
are macOS system libraries; SFTP's OpenSSL is vendored.

Automated coverage includes filename ordering, traversal/symlink boundaries,
WebDAV encoding, namespaces and rejected responses, remote spool ownership,
stale directory/media results, navigation cancellation, cancelled credential
dialogs, mixed folder/file playback indexes, source IDs,
manager availability without Plex, and isolated account/credential persistence.
The former opt-in SFTP fixture exercised SSH/SFTP handshakes and file access;
that provider and fixture have since been removed (see below).

Useful commands:

```sh
cargo test
cargo test live_tool_resolves_band_with_article_and_images -- --ignored --nocapture
cargo clippy --all-targets -- -D warnings
cargo fmt --all --check
cargo build --release --bin textamp
cargo run --example audio_smoke -- --file
python3 tests/fixtures/folder_tui_smoke.py target/release/textamp
# Opt-in live Wikipedia + standard RIFF artist tag + photo navigation:
python3 tests/fixtures/folder_tui_smoke.py target/release/textamp --wikipedia
```

The terminal smoke uses isolated XDG directories and silent audio. It checks
rendered text and input paths, not a full pixel/screenshot review. Native tests
exercise macOS CoreAudio; other operating systems and personal remote servers
need their own environment checks. Multiple real Plex account logins have not
been exercised; account-switch storage and isolation are covered with fixtures.

Lizard 1.24.0 measures syntactic cyclomatic complexity, not file size, nesting,
async correctness, macro expansion, or end-to-end behavior. During implementation
the initial combined source dispatcher measured CCN 61; it was separated by
ownership into manager and file-effect dispatchers (initial CCN 35 and 32, including
additional cancellation and credential validation). This partitions
decisions, **not an elimination of those decisions**, and is not presented as a
net complexity reduction. The WebDAV response parser measures CCN 21; its real
external-boundary checks are retained. These are new feature measurements, not
a fresh before/after measurement of the earlier whole-application review.

Removing the custom biography sidecar path lowered the file-effect dispatcher
from CCN 32 to 23 and eliminated its biography actions, task field, text-file API,
and separate popup-loading path. The provider-first biography loader is CCN 7;
the new HTML article converter is CCN 17. Wikipedia necessarily adds network and
parsing logic; this is not a claim that the application as a whole became smaller.

### September 6 settings navigation and source cleanup

SFTP support, its SSH transport/dependency and dedicated fixture were removed.
WebDAV is the only remote-file provider; local folders, Plex and Navidrome remain.
Old SFTP configuration entries are removed before typed parsing so they cannot
invalidate unrelated settings. No remote music or SSH files are touched.

Tab and Shift+Tab now alternate the Settings sidebar and content in every section.
Arrows follow sidebar ↔ Libraries ↔ Accounts ↔ Add library without wrapping.
Up/down selects rows. The previous
library-specific handler intercepted pane-navigation keys and trapped focus.
The current library now has a leading `[Active]` badge and a persistent header,
independent of the highlighted row. Help and the settings/transport hints match.

Navidrome accounts with one music folder show only that named library, not a
duplicate All music aggregate. Existing aggregate selections and Sonic opt-outs
migrate to the single-folder identity. Legacy caches are reused only when their
saved directory confirms the same sole folder; migration preserves timestamps.
Accounts with multiple music folders still offer their aggregate and individual
folders. Source/account IDs and all music files remain unchanged.

Regression tests cover sidebar/content traversal across every settings section,
active versus highlighted rows at 40/80/140 columns, single/multi-folder choices,
cache identity and age preservation, and preference/configuration migration.
The full suite passed (332 results including doctests and the isolated child
fixture; four opt-in live-service/native-audio tests skipped). Strict all-target
Clippy passed. Playback behavior was not changed or manually exercised here.

The warning-free release passed the PTY manager smoke using private temporary
configuration copies: mixed Plex/WebDAV/Navidrome visibility, Tab/Shift+Tab pane
navigation, library-tab navigation, opening the real Beatles WebDAV listing,
and clean SIGTERM shutdown with terminal restoration. No audio was played and
no server data was changed. The fixture now requires Python 3.12 explicitly and
creates a visible local directory row rather than expecting the source name in
the normal browse header. Formatting and diff checks passed.

Installed atomically at `~/Applications/textamp`, without an old-build backup.
Installed and build SHA-256 match:
`a0396e98afd2c1514517fffa5d9f3b0113356a23a2946ce0d321d51ed6f5895d`.

Earlier arrow-key follow-up (superseded below): Left exited every library/account tab directly to the
Settings sidebar; Right re-enters the selected tab or cycles tabs from content.
All 18 focused manager/Sonic tests passed, along with strict all-target Clippy,
formatting, and the warning-free release build. The PTY smoke verified the
Accounts → sidebar → Textamp → Accounts round trip using only arrows, without
playing audio. Installed without a backup; build and installed SHA-256:
`0de33b7af232701a962f066503b6a2b34230b630a9c7ebba5d9d13c2a50e695c`.

### Spatial navigation correction

The direct-exit Left key and cycling Right key were asymmetric: from Add library,
Left skipped Accounts and Libraries instead of moving to the neighboring tab.
The navigation now follows the visible order in both directions without wrapping:
sidebar ↔ Libraries ↔ Accounts ↔ Add library. Left from Libraries reaches the
sidebar; Right from Add stays put. Tab/Shift+Tab remain direct pane shortcuts.
Horizontal settings navigation has one handler, and the tab order supplies both
keyboard destinations and contextual footer hints. No additional focus state was
introduced. The sidebar cursor and tab highlighting distinguish keyboard focus
from a remembered selection. Setup pages no longer advertise rename/delete
shortcuts, and local folders no longer advertise nonexistent credentials.

Regression coverage exercises the entire forward/reverse path, both end stops,
sidebar section navigation, direct pane shortcuts, rendered focus and neighbor
hints, plus the Add → Accounts → Libraries path in the release PTY smoke.

Verification: 334 test results passed (including doctests and the isolated child
fixture), four opt-in tests skipped; strict all-target Clippy, formatting, diff
checks, and the warning-free release build passed. The PTY smoke passed the
reverse tab path, sidebar navigation, real WebDAV listing and clean terminal
restoration without playing audio. Installed atomically without a build backup;
build and installed SHA-256:
`f71f19b5a37c2657697337aa4e8bc3e36b714d3cdeb92f0f96f21cff8b59f3e4`.

### Account buttons and checked WebDAV forms

Accounts is now a saved-sign-in management list, not another route for opening
music. Enter opens Sign out / Cancel buttons with Cancel selected initially;
keyboard and mouse use the same action. Plex sign-out removes only the selected
profile and its active token, when applicable. Navidrome uses its existing scoped
account removal. Neither operation deletes music or other accounts. Add library
names the providers rather than duplicating a “connect accounts” section.

WebDAV uses one editable URL/username/masked-password/name form. Its draft is not
configuration: a bounded, read-only PROPFIND must succeed before saving private
credentials and adding the source. Failures remain inline with entries intact.
Closing the form drops its task lease; instance IDs reject late results after
cancel/reopen. A blank edit password retains the existing private/environment
credential; clearing the username selects anonymous access. Editing the active
endpoint resets its old playback/browse work before reopening it. The cache key
already includes the endpoint, so old listings cannot migrate to another server.
The obsolete sequential WebDAV naming/username/password effect paths were removed.

The reported “record overflow” was reproduced as an HTTPS connection to a
plain-HTTP port: `beatles archive` had `https://understander:8081/`, whereas the
existing Beatles entry used `http://understander:8081/`. The archive URL was
corrected to the user's supplied HTTP address. Generic connection errors now
explain scheme/port checks; there is no automatic HTTPS downgrade. Authentication,
permission and missing-folder errors retain HTTP status and useful context.

Regression coverage includes account cancellation without switching/playback,
scoped active/inactive Plex sign-out in private fixtures, one-screen form rendering,
secret masking, Unicode editing, mouse buttons, rejected/stale results, actual
request cancellation, HTTP authentication/TLS mismatch fixtures, verified saves
and credential-store failure without false success.

Verification: the full suite reported 345 passing results (including isolated
child fixtures), zero failures and four opt-in tests skipped. The final focused
account/dialog tests, strict all-target Clippy, formatting and diff checks passed.
The release build succeeded with zero warnings. The release PTY smoke verified
the account Cancel buttons, combined WebDAV form, spatial settings navigation,
both live Beatles and corrected beatles archive listings, and clean terminal
restoration. No audio was played, no live accounts were signed out, and no server
data was modified. Actual sign-out and credential writes were tested only with
isolated fixtures.

Installed atomically at `~/Applications/textamp` without a build backup. Build
and installed SHA-256 match:
`f222929b6845bc920a4c07ba4a688b7014a5d96e0cb502b598c960884bde1bfd`.
