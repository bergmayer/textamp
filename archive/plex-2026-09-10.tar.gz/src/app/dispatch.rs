//! Shared action dispatch.
//!
//! The TUI routes actions through `dispatch_action`: one implementation
//! owns action ordering and follow-up dispatch.
//!
//! Handlers live in `crate::app::handlers::dispatch_*`; this file is just
//! the router. The source boundary consumes provider requests before shared dispatch;
//! `sources::routing` rejects an unhandled request instead of falling through
//! to a Plex effect. Shared reducers and explicit account management
//! remain independent of the active provider.

use anyhow::Result;
use tokio::sync::mpsc;

use crate::app::action::SystemAction;
use crate::app::event::{AuthEvent, Event};
use crate::app::handlers;
use crate::app::handlers::helpers;
use crate::app::Action;
use crate::app::AppState;
use crate::audio::AudioPlayer;
use crate::config::Config;
use crate::plex::{PlexAuth, PlexClient};

/// Dispatch an `Action` and all of its follow-up actions.
///
/// Returns when every Action (and any it spawns synchronously) has been
/// routed. Long-running I/O is handled by each dispatch module spawning
/// its own tokio tasks that emit results back on `event_tx`.
pub async fn dispatch_action(
    action: Action,
    state: &mut AppState,
    client: &mut PlexClient,
    audio: &mut AudioPlayer,
    config: &mut Config,
    event_tx: &mpsc::Sender<Event>,
) -> Result<()> {
    let mut pending: Vec<Action> = vec![action];

    while let Some(next) = pending.pop() {
        if crate::app::sources::sonic::action_blocked(state, &next) {
            continue;
        }
        let provider_actions = crate::app::sources::route(&next, state, client, audio, event_tx);
        if let Some(actions) = provider_actions {
            pending.extend(actions.into_iter().rev());
            continue;
        }
        let follow_ups = match next {
            Action::Source(a) => {
                crate::app::sources::dispatch(a, state, client, audio, config, event_tx).await?
            }
            Action::System(a) => {
                handlers::dispatch_system::dispatch(event_tx, config, a, state, client).await?
            }
            Action::Navigation(a) => {
                handlers::dispatch_navigation::dispatch(event_tx, a, state, client).await?
            }
            Action::Data(a) => {
                handlers::dispatch_data::dispatch(event_tx, config, a, state, client).await?
            }
            Action::Miller(a) => {
                handlers::dispatch_miller::dispatch(event_tx, a, state, client, audio).await?
            }
            Action::Playback(a) => {
                handlers::dispatch_playback::dispatch(event_tx, a, state, client, audio).await?
            }
            Action::Queue(a) => {
                handlers::dispatch_queue::dispatch(event_tx, a, state, client, audio).await?
            }
            Action::Search(a) => {
                handlers::dispatch_search::dispatch(event_tx, a, state, client).await?
            }
            Action::Browse(a) => {
                handlers::dispatch_browse::dispatch(event_tx, a, state, client).await?
            }
            Action::Folders(a) => {
                handlers::dispatch_folders::dispatch(event_tx, a, state, client, audio).await?
            }
            Action::Radio(a) => {
                handlers::dispatch_radio::dispatch(event_tx, a, state, client, audio).await?
            }
            Action::Settings(a) => {
                handlers::dispatch_settings::dispatch(event_tx, config, a, state, client, audio)
                    .await?
            }
        };

        // Depth-first, in returned order, matching recursive dispatch without
        // allocating a boxed future for every follow-up.
        for f in follow_ups.into_iter().rev() {
            pending.push(f);
        }
    }

    crate::app::sources::sonic::reconcile(state);
    Ok(())
}

/// Translate a core event into zero or more `Action`s without dispatching.
///
/// This is the complement to `dispatch_action`. The TUI handles terminal
/// input separately and passes asynchronous results through this reducer.
pub fn handle_core_event(
    event: Event,
    state: &mut AppState,
    client: &mut PlexClient,
    event_tx: &mpsc::Sender<Event>,
) -> Vec<Action> {
    let mut actions = match event {
        Event::RadioResult {
            generation,
            navigation_generation,
            event,
        } => {
            if navigation_generation.map_or(generation == state.radio_generation, |id| {
                id == state.station_navigation_generation
            }) {
                handle_core_event(*event, state, client, event_tx)
            } else {
                vec![]
            }
        }
        Event::CategoryResult {
            generation,
            category,
            request_id,
            result,
        } => {
            if generation != state.library_generation
                || state
                    .cache_mgmt
                    .requests
                    .get(&category)
                    .is_none_or(|(id, _)| *id != request_id)
            {
                return vec![];
            }
            state.cache_mgmt.requests.remove(&category);
            let explicit = state.cache_mgmt.explicit_refreshes.remove(&category);
            match category {
                crate::app::state::RefreshCategory::Artists => {
                    state.library.artists_loading = false
                }
                crate::app::state::RefreshCategory::Playlists => {
                    state.library.playlists_loading = false
                }
                _ => {}
            }
            state.cache_mgmt.background_refresh.remove(&category);
            let label = category.progress_label();
            state.cache_mgmt.preloads_in_progress.remove(label);
            if state.cache_mgmt.preloads_in_progress.is_empty() {
                state.cache_mgmt.preloads_total = 0;
            }
            match result {
                Ok(event) => {
                    state.cache_mgmt.failures.remove(&category);
                    state
                        .cache_mgmt
                        .category_timestamps
                        .insert(category, crate::plex::CacheData::now());
                    state.cache_mgmt.dirty = true;
                    state.clear_status();
                    handle_core_event(*event, state, client, event_tx)
                }
                Err(failure) => {
                    let error = failure.error;
                    let attempts = state
                        .cache_mgmt
                        .failures
                        .get(&category)
                        .map_or(1, |failure| failure.attempts + 1);
                    let delay = if failure.retryable {
                        [30, 120].get(attempts - 1).copied()
                    } else {
                        None
                    };
                    state.cache_mgmt.failures.insert(
                        category,
                        crate::app::state::RefreshFailure {
                            attempts,
                            retry_at: delay.map(|secs| {
                                std::time::Instant::now() + std::time::Duration::from_secs(secs)
                            }),
                        },
                    );
                    if error.connection_error {
                        state.connection.mark_degraded(error.message.clone());
                    }
                    let retry = delay.map_or(
                        "Automatic retries stopped; F5 retries the current section.".to_string(),
                        |secs| format!("Retrying in {secs}s."),
                    );
                    tracing::warn!("{} {}", error.message, retry);
                    if explicit {
                        state.set_error(format!("{} {}", error.message, retry));
                    } else {
                        let name = category.display_name();
                        state.set_status(match delay {
                            Some(secs) => format!("{name} refresh failed · retry in {secs}s"),
                            None => format!("{name} refresh failed · F5 to retry"),
                        });
                    }
                    vec![]
                }
            }
        }
        Event::LibraryResult { generation, event } => {
            if generation == state.library_generation {
                handle_core_event(*event, state, client, event_tx)
            } else {
                vec![]
            }
        }
        Event::ConnectionResult { generation, event } => {
            if generation == state.connection_generation {
                handle_core_event(*event, state, client, event_tx)
            } else {
                vec![]
            }
        }
        event => handlers::events::handle_app_event(event, state, client, event_tx),
    };
    crate::app::sources::sonic::reconcile(state);
    if !state.sources.active.is_plex() {
        return actions;
    }
    handlers::helpers::pump_category_loads(event_tx, state, client);
    if state.connection_recovery_due()
        && !actions
            .iter()
            .any(|action| matches!(action, Action::System(SystemAction::RecoverConnection)))
    {
        actions.push(SystemAction::RecoverConnection.into());
    }
    actions
}

/// Kick off the shared authentication flow.
///
/// Authentication emits events for the main reducer:
///  - Fast path: stored token + server_url + username → immediate
///    `AuthSuccess`. The generation-scoped validation task is launched by the
///    reducer after it has installed that account context.
///  - Slow path: verify the stored token with plex.tv, discover servers,
///    pick a working connection, emit `AuthSuccess`.
///  - Nothing stored / token invalid: emit `AuthShowLogin`.
pub fn spawn_auth_task(
    event_tx: mpsc::Sender<Event>,
    connection_urls: Vec<String>,
    generation: u64,
) {
    let event_tx = ScopedAuthSender {
        sender: event_tx,
        generation,
    };
    crate::app::tasks::spawn(async move {
        let stored = match crate::app::tasks::spawn_blocking(PlexAuth::load_token).await {
            Ok(stored) => stored,
            Err(error) => {
                tracing::error!("Stored-auth worker failed: {}", error);
                None
            }
        };
        if let Some(stored) = stored {
            tracing::info!(
                "Loaded stored auth: client_identifier={}, server_url={:?}",
                stored.client_identifier,
                stored.server_url
            );

            // Fast path
            if let (Some(ref server_url), Some(ref username)) =
                (&stored.server_url, &stored.username)
            {
                tracing::info!("Fast path: using stored credentials (instant startup)");
                let _ = event_tx
                    .send(
                        AuthEvent::AuthSuccess {
                            token: stored.token.clone(),
                            username: username.clone(),
                            server_url: server_url.clone(),
                            server_identifier: stored.server_identifier.clone(),
                            servers: vec![],
                            client_identifier: stored.client_identifier.clone(),
                            has_plex_pass: stored.has_plex_pass,
                        }
                        .into(),
                    )
                    .await;

                return;
            }

            // Slow path: verify the token and find a live connection.
            let auth = match PlexAuth::from_stored_auth(&stored) {
                Ok(auth) => auth,
                Err(error) => {
                    tracing::error!("Cannot initialize authentication client: {}", error);
                    let _ = event_tx.send(AuthEvent::AuthShowLogin.into()).await;
                    return;
                }
            };
            if let Ok(user) = auth.verify_token(&stored.token).await {
                let servers = auth.get_servers(&stored.token).await.unwrap_or_default();

                let final_server_url = if let Some(stored_id) = &stored.server_identifier {
                    if let Some(server) = servers.iter().find(|s| &s.client_identifier == stored_id)
                    {
                        helpers::find_working_connection_with_urls(
                            server,
                            &stored.token,
                            &stored.client_identifier,
                            &connection_urls,
                        )
                        .await
                        .map(|selection| selection.selected.url)
                    } else {
                        helpers::find_working_connection_from_servers_with_urls(
                            &servers,
                            &stored.token,
                            &stored.client_identifier,
                            &connection_urls,
                        )
                        .await
                    }
                } else {
                    helpers::find_working_connection_from_servers_with_urls(
                        &servers,
                        &stored.token,
                        &stored.client_identifier,
                        &connection_urls,
                    )
                    .await
                };

                if let Some(url) = final_server_url {
                    let has_plex_pass = user.has_plex_pass();
                    let server_identifier = servers
                        .iter()
                        .find(|server| {
                            server
                                .connections
                                .iter()
                                .any(|connection| connection.uri == url)
                        })
                        .map(|server| server.client_identifier.clone());
                    let _ = event_tx
                        .send(
                            AuthEvent::AuthSuccess {
                                token: stored.token,
                                username: user.username,
                                server_url: url,
                                server_identifier,
                                servers,
                                client_identifier: stored.client_identifier,
                                has_plex_pass,
                            }
                            .into(),
                        )
                        .await;
                    return;
                }
            }
        }

        // Nothing valid — ask the UI to show the login form.
        let _ = event_tx.send(AuthEvent::AuthShowLogin.into()).await;
    });
}

pub(crate) struct ScopedAuthSender {
    pub(crate) sender: mpsc::Sender<Event>,
    pub(crate) generation: u64,
}
impl ScopedAuthSender {
    pub(crate) async fn send(&self, event: Event) -> Result<(), mpsc::error::SendError<Event>> {
        self.sender
            .send(Event::for_connection(self.generation, event))
            .await
    }
}
