//! Navigation dispatch handlers: SetView, NextView, PrevView, NextMode, PrevMode,
//! SetCategory, ToggleFocus.

use crate::app::action::{BrowseAction, FolderAction, NavigationAction, SystemAction};
use crate::app::state::{BrowseCategory, Focus, RightPanelMode, View};
use crate::app::{Action, AppState, Event};
use crate::plex::PlexClient;

use anyhow::Result;
use tokio::sync::mpsc;

use super::helpers;

/// Dispatch navigation actions. Returns follow-up actions.
pub async fn dispatch(
    event_tx: &mpsc::Sender<Event>,
    action: NavigationAction,
    state: &mut AppState,
    client: &mut PlexClient,
) -> Result<Vec<Action>> {
    let mut follow_ups = vec![];

    // Deactivate inline filter on view or category change
    if matches!(
        action,
        NavigationAction::SetView(_) | NavigationAction::SetCategory { .. }
    ) && state.list_filter.active
    {
        state.list_filter.deactivate();
    }

    match action {
        NavigationAction::SetView(view) => {
            // Clear artwork cache when leaving Similar view to force re-render
            // (Similar popup's Clear widget can corrupt terminal images)

            state.set_view(view);
            // Load stations when entering Queue view if not already loaded
            if view == View::Queue
                && state.station_nav.columns.is_empty()
                && !state.station_nav.loading
            {
                follow_ups.push(BrowseAction::LoadStations.into());
            }
            // Load waveform and spectrogram when entering NowPlaying view
            if view == View::NowPlaying {
                follow_ups.push(SystemAction::LoadWaveform.into());
                follow_ups.push(SystemAction::LoadSpectrogram.into());
            }
        }
        NavigationAction::NextView => {
            // Tab: cycle through top-level views
            // Order: Browse → Queue → Now Playing → Browse
            if state.view == View::NowPlaying {
                state.set_view(View::Browse);
            } else if state.view == View::Queue {
                state.set_view(View::NowPlaying);
            } else if state.view == View::Browse {
                state.set_view(View::Queue);
            } else {
                state.set_view(View::Browse);
            }
        }
        NavigationAction::PrevView => {
            // Shift+Tab: cycle backwards through top-level views
            // Order: Browse ← Queue ← Now Playing ← Browse
            if state.view == View::NowPlaying {
                state.set_view(View::Queue);
            } else if state.view == View::Queue {
                state.set_view(View::Browse);
            } else if state.view == View::Browse {
                state.set_view(View::NowPlaying);
            } else {
                state.set_view(View::Browse);
            }
        }
        NavigationAction::SetCategory {
            category,
            preserve_sections_focus,
        } => {
            // Picking a category implies "show me that part of the
            // library", so always switch to the Browse view too.
            // Without this, the View menu / Ctrl+L|P|G|O shortcuts
            // would silently change the category state but leave the
            // user stuck on Queue/Now Playing/Help/etc.
            if state.view != View::Browse {
                state.set_view(View::Browse);
            }

            // `preserve_sections_focus` is true on a sections-column
            // arrow-key sweep — the user is still navigating with the
            // keyboard in the sections column, the rightward content
            // should follow without focus stealing. Click / Enter /
            // palette / shortcut paths set it to false so the action
            // transfers focus to the new category's content.
            if !preserve_sections_focus {
                state.category_column_focused = false;
            }

            if state.browse_category != category {
                // Unshuffle Library root when leaving, so "All Artists" is in correct position
                if state.browse_category == BrowseCategory::Library {
                    if let Some(col) = state.artist_nav.columns.first_mut() {
                        if col.is_shuffled() {
                            col.unshuffle();
                        }
                    }
                }
                state.set_browse_category(category, preserve_sections_focus);
                state.focus = Focus::Left;
                // Clear right panel
                state.library.right_panel_mode = RightPanelMode::Empty;
                state.library.selected_artist_albums.clear();
                state.library.selected_album_tracks.clear();

                // Load category data if needed (and not already loading)
                match category {
                    BrowseCategory::Library
                        if state.library.artists.is_empty() && !state.library.artists_loading =>
                    {
                        helpers::load_artists(event_tx, state, client);
                    }
                    BrowseCategory::Playlists => {
                        if state.library.playlists.is_empty() && !state.library.playlists_loading {
                            helpers::load_playlists(event_tx, state, client);
                        } else {
                            // Rebuild root column from state.library.playlists to ensure it's populated
                            // (guards against stale/empty nav from preload race conditions)
                            let items = crate::app::state::BrowseItem::from_playlists(
                                &state.library.playlists,
                            );
                            state.playlist_nav.reset("playlists", items);
                        }
                    }
                    BrowseCategory::Folders if state.folder_state.is_none() => {
                        follow_ups.push(FolderAction::LoadFolderRoot.into());
                    }
                    cat if cat.is_tag_section() => {
                        // Reset shared tag_nav for the new section.
                        state.tag_nav.columns.clear();
                        state.tag_nav.focused_column = 0;
                        follow_ups.push(BrowseAction::RefreshTagView.into());
                    }
                    _ => {}
                }
            }
        }
        NavigationAction::ToggleFocus => {
            state.focus = match state.focus {
                Focus::Left => Focus::Right,
                Focus::Right => Focus::Left,
            };
        }
    }
    Ok(follow_ups)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::plex::PlexClientInfo;

    fn setup() -> (
        mpsc::Sender<Event>,
        mpsc::Receiver<Event>,
        AppState,
        PlexClient,
    ) {
        let (tx, rx) = mpsc::channel(100);
        let state = AppState::new();
        let client = PlexClient::new(PlexClientInfo::default()).unwrap();
        (tx, rx, state, client)
    }

    #[tokio::test]
    async fn toggle_focus_left_to_right() {
        let (tx, _rx, mut state, mut client) = setup();
        state.focus = Focus::Left;

        dispatch(&tx, NavigationAction::ToggleFocus, &mut state, &mut client)
            .await
            .unwrap();
        assert_eq!(state.focus, Focus::Right);
    }

    #[tokio::test]
    async fn toggle_focus_right_to_left() {
        let (tx, _rx, mut state, mut client) = setup();
        state.focus = Focus::Right;

        dispatch(&tx, NavigationAction::ToggleFocus, &mut state, &mut client)
            .await
            .unwrap();
        assert_eq!(state.focus, Focus::Left);
    }

    #[tokio::test]
    async fn set_view_changes_state() {
        let (tx, _rx, mut state, mut client) = setup();

        dispatch(
            &tx,
            NavigationAction::SetView(View::Queue),
            &mut state,
            &mut client,
        )
        .await
        .unwrap();
        assert_eq!(state.view, View::Queue);

        dispatch(
            &tx,
            NavigationAction::SetView(View::Help),
            &mut state,
            &mut client,
        )
        .await
        .unwrap();
        assert_eq!(state.view, View::Help);
    }

    #[tokio::test]
    async fn set_view_queue_requests_load_stations() {
        let (tx, _rx, mut state, mut client) = setup();

        let follow_ups = dispatch(
            &tx,
            NavigationAction::SetView(View::Queue),
            &mut state,
            &mut client,
        )
        .await
        .unwrap();
        assert!(follow_ups
            .iter()
            .any(|a| matches!(a, Action::Browse(BrowseAction::LoadStations))));
    }

    #[tokio::test]
    async fn set_view_now_playing_requests_waveform() {
        let (tx, _rx, mut state, mut client) = setup();

        let follow_ups = dispatch(
            &tx,
            NavigationAction::SetView(View::NowPlaying),
            &mut state,
            &mut client,
        )
        .await
        .unwrap();
        assert!(follow_ups
            .iter()
            .any(|a| matches!(a, Action::System(SystemAction::LoadWaveform))));
        assert!(follow_ups
            .iter()
            .any(|a| matches!(a, Action::System(SystemAction::LoadSpectrogram))));
    }

    #[tokio::test]
    async fn next_view_browse_to_queue() {
        let (tx, _rx, mut state, mut client) = setup();
        state.view = View::Browse;
        state.set_browse_category(BrowseCategory::Library, false);

        dispatch(&tx, NavigationAction::NextView, &mut state, &mut client)
            .await
            .unwrap();
        assert_eq!(state.view, View::Queue);
    }

    #[tokio::test]
    async fn next_view_queue_to_now_playing() {
        let (tx, _rx, mut state, mut client) = setup();
        state.view = View::Queue;

        dispatch(&tx, NavigationAction::NextView, &mut state, &mut client)
            .await
            .unwrap();
        assert_eq!(state.view, View::NowPlaying);
    }

    #[tokio::test]
    async fn next_view_now_playing_to_browse() {
        let (tx, _rx, mut state, mut client) = setup();
        state.view = View::NowPlaying;

        dispatch(&tx, NavigationAction::NextView, &mut state, &mut client)
            .await
            .unwrap();
        assert_eq!(state.view, View::Browse);
    }

    #[tokio::test]
    async fn prev_view_library_to_now_playing() {
        let (tx, _rx, mut state, mut client) = setup();
        state.view = View::Browse;
        state.set_browse_category(BrowseCategory::Library, false);

        dispatch(&tx, NavigationAction::PrevView, &mut state, &mut client)
            .await
            .unwrap();
        assert_eq!(state.view, View::NowPlaying);
    }

    #[tokio::test]
    async fn prev_view_now_playing_to_queue() {
        let (tx, _rx, mut state, mut client) = setup();
        state.view = View::NowPlaying;

        dispatch(&tx, NavigationAction::PrevView, &mut state, &mut client)
            .await
            .unwrap();
        assert_eq!(state.view, View::Queue);
    }

    #[tokio::test]
    async fn set_category_changes_and_resets_focus() {
        let (tx, _rx, mut state, mut client) = setup();
        state.view = View::Browse;
        state.set_browse_category(BrowseCategory::Library, false);
        state.focus = Focus::Right;

        dispatch(
            &tx,
            NavigationAction::set_category(BrowseCategory::AlbumGenres),
            &mut state,
            &mut client,
        )
        .await
        .unwrap();
        assert_eq!(state.browse_category, BrowseCategory::AlbumGenres);
        assert_eq!(state.focus, Focus::Left);
    }

    #[tokio::test]
    async fn set_category_same_is_noop() {
        let (tx, _rx, mut state, mut client) = setup();
        state.view = View::Browse;
        state.set_browse_category(BrowseCategory::Library, false);
        state.focus = Focus::Right; // keep right focus

        dispatch(
            &tx,
            NavigationAction::set_category(BrowseCategory::Library),
            &mut state,
            &mut client,
        )
        .await
        .unwrap();
        // Category didn't change, so focus should remain Right
        assert_eq!(state.focus, Focus::Right);
    }
}
