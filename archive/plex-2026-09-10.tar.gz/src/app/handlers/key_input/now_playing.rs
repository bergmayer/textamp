//! Queue and Now Playing view key handling.

use crate::app::action::*;
use crossterm::event::{self, KeyCode, KeyModifiers};

use crate::app::state::{NowPlayingFocus, PlaybackMode, View};
use crate::app::Action;
use crate::app::AppState;
use crate::plex::models::Track;

/// Handle Queue view keys (track list + sidebar buttons).
pub(super) fn handle_queue_keys(key: event::KeyEvent, state: &mut AppState) -> Vec<Action> {
    // Horizontal navigation between the three top panes:
    //   Sidebar  ←→  Tracks  ←→  Artwork
    // Left from Tracks → Sidebar; Right from Tracks → Artwork.
    // Sidebar Right and Artwork Left are handled inside their own
    // sub-handlers below.
    if state.now_playing_focus == NowPlayingFocus::Tracks && key.code == KeyCode::Left {
        state.now_playing_focus = NowPlayingFocus::Sidebar;
        return vec![];
    }
    if state.now_playing_focus == NowPlayingFocus::Tracks && key.code == KeyCode::Right {
        state.now_playing_focus = NowPlayingFocus::Artwork;
        return vec![];
    }

    // Sidebar focused: navigate the four buttons.
    if state.now_playing_focus == NowPlayingFocus::Sidebar {
        return handle_sidebar_keys(key, state);
    }

    // Artwork focused: arrow keys hop to neighbours; Enter opens
    // the Artist Bio popup as a little easter egg.
    if state.now_playing_focus == NowPlayingFocus::Artwork {
        return handle_artwork_keys(key, state);
    }

    handle_queue_track_keys(key, state)
}

/// Handle keyboard nav while the right-side artwork panel has
/// focus. Arrow keys hop to neighbours; Enter is the easter-egg
/// shortcut to open the Artist Bio popup for the now-playing
/// (or focused) artist.
fn handle_artwork_keys(key: event::KeyEvent, state: &mut AppState) -> Vec<Action> {
    match key.code {
        KeyCode::Left => {
            state.now_playing_focus = NowPlayingFocus::Tracks;
            vec![]
        }
        KeyCode::Down => {
            // Drop into the visualizer below — focus the tab bar so
            // the user can immediately pick a viz mode.
            state.now_playing_focus = NowPlayingFocus::Tracks;
            state.visualizer_tab_focused = true;
            vec![NavigationAction::SetView(View::NowPlaying).into()]
        }
        KeyCode::Up => {
            // No-op — artwork is the top-most slot in this column.
            vec![]
        }
        KeyCode::Esc => {
            state.now_playing_focus = NowPlayingFocus::Tracks;
            vec![]
        }
        KeyCode::Enter => {
            // Easter egg: pressing Enter on the cover art opens the
            // Artist Bio popup for whichever artist resolves from
            // the now-playing track (or focused row).
            match crate::app::handlers::helpers::get_artist_for_bio(state) {
                Some((artist_key, artist_name)) => vec![SearchAction::ShowArtistBio {
                    artist_key,
                    artist_name,
                }
                .into()],
                None => vec![],
            }
        }
        _ => vec![],
    }
}

/// Handle keyboard nav over the now-playing left sidebar buttons:
/// Capability-filtered Radio / DJ Modes / Remix Tools / Clear Queue.
fn handle_sidebar_keys(key: event::KeyEvent, state: &mut AppState) -> Vec<Action> {
    let buttons = state.now_playing_sidebar_buttons();
    let n = buttons.len();
    state.now_playing_sidebar_index = state.now_playing_sidebar_index.min(n - 1);
    match key.code {
        KeyCode::Up => {
            state.now_playing_sidebar_index = state.now_playing_sidebar_index.saturating_sub(1);
            vec![]
        }
        KeyCode::Down => {
            // At the bottom of the sidebar (Clear Queue), Down hops
            // straight to the visualizer below. Otherwise just
            // advance to the next button.
            if state.now_playing_sidebar_index >= n - 1 {
                state.now_playing_focus = NowPlayingFocus::Tracks;
                state.visualizer_tab_focused = true;
                return vec![NavigationAction::SetView(View::NowPlaying).into()];
            }
            state.now_playing_sidebar_index = (state.now_playing_sidebar_index + 1).min(n - 1);
            vec![]
        }
        KeyCode::Right | KeyCode::Esc => {
            state.now_playing_focus = NowPlayingFocus::Tracks;
            vec![]
        }
        KeyCode::Enter => activate_sidebar(state, buttons[state.now_playing_sidebar_index]),
        _ => vec![],
    }
}

/// Handle Now Playing visualizer view keys (artwork + track info + waveform seekbar).
///
/// Standard arrow-key navigation: arrows always traverse the
/// on-screen UI elements. Seeking uses the global Shift+arrow shortcuts so the
/// arrows are free to walk between the visualizer, the visualizer
/// tab bar, and the queue / sidebar / tracks at the top of the
/// combined Now-Playing screen.
pub(super) fn handle_now_playing_visualizer_keys(
    key: event::KeyEvent,
    state: &mut AppState,
) -> Vec<Action> {
    // When visualizer tab bar is focused, arrow keys navigate tabs.
    if state.visualizer_tab_focused {
        match key.code {
            KeyCode::Left => {
                state.visualizer_tab = state.visualizer_tab.prev();
                return vec![];
            }
            KeyCode::Right => {
                state.visualizer_tab = state.visualizer_tab.next();
                return vec![];
            }
            KeyCode::Up => {
                // Tab bar → queue tracks at the top of the screen.
                state.visualizer_tab_focused = false;
                state.now_playing_focus = NowPlayingFocus::Tracks;
                return vec![NavigationAction::SetView(View::Queue).into()];
            }
            KeyCode::Down | KeyCode::Enter => {
                state.visualizer_tab_focused = false;
                return vec![];
            }
            KeyCode::Esc => {
                state.visualizer_tab_focused = false;
                return vec![];
            }
            _ => {}
        }
    }

    match key.code {
        KeyCode::Esc => vec![],
        KeyCode::F(1) => vec![NavigationAction::SetView(View::Help).into()],

        // Up: focus the visualizer tab bar (waveform / spectrum /
        // spectrogram). A second Up walks onto the queue tracks at
        // the top of the screen.
        KeyCode::Up => {
            state.visualizer_tab_focused = true;
            vec![]
        }
        // Down on the visualizer: nothing — it's the bottom-most
        // region of the screen.
        KeyCode::Down => vec![],

        // Left jumps up to the queue area and lands on the left-side
        // sidebar (Radio / DJ Modes / Remix Tools / Clear Queue) —
        // single keypress from the visualizer to the sidebar.
        KeyCode::Left => {
            state.now_playing_focus = NowPlayingFocus::Sidebar;
            vec![NavigationAction::SetView(View::Queue).into()]
        }
        // Right jumps up to the queue track list. Symmetric with
        // Left so the queue area is one keypress away in either
        // direction.
        KeyCode::Right => {
            state.now_playing_focus = NowPlayingFocus::Tracks;
            vec![NavigationAction::SetView(View::Queue).into()]
        }

        // Preserve the one-second forward shortcut; comma opens Settings globally.
        KeyCode::Char('.') => vec![PlaybackAction::SeekRelative(1000).into()],

        _ => vec![],
    }
}

/// Handle track list keys in the Queue view.
fn handle_queue_track_keys(key: event::KeyEvent, state: &mut AppState) -> Vec<Action> {
    // Get the max index based on current mode
    let get_max_index = |state: &AppState| -> usize {
        match state.playback_mode {
            PlaybackMode::Queue | PlaybackMode::None => state.queue.tracks.len().saturating_sub(1),
            PlaybackMode::Radio => state.radio.tracks.len().saturating_sub(1),
        }
    };

    match key.code {
        KeyCode::Esc => {
            // Exit multi-select mode, clearing any selection.
            if state.select_mode || !state.queue.selected.is_empty() {
                state.select_mode = false;
                state.queue.selected.clear();
                return vec![];
            }
            vec![]
        }
        KeyCode::F(1) => vec![NavigationAction::SetView(View::Help).into()],

        // Shift+Up/Down: move queue track(s) up/down (batch if multi-selected)
        KeyCode::Up if key.modifiers.contains(KeyModifiers::SHIFT) => {
            if state.queue.selected.is_empty() {
                vec![QueueAction::MoveQueueTrackUp.into()]
            } else {
                vec![QueueAction::MoveSelectedTracksUp.into()]
            }
        }
        KeyCode::Down if key.modifiers.contains(KeyModifiers::SHIFT) => {
            if state.queue.selected.is_empty() {
                vec![QueueAction::MoveQueueTrackDown.into()]
            } else {
                vec![QueueAction::MoveSelectedTracksDown.into()]
            }
        }

        // Ctrl+Z: undo last remix
        KeyCode::Char('z') if key.modifiers.contains(KeyModifiers::CONTROL) => {
            vec![QueueAction::UndoLastRemix.into()]
        }

        KeyCode::Up => {
            state.scroll.queue = None;
            if state.list_state.queue_index > 0 {
                state.list_state.queue_index -= 1;
            }
            vec![]
        }
        KeyCode::Down => {
            state.scroll.queue = None;
            let max = get_max_index(state);
            // Down at the bottom of the list (or in an empty queue)
            // hops the focus over to the visualizer area below — its
            // tab bar gets focused so the user can immediately
            // arrow-Left/Right between waveform / spectrum /
            // spectrogram / vectorscope.
            if state.queue.tracks.is_empty() || state.list_state.queue_index >= max {
                state.visualizer_tab_focused = true;
                return vec![NavigationAction::SetView(View::NowPlaying).into()];
            }
            state.list_state.queue_index = (state.list_state.queue_index + 1).min(max);
            vec![]
        }
        KeyCode::PageUp => {
            state.scroll.queue = None;
            state.list_state.queue_index = state.list_state.queue_index.saturating_sub(10);
            vec![]
        }
        KeyCode::PageDown => {
            state.scroll.queue = None;
            let max = get_max_index(state);
            state.list_state.queue_index = (state.list_state.queue_index + 10).min(max);
            vec![]
        }
        KeyCode::Home => {
            state.scroll.queue = None;
            state.list_state.queue_index = 0;
            vec![]
        }
        KeyCode::End => {
            state.scroll.queue = None;
            let max = get_max_index(state);
            state.list_state.queue_index = max;
            vec![]
        }

        KeyCode::Enter => {
            // If the selected track is already playing, switch to NowPlaying view
            let is_current = match state.playback_mode {
                PlaybackMode::Queue | PlaybackMode::None => {
                    state.queue.index == Some(state.list_state.queue_index)
                }
                PlaybackMode::Radio => {
                    state.radio.track_index == Some(state.list_state.queue_index)
                }
            };
            if is_current {
                return vec![
                    NavigationAction::SetView(View::NowPlaying).into(),
                    SystemAction::LoadWaveform.into(),
                ];
            }

            // Play selected item from queue or radio (without modifying queue order)
            match state.playback_mode {
                PlaybackMode::Queue | PlaybackMode::None => {
                    let queue_idx = state.list_state.queue_index;
                    if queue_idx < state.queue.tracks.len() {
                        vec![QueueAction::JumpToQueueIndex(queue_idx).into()]
                    } else {
                        vec![]
                    }
                }
                PlaybackMode::Radio => {
                    // Jump to selected radio track without clearing radio state
                    if state.list_state.queue_index < state.radio.tracks.len() {
                        vec![RadioAction::JumpToRadioTrack(state.list_state.queue_index).into()]
                    } else {
                        vec![]
                    }
                }
            }
        }

        KeyCode::Delete => {
            if !state.queue.selected.is_empty() {
                return vec![QueueAction::RemoveSelectedFromQueue.into()];
            }
            match state.playback_mode {
                PlaybackMode::Queue | PlaybackMode::None => {
                    vec![QueueAction::RemoveFromQueue(state.list_state.queue_index).into()]
                }
                PlaybackMode::Radio => {
                    let target_idx = state.list_state.queue_index;
                    let snapshot = state.convert_radio_to_queue("Delete track (from radio)");
                    state.queue.undo_snapshot = Some(snapshot);
                    vec![QueueAction::RemoveFromQueue(target_idx).into()]
                }
            }
        }

        // Alphabet jumping
        KeyCode::Char(c) if c.is_ascii_alphabetic() && key.modifiers.is_empty() => {
            let letter_lower = c.to_ascii_lowercase();
            let tracks: &[Track] = match state.playback_mode {
                PlaybackMode::Queue | PlaybackMode::None => &state.queue.tracks,
                PlaybackMode::Radio => &state.radio.tracks,
            };
            if let Some(idx) = tracks.iter().position(|t| {
                t.title
                    .chars()
                    .next()
                    .map(|ch| ch.to_ascii_lowercase() == letter_lower)
                    .unwrap_or(false)
            }) {
                state.list_state.queue_index = idx;
            }
            vec![]
        }

        _ => vec![],
    }
}

pub(crate) fn activate_sidebar(
    state: &mut AppState,
    button: crate::app::presentation::NpSidebarButton,
) -> Vec<Action> {
    use crate::app::presentation::NpSidebarButton::*;
    match button {
        ClearQueue => vec![QueueAction::ClearQueue.into()],
        Radio | DjModes | Remix => {
            let query = match button {
                Radio => "Radio",
                DjModes => "DJ",
                _ => "Remix",
            };
            crate::app::command_palette::open_with_query(state, query);
            vec![]
        }
    }
}
