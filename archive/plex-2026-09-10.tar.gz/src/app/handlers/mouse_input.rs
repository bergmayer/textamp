//! Mouse input handler functions.
//!
//! All mouse event processing extracted from the event loop as free functions.

use super::helpers;
use crate::app::action::*;
use crate::app::command_palette;
use crate::app::scrollbar::{calc_thumb, scroll_offset_from_y};
use crate::app::state::{
    BrowseCategory, BrowseItem, BrowseNavigationState, PlaybackMode, ScrollbarDrag, ScrollbarView,
    SearchTab, View,
};
use crate::app::Action;
use crate::app::AppState;
use ratatui::layout::Rect;

/// Check if a browse column uses 2-row display for mouse hit-testing.
/// Mirrors the logic in `is_two_row_column()` in `src/ui/app.rs`.
fn is_two_row_browse_column(
    state: &AppState,
    col: &crate::app::state::BrowseColumn,
    col_idx: usize,
    nav: &BrowseNavigationState,
) -> bool {
    let first_is_track = col
        .items
        .first()
        .is_some_and(|item| matches!(item, BrowseItem::Track { .. }));
    let first_is_album = col
        .items
        .first()
        .is_some_and(|item| matches!(item, BrowseItem::Album { .. }));

    // Special track columns always get two-row display
    if first_is_track && state.is_special_track_column(nav, col_idx) {
        return true;
    }

    // Album columns in "All Artists" mode
    if first_is_album
        && (nav
            .columns
            .first()
            .and_then(|c| c.selected_item())
            .is_some_and(|item| matches!(item, BrowseItem::AllArtists))
            || (state.browse_category == BrowseCategory::Library
                && state.library.library_sub_mode != crate::app::state::LibrarySubMode::Normal
                && col_idx == 0))
    {
        return true;
    }

    // Genre/mood album columns
    if first_is_album && state.browse_category.is_tag_section() {
        return true;
    }

    // Grouped-by-album playlist columns (albums with artist on 2nd row).
    // Mirrors the renderer's `is_two_row_column` in `src/ui/app.rs`;
    // without this branch, clicks in playlists like "rephlex and skam"
    // (which the user grouped by album) misalign because the hit-test
    // thinks rows are 1 cell tall while the renderer paints 2.
    if first_is_album && col.grouped_by_album {
        return true;
    }

    false
}

/// Handle a click on a Miller column that has an active filter.
///
/// Returns `true` if this is a "second click" (drill-down): filter is deactivated,
/// caller should dispatch the drill-down action.
/// Returns `false` if this is a "first click" (selection only): filter stays active,
/// the item is highlighted and the caller should return without drilling.
///
/// Common logic shared by browse, folder, genre, and playlist column click handlers.
fn handle_filtered_column_click(
    state: &mut AppState,
    col_idx: usize,
    item_idx: usize,
    scroll_offset: usize,
    col_selected_index: usize,
) -> bool {
    // Detect "second click": item is already selected AND there was a recent click
    // (distinguishes "auto-selected by filter typing" from "selected by prior click")
    let is_drill = col_selected_index == item_idx
        && state
            .scroll
            .browse_click_time
            .map(|t| t.elapsed().as_millis() < 2000)
            .unwrap_or(false);

    state.scroll.browse = Some((col_idx, scroll_offset));
    state.scroll.browse_click_time = Some(std::time::Instant::now());

    if is_drill {
        // Second click → deactivate filter, caller dispatches drill-down
        state.list_filter.deactivate();
        true
    } else {
        // First click → update filter selection, keep filter active
        if let Some(ref results) = state.list_filter.results {
            if let Some(pos) = results
                .matched_indices
                .iter()
                .position(|&idx| idx == item_idx)
            {
                state.list_filter.selected = pos;
            }
        }
        false
    }
}

/// Check if a BrowseItem should be rendered as a one-row item (no artwork) in art grid mode.
fn is_one_row_item(item: &BrowseItem) -> bool {
    matches!(
        item,
        BrowseItem::ArtistRadio { .. }
            | BrowseItem::AllTracks { .. }
            | BrowseItem::CompilationTracks { .. }
            | BrowseItem::Compilations
    )
}

/// Handle mouse events.
pub fn handle_mouse(event: crossterm::event::MouseEvent, state: &mut AppState) -> Vec<Action> {
    // These overlays have no pointer controls; never let input reach the player.
    if state.popups.input_dialog.is_some() || state.notifications.last_error.is_some() {
        state.seek_drag = None;
        state.volume_drag = false;
        state.scroll.scrollbar_drag = None;
        state.miller_h_drag_grab = None;
        return vec![];
    }
    if state.popups.library_dialog.is_some() {
        return crate::app::sources::dialogs::mouse(event, state);
    }
    use crossterm::event::{MouseButton, MouseEventKind};
    if let Some(popup) = &mut state.popups.text {
        match event.kind {
            MouseEventKind::ScrollDown => popup.scroll = popup.scroll.saturating_add(3),
            MouseEventKind::ScrollUp => popup.scroll = popup.scroll.saturating_sub(3),
            _ => {}
        }
        return vec![];
    }

    let click_row = event.row;
    let click_col = event.column;
    if matches!(event.kind, MouseEventKind::Down(MouseButton::Left)) {
        // Also recover from a release that happened outside the terminal.
        state.seek_drag = None;
        state.volume_drag = false;
    }

    // Mouse click exits multi-select mode — any pointer interaction
    // is treated as a "leave the keyboard expand mode" gesture. The
    // existing selection set persists; the user can act on it after
    // exiting, or click on rows again to manipulate normally.
    let is_click_down = matches!(
        event.kind,
        MouseEventKind::Down(MouseButton::Left)
            | MouseEventKind::Down(MouseButton::Right)
            | MouseEventKind::Down(MouseButton::Middle)
    );
    if is_click_down && state.select_mode {
        state.select_mode = false;
    }
    // Same for the track-details pane focus: any click outside the
    // pane drops focus from it. The pane click handler below will
    // re-set the flag when the click lands on the pane's rect.
    if is_click_down && state.track_pane_focused {
        state.track_pane_focused = false;
    }

    // Calculate layout regions
    // Layout: [content] [transport(2)] — the old 3-row command bar
    // is gone (replaced by the `:` command palette).
    let transport_start = state.terminal_height.saturating_sub(2);
    let tab_strip_row = state.terminal_height.saturating_sub(1);
    // The command bar no longer exists; keep these named for the
    // existing branches but pin them past the screen so the
    // "click in command bar" branches never fire.
    let commands_start = state.terminal_height;
    let command_top_row = state.terminal_height;

    // Command palette overlay intercepts clicks when open. Click on a
    // row → set selection + execute (same as Enter). Click elsewhere
    // inside the popup → no-op (keep open). Click outside → cancel.
    if state.palette.open {
        if let MouseEventKind::Down(MouseButton::Left) = event.kind {
            let regions = state.hit_regions.command_palette.clone();
            if let Some(regions) = regions {
                let inside_outer = click_row >= regions.outer.y
                    && click_row < regions.outer.y + regions.outer.height
                    && click_col >= regions.outer.x
                    && click_col < regions.outer.x + regions.outer.width;
                if !inside_outer {
                    state.palette.close();
                    return vec![];
                }
                for (rect, match_idx) in &regions.rows {
                    if click_row >= rect.y
                        && click_row < rect.y + rect.height
                        && click_col >= rect.x
                        && click_col < rect.x + rect.width
                    {
                        state.palette.selected = *match_idx;
                        if let Some(&entry_idx) = state.palette.matches.get(*match_idx) {
                            if let Some(entry) = state.palette.entries.get(entry_idx) {
                                let cmd = entry.command.clone();
                                state.palette.close();
                                return command_palette::run(cmd, state);
                            }
                        }
                        return vec![];
                    }
                }
            }
        }
        // Swallow non-left-click events while palette is open — no
        // scrolling / right-click context menus on the overlay.
        return vec![];
    }

    // Confirm dialog intercepts mouse clicks when active
    if state.popups.confirm_dialog.is_some() {
        if let crossterm::event::MouseEventKind::Down(crossterm::event::MouseButton::Left) =
            event.kind
        {
            // Read registered regions (drop borrow before mutating state)
            let regions = {
                let hr = &state.hit_regions;
                hr.confirm_dialog.clone()
            };
            if let Some(regions) = regions {
                // Determine which button was clicked (if any)
                let clicked_yes = if click_row == regions.yes_button.y
                    && click_col >= regions.yes_button.x
                    && click_col < regions.yes_button.right()
                {
                    Some(true)
                } else if click_row == regions.no_button.y
                    && click_col >= regions.no_button.x
                    && click_col < regions.no_button.right()
                {
                    Some(false)
                } else {
                    None
                };

                if let Some(clicked_yes) = clicked_yes {
                    if let Some(dialog) = state.popups.confirm_dialog.as_ref() {
                        let already_selected = clicked_yes == dialog.selected_yes;
                        if already_selected {
                            let dialog = state.popups.confirm_dialog.take().unwrap();
                            if clicked_yes {
                                use crate::app::state::ConfirmAction;
                                return match dialog.on_confirm {
                                    ConfirmAction::RefreshCache => {
                                        helpers::refresh_current_view(state)
                                    }
                                    ConfirmAction::ClearLibraryCache => {
                                        vec![SettingsAction::ClearLibraryCache.into()]
                                    }
                                    ConfirmAction::ClearArtworkCache => {
                                        vec![SettingsAction::ClearArtworkCache.into()]
                                    }
                                    ConfirmAction::ClearSubfolderCache => {
                                        vec![SettingsAction::ClearSubfolderCache.into()]
                                    }
                                    ConfirmAction::RemoveFolder(id) => vec![Action::Source(
                                        crate::app::sources::SourceAction::Remove(id),
                                    )],
                                    ConfirmAction::RemovePlexAccount(id) => vec![Action::Source(
                                        crate::app::sources::SourceAction::RemoveAccount(id),
                                    )],
                                    ConfirmAction::NavidromeDeletePlaylist(id) => vec![crate::app::sources::navidrome::NavAction::Command(crate::app::sources::navidrome::commands::Command::DeletePlaylist(id)).into()],
                    ConfirmAction::NavidromeReplacePlaylist(id) => vec![crate::app::sources::navidrome::NavAction::Command(crate::app::sources::navidrome::commands::Command::ReplacePlaylist(id)).into()],
                    ConfirmAction::RemoveNavidrome(id) => vec![crate::app::sources::navidrome::NavAction::Remove(id).into()],
                                    ConfirmAction::Logout => vec![SettingsAction::Logout.into()],
                                    ConfirmAction::Quit => vec![SystemAction::Quit.into()],
                                };
                            }
                            return vec![];
                        } else {
                            state.popups.confirm_dialog.as_mut().unwrap().selected_yes =
                                clicked_yes;
                            return vec![];
                        }
                    }
                }
            }
        }
        return vec![];
    }

    if crate::app::sources::manager::settings_active(state)
        && matches!(
            event.kind,
            crossterm::event::MouseEventKind::Down(crossterm::event::MouseButton::Left)
        )
        && state
            .hit_regions
            .library_sonic_toggle
            .is_some_and(|r| r.contains(ratatui::layout::Position::new(event.column, event.row)))
    {
        if let Some(choice) =
            crate::app::sources::choices(state).get(state.popups.library_picker_index)
        {
            return vec![Action::Source(
                crate::app::sources::SourceAction::ToggleSonic(choice.clone()),
            )];
        }
    }
    if crate::app::sources::manager::settings_active(state)
        && event.kind == crossterm::event::MouseEventKind::Down(crossterm::event::MouseButton::Left)
        && state
            .hit_regions
            .library_audiomuse
            .is_some_and(|r| r.contains((event.column, event.row).into()))
    {
        if let Some(choice) =
            crate::app::sources::choices(state).get(state.popups.library_picker_index)
        {
            return vec![crate::app::sources::audiomuse::Command::Configure(choice.clone()).into()];
        }
    }
    // Library picker popup intercepts all mouse events when active
    if state.popups.library_picker_active {
        return handle_library_picker_mouse(event, state);
    }
    if crate::app::sources::manager::settings_active(state)
        && state
            .hit_regions
            .library_picker
            .as_ref()
            .is_some_and(|region| {
                region
                    .outer
                    .contains(ratatui::layout::Position::new(event.column, event.row))
            })
    {
        if matches!(
            event.kind,
            crossterm::event::MouseEventKind::Down(crossterm::event::MouseButton::Left)
        ) {
            state.settings_state.focus = crate::app::state::SettingsFocus::Content;
        }
        return handle_library_picker_mouse(event, state);
    }

    // Search popup intercepts mouse clicks when active
    if state.popups.search_active {
        if let crossterm::event::MouseEventKind::Down(crossterm::event::MouseButton::Left) =
            event.kind
        {
            return handle_search_popup_click(click_row, click_col, state);
        }
        return vec![];
    }

    // Artist radio picker popup intercepts mouse clicks when active
    if state.popups.artist_radio_picker.is_some() {
        if let crossterm::event::MouseEventKind::Down(crossterm::event::MouseButton::Left) =
            event.kind
        {
            return handle_artist_radio_picker_click(click_row, click_col, state);
        }
        return vec![];
    }

    // Adventure launcher popup intercepts mouse clicks when active
    if state.popups.adventure_launcher.is_some() {
        if let crossterm::event::MouseEventKind::Down(crossterm::event::MouseButton::Left) =
            event.kind
        {
            return handle_adventure_launcher_click(click_row, click_col, state);
        }
        return vec![];
    }

    // Artist bio popup intercepts all mouse events when active
    if state.popups.artist_bio.is_some() {
        match event.kind {
            crossterm::event::MouseEventKind::ScrollDown => {
                if let Some(ref mut popup) = state.popups.artist_bio {
                    popup.scroll = popup.scroll.saturating_add(3);
                }
            }
            crossterm::event::MouseEventKind::ScrollUp => {
                if let Some(ref mut popup) = state.popups.artist_bio {
                    popup.scroll = popup.scroll.saturating_sub(3);
                }
            }
            crossterm::event::MouseEventKind::Down(crossterm::event::MouseButton::Left) => {
                state.popups.artist_bio = None;
                // Bio popup overlays the Now Playing artwork when shown
                // from that view; dropping the protocol forces a fresh
                // image placement on the next render so the terminal
                // re-displays the cover that the popup hid.
            }
            _ => {}
        }
        return vec![];
    }

    // Sort popup intercepts mouse clicks when active
    if state.popups.sort.is_some() {
        if let crossterm::event::MouseEventKind::Down(crossterm::event::MouseButton::Left) =
            event.kind
        {
            return handle_sort_popup_click(click_row, click_col, state);
        }
        return vec![];
    }

    // Resolve clicks against rendered panes, not the previous keyboard focus.
    // The Search landing panel covers retained navigation state, not clickable
    // tracks. Consume wheel/right-click too, before legacy geometry fallbacks.
    if state
        .hit_regions
        .search_landing
        .is_some_and(|area| area.contains(ratatui::layout::Position::new(click_col, click_row)))
    {
        return vec![];
    }

    // Wheel events use the same geometry but do not steal keyboard focus.
    if matches!(
        event.kind,
        MouseEventKind::Down(MouseButton::Left | MouseButton::Right)
    ) {
        state.set_view(pointer_view(state, click_col, click_row));
    }

    match event.kind {
        // Left click
        MouseEventKind::Down(MouseButton::Left) => {
            // Click outside filter box closes it (filter is in the transport bar).
            // Exception: in Browse view, clicks on items in the filtered column pass
            // through (so you can select a filtered result). But if the query is empty,
            // clicking anywhere closes the filter.
            if state.list_filter.active
                && !(click_row >= transport_start && click_row < commands_start)
                && (state.view != View::Browse || state.list_filter.query.is_empty())
            {
                state.list_filter.deactivate();
                return vec![];
            }
            // Browse view with non-empty query: let content-area clicks pass through
            // to normal handlers. Filter stays active until Esc or view change.

            // Check command bar (bottom 3 rows: top row has tabs+F-keys, spacer, bottom has contextual)
            if click_row >= commands_start {
                if click_row == command_top_row {
                    // Top row: check tab bar items first (library label, quit, view tabs),
                    // then F-key items
                    let tab_result = handle_tab_bar_click(click_col, state);
                    if !tab_result.is_empty() {
                        return tab_result;
                    }
                    return handle_command_bar_click(click_col, state, true);
                } else if click_row == commands_start + 2 {
                    return handle_command_bar_click(click_col, state, false);
                }
                // Middle row is spacer — ignore clicks
                return vec![];
            }

            // Check transport bar (2 rows). The bottom row is the
            // Library / Now Playing tab strip; clicks there go to
            // the shared tab-bar handler. The top row is the actual
            // playback transport.
            if click_row == tab_strip_row {
                let tab_result = handle_tab_bar_click(click_col, state);
                if !tab_result.is_empty() {
                    return tab_result;
                }
                return vec![];
            }
            if click_row >= transport_start && click_row < commands_start {
                return handle_transport_down(click_col, click_row, transport_start, state);
            }

            // Niri-style horizontal scrollbar (Browse view, scrolling
            // Miller layout, ribbon overflows screen). Click on the
            // rail jumps to that position; click on the thumb starts
            // a drag tracked through the next Drag events.
            {
                let bar = state.hit_regions.miller_h_scrollbar.clone();
                if let Some(bar) = bar {
                    if click_row == bar.rail.y
                        && click_col >= bar.rail.x
                        && click_col < bar.rail.x + bar.rail.width
                    {
                        let max_start = bar.total.saturating_sub(bar.visible);
                        if click_col >= bar.thumb_x && click_col < bar.thumb_x + bar.thumb_w {
                            // Drag grab: remember click offset inside
                            // thumb so the thumb tracks the cursor
                            // instead of recentering on it.
                            state.miller_h_drag_grab = Some(click_col - bar.thumb_x);
                        } else {
                            // Click on the rail outside the thumb —
                            // center the thumb on the click and seed
                            // a drag from there.
                            let rel = (click_col - bar.rail.x) as usize;
                            let thumb_target = rel.saturating_sub(bar.thumb_w as usize / 2);
                            let usable_rail = (bar.rail.width as usize)
                                .saturating_sub(bar.thumb_w as usize)
                                .max(1);
                            let new_start =
                                (thumb_target * max_start + usable_rail / 2) / usable_rail;
                            state.miller_scroll_col = new_start.min(max_start);
                            state.miller_scroll_manual = true;
                            state.miller_h_drag_grab = Some(bar.thumb_w / 2);
                        }
                        return vec![];
                    }
                }
            }

            if matches!(state.view, View::Browse | View::Queue | View::NowPlaying) {
                if let Some(actions) = visualizer_click(click_col, click_row, state) {
                    return actions;
                }
            }

            // Content area clicks depend on view
            match state.view {
                View::Auth => {
                    return handle_auth_click(click_row, click_col, state);
                }
                View::Browse => {
                    return handle_browse_click(click_row, click_col, state);
                }
                View::Queue | View::NowPlaying => {
                    return handle_now_playing_down(click_row, click_col, event.modifiers, state);
                }
                View::Search => {
                    return handle_search_click(click_row, click_col, state);
                }
                View::Settings => {
                    return handle_settings_click(click_row, click_col, state);
                }
                View::Help => {
                    return handle_help_click(click_row, click_col, state);
                }
                View::Similar => {
                    return handle_similar_click(click_row, click_col, state);
                }
                View::Related => {
                    return handle_related_click(click_row, click_col, state);
                }
            }
        }

        // Right-click — set selection to the row that was right-
        // clicked (so the palette's context-aware entries follow
        // the clicked item, not whatever was previously focused),
        // then open the command palette. Same end result as
        // left-clicking the row to select + typing `:` to bring up
        // the menu, but in one motion. Chrome rows (transport,
        // command bar, tab strip) are skipped — right-clicks there
        // shouldn't pop the palette.
        MouseEventKind::Down(MouseButton::Right) => {
            if click_row >= commands_start || click_row >= transport_start {
                return vec![];
            }
            handle_right_click_select(click_row, click_col, state);
            command_palette::open(state);
            return vec![];
        }

        // Mouse drag - scrollbar drag, seek drag, or volume drag
        MouseEventKind::Drag(MouseButton::Left) => {
            if let Some(grab) = state.miller_h_drag_grab {
                let bar = state.hit_regions.miller_h_scrollbar.clone();
                if let Some(bar) = bar {
                    let max_start = bar.total.saturating_sub(bar.visible);
                    let cursor_within_rail =
                        click_col.saturating_sub(grab).saturating_sub(bar.rail.x);
                    let usable_rail = (bar.rail.width as usize)
                        .saturating_sub(bar.thumb_w as usize)
                        .max(1);
                    let new_start =
                        (cursor_within_rail as usize * max_start + usable_rail / 2) / usable_rail;
                    state.miller_scroll_col = new_start.min(max_start);
                    state.miller_scroll_manual = true;
                    return vec![];
                }
            }
            if state.scroll.scrollbar_drag.is_some() {
                return handle_scrollbar_drag(click_row, state);
            }
            if state.volume_drag {
                return handle_volume_drag(click_col, state);
            }
            if let Some(area) = state.seek_drag {
                return seek_at(click_col, area, state.playback.duration_ms);
            }
        }

        // Mouse up - clear drag state
        MouseEventKind::Up(MouseButton::Left) => {
            let seek = state
                .seek_drag
                .take()
                .map(|area| seek_at(click_col, area, state.playback.duration_ms));
            state.volume_drag = false;
            state.scroll.scrollbar_drag = None;
            state.miller_h_drag_grab = None;
            if let Some(actions) = seek {
                return actions;
            }
        }

        // Scroll wheel
        MouseEventKind::ScrollUp => {
            return handle_scroll(true, click_row, click_col, state);
        }
        MouseEventKind::ScrollDown => {
            return handle_scroll(false, click_row, click_col, state);
        }

        _ => {}
    }

    vec![]
}

/// Resolve the input owner from actual rendered geometry, in split or single view.
fn pointer_view(state: &AppState, column: u16, row: u16) -> View {
    let point = (column, row).into();
    let regions = &state.hit_regions;
    if regions.now_playing_content.as_ref().is_some_and(|r| {
        r.visualizer_tab_area.contains(point) || r.visualizer_content_area.contains(point)
    }) {
        return View::NowPlaying;
    }
    if regions
        .queue_content
        .as_ref()
        .is_some_and(|r| r.track_list.contains(point) || r.art_area.contains(point))
        || regions
            .now_playing_sidebar
            .as_ref()
            .is_some_and(|rows| rows.iter().any(|(r, _)| r.contains(point)))
    {
        return View::Queue;
    }
    if regions
        .tall_mode_split
        .as_ref()
        .is_some_and(|r| r.top.contains(point))
        && matches!(state.view, View::Queue | View::NowPlaying)
    {
        return View::Browse;
    }
    state.view
}

/// Handle mouse events when the library picker popup is active.
fn handle_library_picker_mouse(
    event: crossterm::event::MouseEvent,
    state: &mut AppState,
) -> Vec<Action> {
    use crossterm::event::{MouseButton, MouseEventKind};

    let click_row = event.row;
    let click_col = event.column;

    // Read registered regions (drop borrow before mutating state)
    if matches!(event.kind, MouseEventKind::Down(MouseButton::Left)) {
        let tab = state
            .hit_regions
            .library_manager_tabs
            .iter()
            .find(|(rect, _)| rect.contains(ratatui::layout::Position::new(click_col, click_row)))
            .map(|(_, tab)| *tab);
        if let Some(tab) = tab {
            crate::app::sources::manager::select_tab(state, tab);
            return vec![];
        }
    }
    let regions = {
        let hr = &state.hit_regions;
        hr.library_picker.clone()
    };
    let Some(regions) = regions else {
        return vec![];
    };

    let inside_popup = click_row >= regions.outer.y
        && click_row < regions.outer.bottom()
        && click_col >= regions.outer.x
        && click_col < regions.outer.right();

    match event.kind {
        MouseEventKind::Down(MouseButton::Left) => {
            if inside_popup {
                if regions
                    .items_area
                    .contains(ratatui::layout::Position::new(click_col, click_row))
                {
                    let offset = crate::app::sources::picker_offset(
                        state,
                        regions.items_area.height as usize,
                    );
                    let clicked_idx = offset + (click_row - regions.items_area.y) as usize;

                    if clicked_idx < regions.item_count {
                        let already_highlighted = state.popups.library_picker_index == clicked_idx;
                        if already_highlighted {
                            if let Some(entry) =
                                crate::app::sources::choices(state).get(clicked_idx)
                            {
                                return vec![entry.action()];
                            }
                        } else {
                            // First click: just highlight
                            state.popups.library_picker_index = clicked_idx;
                            state.sources.picker_scroll_pin = Some(offset);
                        }
                    }
                }
            } else {
                return vec![SearchAction::CloseLibraryPicker.into()];
            }
        }
        MouseEventKind::ScrollUp if inside_popup && state.popups.library_picker_index > 0 => {
            state.sources.picker_scroll_pin = None;
            state.popups.library_picker_index -= 1;
        }
        MouseEventKind::ScrollDown
            if inside_popup && state.popups.library_picker_index + 1 < regions.item_count =>
        {
            state.sources.picker_scroll_pin = None;
            state.popups.library_picker_index += 1;
        }
        _ => {}
    }

    vec![]
}

/// Shared: handle a click in the search tab bar area.
/// Returns actions if a tab was clicked, or empty vec otherwise.
fn handle_search_tab_click(rel_col: u16, state: &mut AppState) -> Vec<Action> {
    if state.sources.active.folder().is_some() {
        return vec![];
    }
    let tab_labels = [
        " all ",
        " artists ",
        " albums ",
        " playlists ",
        " tracks ",
        " genres ",
    ];
    if let Some(tab_idx) = tab_hit_test(rel_col, &tab_labels) {
        let new_tab = match tab_idx {
            0 => SearchTab::Global,
            1 => SearchTab::Artists,
            2 => SearchTab::Albums,
            3 => SearchTab::Playlists,
            4 => SearchTab::Tracks,
            _ => SearchTab::Genres,
        };
        state.search.tab = new_tab;
        state.search.focus = crate::app::state::SearchFocus::Input;
        state.list_state.search_item_index = 0;
        state.scroll.search = None;
        if !state.search.query.is_empty() {
            return vec![SearchAction::ExecuteLocalSearch.into()];
        }
    }
    vec![]
}

/// Shared: handle a click in the search results area.
/// Click highlights item. Click on already-highlighted item (if not a rapid double-click) opens in library.
fn handle_search_result_click(
    visual_row: usize,
    results_height: usize,
    state: &mut AppState,
) -> Vec<Action> {
    use crate::services::NavigationService;

    if visual_row >= results_height {
        return vec![];
    }

    let Some(ref results) = state.search.results else {
        return vec![];
    };
    let prev_idx = state.list_state.search_item_index;
    let was_focused = matches!(state.search.focus, crate::app::state::SearchFocus::Results);

    // Check if this is a rapid click (within 500ms) - if so, don't open on second click
    let is_rapid_click = state
        .scroll
        .search_click_time
        .map(|t| t.elapsed().as_millis() < 500)
        .unwrap_or(false);

    match state.search.tab {
        SearchTab::Global => {
            let section_counts = [
                results.artists.len(),
                results.albums.len(),
                results.playlists.len(),
                results.genres.len(),
                results.tracks.len(),
            ];
            let mut entries: Vec<Option<usize>> = Vec::new();
            let mut global_idx: usize = 0;
            for &count in &section_counts {
                if count > 0 {
                    entries.push(None); // section header
                    for _ in 0..count {
                        entries.push(Some(global_idx));
                        global_idx += 1;
                    }
                }
            }
            let display_selected = entries
                .iter()
                .position(|e| *e == Some(state.list_state.search_item_index))
                .unwrap_or(0);
            let scroll_offset = match state.scroll.search {
                Some(pinned) => pinned,
                None => NavigationService::calc_scroll_offset(
                    display_selected,
                    results_height,
                    entries.len(),
                ),
            };
            let abs_row = scroll_offset + visual_row;
            if let Some(Some(idx)) = entries.get(abs_row) {
                let already_selected = was_focused && *idx == prev_idx;
                state.search.focus = crate::app::state::SearchFocus::Results;
                state.list_state.search_item_index = *idx;
                state.scroll.search = Some(scroll_offset);
                state.scroll.search_click_time = Some(std::time::Instant::now());
                // Open in library only if already selected AND not a rapid click
                if already_selected && !is_rapid_click {
                    return vec![SearchAction::SelectSearchResult.into()];
                }
            }
        }
        _ => {
            let total = match state.search.tab {
                SearchTab::Artists => results.artists.len(),
                SearchTab::Albums => results.albums.len(),
                SearchTab::Playlists => results.playlists.len(),
                SearchTab::Tracks => results.tracks.len(),
                SearchTab::Genres => results.genres.len(),
                _ => 0,
            };
            let scroll_offset = match state.scroll.search {
                Some(pinned) => pinned,
                None => NavigationService::calc_scroll_offset(
                    state.list_state.search_item_index,
                    results_height,
                    total,
                ),
            };
            let actual_idx = scroll_offset + visual_row;
            if actual_idx < total {
                let already_selected = was_focused && actual_idx == prev_idx;
                state.search.focus = crate::app::state::SearchFocus::Results;
                state.list_state.search_item_index = actual_idx;
                state.scroll.search = Some(scroll_offset);
                state.scroll.search_click_time = Some(std::time::Instant::now());
                // Open in library only if already selected AND not a rapid click
                if already_selected && !is_rapid_click {
                    return vec![SearchAction::SelectSearchResult.into()];
                }
            }
        }
    }
    vec![]
}

/// Handle mouse click when the search popup is active.
fn handle_search_popup_click(click_row: u16, click_col: u16, state: &mut AppState) -> Vec<Action> {
    // Read registered regions (drop borrow before mutating state)
    let regions = {
        let hr = &state.hit_regions;
        hr.search_popup.clone()
    };
    let Some(regions) = regions else {
        return vec![];
    };

    // Click outside popup → close
    if click_row < regions.outer.y
        || click_row >= regions.outer.bottom()
        || click_col < regions.outer.x
        || click_col >= regions.outer.right()
    {
        state.search.query.clear();
        state.search.results = None;
        state.search.focus = crate::app::state::SearchFocus::Input;
        return vec![SearchAction::CloseSearchPopup.into()];
    }

    // Tab area
    if click_row >= regions.tab_area.y && click_row < regions.tab_area.bottom() {
        let rel_col = click_col.saturating_sub(regions.tab_area.x);
        let actions = handle_search_tab_click(rel_col, state);
        if !actions.is_empty() {
            return actions;
        }
        return vec![];
    }

    // Search input area
    if click_row >= regions.input_area.y && click_row < regions.input_area.bottom() {
        state.search.focus = crate::app::state::SearchFocus::Input;
        return vec![];
    }

    // Results area
    if click_row >= regions.results_area.y && click_row < regions.results_area.bottom() {
        let visual_row = (click_row - regions.results_area.y) as usize;
        let results_height = regions.results_area.height as usize;
        let actions = handle_search_result_click(visual_row, results_height, state);
        return actions;
    }

    vec![]
}

/// Handle click on the top tab bar (navigation tabs).
fn handle_tab_bar_click(click_col: u16, state: &mut AppState) -> Vec<Action> {
    // Read registered regions (drop borrow before mutating state)
    let regions = {
        let hr = &state.hit_regions;
        hr.tab_bar.clone()
    };
    let Some(regions) = regions else {
        return vec![];
    };

    // Click on library name opens library picker
    if let Some(lib_rect) = &regions.library_label {
        if click_col >= lib_rect.x && click_col < lib_rect.right() {
            return vec![SearchAction::OpenLibraryPicker.into()];
        }
    }

    // Click on quit button
    if let Some(quit_rect) = &regions.quit_button {
        if click_col >= quit_rect.x && click_col < quit_rect.right() {
            use crate::app::state::{ConfirmAction, ConfirmDialog};
            state.popups.close_all();
            state.popups.confirm_dialog = Some(ConfirmDialog {
                title: "Quit".to_string(),
                message: "Are you sure you want to quit?".to_string(),
                on_confirm: ConfirmAction::Quit,
                selected_yes: false,
            });
            return vec![];
        }
    }

    // Find which tab was clicked
    for (rect, idx) in &regions.tabs {
        if click_col >= rect.x && click_col < rect.right() {
            return tab_bar_action(*idx, state);
        }
    }

    vec![]
}

/// Handle click on the always-visible command bar (bottom 2 rows).
fn handle_command_bar_click(click_col: u16, state: &mut AppState, is_top_row: bool) -> Vec<Action> {
    use crate::app::handlers::key_input::{available_alt_commands, CommandModifier};

    // Read registered regions (drop borrow before mutating state)
    let regions = {
        let hr = &state.hit_regions;
        hr.command_bar.clone()
    };
    let Some(regions) = regions else {
        return vec![];
    };

    let items = if is_top_row {
        &regions.top_row
    } else {
        &regions.bottom_row
    };

    // Find which command button was clicked
    for (rect, action_key) in items {
        if click_col >= rect.x && click_col < rect.right() {
            let parts: Vec<&str> = action_key.splitn(2, ':').collect();
            if parts.len() != 2 {
                continue;
            }
            let (mod_str, key_str) = (parts[0], parts[1]);

            let alt_cmds = available_alt_commands(state);

            // F-key commands use "fkey:F1" format
            if mod_str == "fkey" {
                for cmd in &alt_cmds {
                    if cmd.display_key == Some(key_str) {
                        if !cmd.enabled {
                            return vec![];
                        }
                        return alt_bar_item_action(cmd, state);
                    }
                }
                return vec![];
            }

            // Modifier+key commands use "ctrl:e" format
            for cmd in &alt_cmds {
                let cmd_mod_str = match cmd.modifier {
                    CommandModifier::Ctrl => "ctrl",
                    CommandModifier::Alt => "alt",
                    CommandModifier::None => "none",
                };
                let cmd_key_str = cmd.key.to_string();
                if cmd_mod_str == mod_str && cmd_key_str == key_str {
                    if !cmd.enabled {
                        return vec![];
                    }
                    return alt_bar_item_action(cmd, state);
                }
            }
        }
    }

    vec![]
}

/// Map a clicked alt bar command to an action.
fn alt_bar_item_action(
    cmd: &crate::app::handlers::key_input::AltCommand,
    state: &mut AppState,
) -> Vec<Action> {
    use crate::app::handlers::key_input::CommandModifier;
    match (cmd.modifier, cmd.key) {
        (CommandModifier::Ctrl, 'e') => vec![QueueAction::EnqueueSelection.into()],
        (CommandModifier::Ctrl, 'm') => super::key_input::get_similar_action(state),
        (CommandModifier::Ctrl, 'j') => super::key_input::navigate_to_album(state),
        (CommandModifier::Ctrl, 's') => vec![QueueAction::PromptSavePlaylist.into()],
        (CommandModifier::Ctrl, 'x') => vec![QueueAction::ClearQueue.into()],
        (CommandModifier::Alt, 'f') => vec![SearchAction::ActivateListFilter.into()],
        (CommandModifier::Alt, 'r') => super::key_input::random_album_radio(state),
        (CommandModifier::Ctrl, 'f') => {
            if state.popups.search_active {
                vec![SearchAction::CloseSearchPopup.into()]
            } else {
                vec![SearchAction::OpenSearchPopup.into()]
            }
        }
        (CommandModifier::Ctrl, 'q') => {
            use crate::app::state::{ConfirmAction, ConfirmDialog};
            state.popups.close_all();
            state.popups.confirm_dialog = Some(ConfirmDialog {
                title: "Quit".to_string(),
                message: "Are you sure you want to quit?".to_string(),
                on_confirm: ConfirmAction::Quit,
                selected_yes: false,
            });
            vec![]
        }
        (CommandModifier::None, _) => {
            // Function keys
            match cmd.display_key {
                Some("F1") => vec![NavigationAction::SetView(View::Help).into()],
                Some("F2") => vec![SettingsAction::OpenSettings.into()],
                Some("F3") => vec![SearchAction::OpenLibraryPicker.into()],
                Some("F4") => {
                    if let Some((artist_key, artist_name)) = helpers::get_artist_for_bio(state) {
                        vec![SearchAction::ShowArtistBio {
                            artist_key,
                            artist_name,
                        }
                        .into()]
                    } else {
                        vec![]
                    }
                }
                Some("F5") => helpers::refresh_current_view(state),
                _ => vec![],
            }
        }
        _ => vec![],
    }
}

/// Return the action for clicking a shortcut bar item (with cycling support).
fn tab_bar_action(idx: usize, _state: &AppState) -> Vec<Action> {
    // Tab indices match the reduced tab bar: 0=Library, 1=Queue, 2=Now Playing
    match idx {
        0 => {
            // Library (Browse view)
            vec![NavigationAction::SetView(View::Browse).into()]
        }
        1 => {
            // Queue
            vec![NavigationAction::SetView(View::Queue).into()]
        }
        2 => {
            // Now Playing (visualizer)
            vec![
                NavigationAction::SetView(View::NowPlaying).into(),
                SystemAction::LoadWaveform.into(),
            ]
        }
        _ => vec![],
    }
}

/// Handle mouse down on the transport bar.
fn handle_transport_down(
    click_col: u16,
    _click_row: u16,
    _transport_start: u16,
    state: &mut AppState,
) -> Vec<Action> {
    // Read registered regions (drop borrow before mutating state)
    let regions = {
        let hr = &state.hit_regions;
        hr.transport.clone()
    };
    let Some(regions) = regions else {
        return vec![];
    };

    // Volume slider click (inline, to the left of speaker icon)
    if let Some(ref slider_rect) = regions.volume_slider {
        if click_col >= slider_rect.x && click_col < slider_rect.right() {
            let relative_pos = click_col - slider_rect.x;
            let vol = (relative_pos as f32 / slider_rect.width as f32).clamp(0.0, 1.0);
            state.volume_slider_until =
                Some(std::time::Instant::now() + std::time::Duration::from_secs(3));
            state.volume_drag = true;
            return vec![PlaybackAction::SetVolume(vol).into()];
        }
    }

    // Speaker icon: toggle volume slider visibility (or mute if already showing)
    if let Some(ref speaker_rect) = regions.speaker_icon {
        if click_col >= speaker_rect.x && click_col < speaker_rect.right() {
            if state
                .volume_slider_until
                .is_some_and(|t| t > std::time::Instant::now())
            {
                // Slider already visible: toggle mute
                return vec![PlaybackAction::ToggleMute.into()];
            } else {
                // Show volume slider
                state.volume_slider_until =
                    Some(std::time::Instant::now() + std::time::Duration::from_secs(5));
                return vec![];
            }
        }
    }

    // Search icon area
    if let Some(ref search_rect) = regions.search_icon {
        if state.view == View::Browse
            && click_col >= search_rect.x
            && click_col < search_rect.right()
        {
            if state.list_filter.active {
                return vec![SearchAction::DeactivateListFilter.into()];
            } else {
                return vec![SearchAction::ActivateListFilter.into()];
            }
        }
    }

    // Play/pause button
    if click_col >= regions.play_pause.x && click_col < regions.play_pause.right() {
        return vec![PlaybackAction::TogglePlayPause.into()];
    }

    // Any point on the scrubber starts a drag, not just the playhead.
    if state.playback.duration_ms > 0
        && click_col >= regions.seekbar.x
        && click_col < regions.seekbar.right()
    {
        state.seek_drag = Some(regions.seekbar);
        return seek_at(click_col, regions.seekbar, state.playback.duration_ms);
    }

    // Previous track button
    if click_col >= regions.prev_track.x && click_col < regions.prev_track.right() {
        return vec![PlaybackAction::Previous.into()];
    }

    // Next track button
    if click_col >= regions.next_track.x && click_col < regions.next_track.right() {
        return vec![PlaybackAction::Next.into()];
    }

    // Track info area: navigate to Now Playing
    if let Some(ref info_rect) = regions.track_info {
        if click_col >= info_rect.x && click_col < info_rect.right() {
            return vec![
                NavigationAction::SetView(View::NowPlaying).into(),
                SystemAction::LoadWaveform.into(),
            ];
        }
    }

    vec![]
}

/// Handle mouse drag on the volume slider.
fn handle_volume_drag(click_col: u16, state: &mut AppState) -> Vec<Action> {
    let slider = {
        let hr = &state.hit_regions;
        hr.transport.as_ref().and_then(|t| t.volume_slider)
    };
    let Some(slider) = slider else { return vec![] };
    // A resize mid-drag can shrink the slider to zero width; 0/0 is NaN.
    if slider.width == 0 {
        return vec![];
    }

    let clamped_col = click_col.max(slider.x).min(slider.x + slider.width);
    let relative_pos = clamped_col - slider.x;
    let vol = (relative_pos as f32 / slider.width as f32).clamp(0.0, 1.0);
    state.volume_slider_until = Some(std::time::Instant::now() + std::time::Duration::from_secs(3));
    vec![PlaybackAction::SetVolume(vol).into()]
}

/// A drag keeps the original horizontal scale even if the pointer leaves its row.
fn seek_at(column: u16, area: Rect, duration_ms: u64) -> Vec<Action> {
    if area.width == 0 || duration_ms == 0 {
        return vec![];
    }
    let last = area.width.saturating_sub(1);
    let offset = column.saturating_sub(area.x).min(last);
    let position = (duration_ms as u128 * offset as u128 / last.max(1) as u128) as u64;
    vec![PlaybackAction::Seek(position).into()]
}

/// Handle the visible visualizer independently of which half has keyboard focus.
fn visualizer_click(column: u16, row: u16, state: &mut AppState) -> Option<Vec<Action>> {
    let regions = state.hit_regions.now_playing_content.as_ref()?;
    let point = ratatui::layout::Position::new(column, row);
    let tabs = regions.visualizer_tab_area;
    let canvas = regions.visualizer_content_area;
    if tabs.contains(point) {
        state.visualizer_tab_focused = true;
        if let Some(tab) = state.visualizer_tab.hit_tab(tabs.width, column - tabs.x) {
            state.visualizer_tab = tab;
        }
        return Some(vec![]);
    }
    if !canvas.contains(point) {
        return None;
    }
    state.visualizer_tab_focused = false;
    if !state.visualizer_tab.allows_canvas_seek() || state.playback.duration_ms == 0 {
        return Some(vec![]);
    }
    state.seek_drag = Some(canvas);
    Some(seek_at(column, canvas, state.playback.duration_ms))
}

// ============================================================================
// Miller Column Hit-Testing
// ============================================================================

/// Compute the full-width Miller column area for the Browse view.
/// Must replicate the layout from AppLayout (30 + remaining = full width).
/// Hit-test a click against a tab bar.
/// Returns Some(tab_index) if the click maps to a tab label.
/// Tab labels should include padding (e.g., " Playlists ").
fn tab_hit_test(click_col: u16, labels: &[&str]) -> Option<usize> {
    let mut x = 0u16;
    let divider_width = 3u16; // " │ "
    for (i, label) in labels.iter().enumerate() {
        let label_width = label.len() as u16;
        if click_col >= x && click_col < x + label_width {
            return Some(i);
        }
        x += label_width;
        if i < labels.len() - 1 {
            x += divider_width;
        }
    }
    None
}

/// Hit-test a click against the title bar (top border row) of Miller columns.
/// Returns Some(col_idx) if the click is on a column's title row.
fn miller_title_hit_test(click_col: u16, click_row: u16, state: &AppState) -> Option<usize> {
    let regions = {
        let hr = &state.hit_regions;
        hr.miller_columns.clone()
    };
    let regions = regions?;

    for col_region in &regions.columns {
        if click_col < col_region.area.x || click_col >= col_region.area.right() {
            continue;
        }
        // Title bar is the top border row: area.y (before inner.y)
        if click_row == col_region.area.y {
            return Some(col_region.col_idx);
        }
    }
    None
}

/// Cycle the sort mode for a specific column (used by title bar click).
/// Cycles through modes only (always ascending): Default → ByTitle → ... → Shuffled → Default.
/// Sorts in-place with no side effects: no truncation, no auto-drill, no focus/selection change.
fn cycle_column_sort(state: &mut AppState, col_idx: usize) -> Vec<Action> {
    use crate::app::state::{BrowseItem, ColumnSortMode, SortColumnType};

    let (current_mode, column_type, saved_selected) = {
        let nav = match state.browse_nav() {
            Some(n) => n,
            None => return vec![],
        };
        let col = match nav.columns.get(col_idx) {
            Some(c) => c,
            None => return vec![],
        };

        let first_item = col.items.first();
        let ct = if first_item.is_some_and(|i| matches!(i, BrowseItem::Artist { .. }))
            || col
                .items
                .iter()
                .take(3)
                .any(|i| matches!(i, BrowseItem::Artist { .. }))
        {
            SortColumnType::Artist
        } else if first_item.is_some_and(|i| matches!(i, BrowseItem::Album { .. }))
            || col
                .items
                .iter()
                .take(4)
                .any(|i| matches!(i, BrowseItem::Album { .. }))
        {
            SortColumnType::Album
        } else if first_item.is_some_and(|i| matches!(i, BrowseItem::Track { .. })) {
            if state.is_special_track_column(nav, col_idx) {
                SortColumnType::AllTracks
            } else {
                SortColumnType::Track
            }
        } else {
            return vec![];
        };

        (col.sort_mode, ct, col.selected_index)
    };

    let modes = match column_type {
        SortColumnType::Artist => vec![ColumnSortMode::Default, ColumnSortMode::Shuffled],
        SortColumnType::Album => vec![
            ColumnSortMode::Default,
            ColumnSortMode::ByTitle,
            ColumnSortMode::ByArtist,
            ColumnSortMode::Shuffled,
        ],
        SortColumnType::Track => vec![
            ColumnSortMode::Default,
            ColumnSortMode::ByTitle,
            ColumnSortMode::ByDuration,
            ColumnSortMode::Shuffled,
        ],
        SortColumnType::AllTracks => vec![
            ColumnSortMode::Default,
            ColumnSortMode::ByArtist,
            ColumnSortMode::ByAlbum,
            ColumnSortMode::ByTitle,
            ColumnSortMode::ByDuration,
            ColumnSortMode::Shuffled,
        ],
    };

    // Find current position and advance to next mode
    let current_pos = modes.iter().position(|m| *m == current_mode).unwrap_or(0);
    let next_mode = modes[(current_pos + 1) % modes.len()];

    // Sort in-place — no truncation, no auto-drill, no focus change
    let nav = match state.browse_nav_mut() {
        Some(n) => n,
        None => return vec![],
    };
    if let Some(col) = nav.columns.get_mut(col_idx) {
        if col.has_originals() && next_mode != ColumnSortMode::Shuffled {
            col.unshuffle();
        }
        col.apply_sort(next_mode);
        if next_mode != ColumnSortMode::Shuffled && next_mode != ColumnSortMode::Default {
            col.clear_originals();
        }
        // Restore selection — header click only changes sort order
        col.selected_index = saved_selected.min(col.items.len().saturating_sub(1));
    }

    vec![]
}

/// Detect a click on the synthetic "▶ Play …" row pinned at the top
/// of an album / playlist / all-tracks column. Returns
/// `Some(col_idx)` when the click maps to that row. The caller
/// dispatches the matching `QueueAction::Play…` and skips the
/// regular miller hit-test so the click isn't double-handled as a
/// click on item 0 below the play row.
fn play_row_hit_test(
    click_col: u16,
    click_row: u16,
    nav: &BrowseNavigationState,
    state: &AppState,
) -> Option<usize> {
    let regions = state.hit_regions.miller_columns.clone()?;
    for col_region in &regions.columns {
        let col_idx = col_region.col_idx;
        let col = nav.columns.get(col_idx)?;
        if col.play_all_row.is_none() {
            continue;
        }
        if click_col < col_region.area.x || click_col >= col_region.area.right() {
            continue;
        }
        // The play row is the first inner line of the column.
        if click_row == col_region.inner.y {
            return Some(col_idx);
        }
    }
    None
}

/// Hit-test a click against Miller column layout for BrowseNavigationState.
/// Returns Some((col_idx, item_idx, scroll_offset)) if the click maps to an item.
/// item_idx is always an index into the full col.items list (mapped through
/// matched_indices when the list filter is active on the clicked column).
fn miller_hit_test(
    click_col: u16,
    click_row: u16,
    nav: &BrowseNavigationState,
    state: &AppState,
) -> Option<(usize, usize, usize)> {
    // Read registered Miller column regions
    let regions = {
        let hr = &state.hit_regions;
        hr.miller_columns.clone()
    };
    let regions = regions?;

    // Check overall area bounds
    if click_row < regions.area.y || click_row >= regions.area.bottom() {
        return None;
    }
    if click_col < regions.area.x || click_col >= regions.area.right() {
        return None;
    }

    // Check if filter is active on this category
    let filter_active =
        state.list_filter.active && state.list_filter.category == state.browse_category;

    // Find which registered column was clicked
    for col_region in &regions.columns {
        let col_idx = col_region.col_idx;
        if col_idx >= nav.columns.len() {
            continue;
        }

        if click_col < col_region.area.x || click_col >= col_region.area.right() {
            continue;
        }

        let col = &nav.columns[col_idx];
        if col.items.is_empty() {
            return None;
        }

        // Synthetic "▶ Play …" row pinned at the top of tracks
        // columns occupies the first inner line. Shift the item
        // area down by one so a click on the play row is *not*
        // mistaken for item 0, and clicks below the play row map
        // to their real positions. The dedicated
        // `play_row_hit_test` runs ahead of this function and
        // catches play-row clicks before we get here.
        let play_row_shift = col.play_all_row.is_some() as u16;
        let inner_y = col_region.inner.y + play_row_shift;
        let inner_height = col_region.inner.height.saturating_sub(play_row_shift);

        if click_row < inner_y || click_row >= inner_y + inner_height {
            return None;
        }

        let click_offset = (click_row - inner_y) as usize;

        // Use pinned scroll offset if set for this column
        let pinned = state
            .scroll
            .browse
            .and_then(|(pc, po)| if pc == col_idx { Some(po) } else { None });

        // Check if this column has artwork_visible enabled
        if col.artwork_visible {
            // Cover art mode: mixed row heights (one-row pinned items vs art-height items).
            // Pull the art_row_height the renderer actually used out of the
            // hit-region — recomputing here used to drift from the renderer
            // and made clicks land on the album below the one clicked on.
            let total_items = col.items.len();
            let art_row_height = col_region.art_row_height.max(1) as usize;

            // Spacer at any one-row ↔ art-height boundary so clicks
            // map correctly regardless of whether pinned rows live
            // at the top or the bottom of the column.
            let has_spacer_after = |idx: usize| -> bool {
                idx + 1 < total_items
                    && is_one_row_item(&col.items[idx]) != is_one_row_item(&col.items[idx + 1])
            };

            // Compute visible count and scroll offset with mixed heights
            let count_visible = |offset: usize| -> usize {
                let mut y = 0usize;
                let mut count = 0;
                for i in offset..total_items {
                    let h = if is_one_row_item(&col.items[i]) {
                        1
                    } else {
                        art_row_height
                    };
                    let spacer = if has_spacer_after(i) { 1 } else { 0 };
                    if y + h + spacer > inner_height as usize {
                        break;
                    }
                    y += h + spacer;
                    count += 1;
                }
                count
            };

            let scroll_offset = if let Some(p) = pinned {
                p
            } else {
                let mut offset = 0;
                loop {
                    let visible = count_visible(offset);
                    if visible == 0 {
                        break;
                    }
                    if col.selected_index >= offset && col.selected_index < offset + visible {
                        break;
                    }
                    if col.selected_index < offset {
                        offset = col.selected_index;
                        break;
                    }
                    offset += 1;
                }
                offset
            };

            // Walk through visible items to find which one was clicked
            let mut y = 0usize;
            for i in scroll_offset..total_items {
                let h = if is_one_row_item(&col.items[i]) {
                    1
                } else {
                    art_row_height
                };
                if y + h > inner_height as usize {
                    break;
                }
                if click_offset >= y && click_offset < y + h {
                    return Some((col_idx, i, scroll_offset));
                }
                y += h;
                if has_spacer_after(i) {
                    y += 1;
                }
            }
        } else if filter_active
            && state.list_filter.column == col_idx
            && state.list_filter.results.is_some()
        {
            // Filtered mode: only matched items are shown
            if let Some(ref results) = state.list_filter.results {
                if results.matched_indices.is_empty() {
                    return None;
                }
                let total_display = results.matched_indices.len();
                let visible_height = inner_height as usize;

                // display_selected_idx = position of col.selected_index in matched list
                let display_selected = results
                    .matched_indices
                    .iter()
                    .position(|&idx| idx == col.selected_index)
                    .unwrap_or(0);
                let scroll_offset = pinned.unwrap_or_else(|| {
                    helpers::calc_scroll_offset(display_selected, visible_height, total_display)
                });
                let display_idx = scroll_offset + click_offset;

                if display_idx < total_display {
                    // Map through matched_indices to get actual item index
                    return Some((col_idx, results.matched_indices[display_idx], scroll_offset));
                }
            }
            return None;
        } else {
            // Check if this column uses 2-row display
            let is_two_row = is_two_row_browse_column(state, col, col_idx, nav);
            let rows_per_item = if is_two_row { 2 } else { 1 };

            let total_items = col.items.len();
            let visible_height = inner_height as usize;
            let visible_item_count = visible_height / rows_per_item;
            let scroll_offset = pinned.unwrap_or_else(|| {
                helpers::calc_scroll_offset(col.selected_index, visible_item_count, total_items)
            });
            let item_idx = scroll_offset + click_offset / rows_per_item;

            if item_idx < total_items {
                return Some((col_idx, item_idx, scroll_offset));
            }
        }

        return None;
    }

    None
}

/// Hit-test a click against Miller column layout for FolderNavigationState.
fn folder_hit_test(
    click_col: u16,
    click_row: u16,
    state: &AppState,
) -> Option<(usize, usize, usize)> {
    let folder_state = state.folder_state.as_ref()?;

    // Read registered Miller column regions
    let regions = {
        let hr = &state.hit_regions;
        hr.miller_columns.clone()
    };
    let regions = regions?;

    if click_row < regions.area.y || click_row >= regions.area.bottom() {
        return None;
    }

    for col_region in &regions.columns {
        let col_idx = col_region.col_idx;
        if col_idx >= folder_state.columns.len() {
            continue;
        }

        if click_col < col_region.area.x || click_col >= col_region.area.right() {
            continue;
        }

        let col = &folder_state.columns[col_idx];
        if col.items.is_empty() {
            return None;
        }

        let inner_y = col_region.inner.y;
        let inner_height = col_region.inner.height;

        if click_row < inner_y || click_row >= inner_y + inner_height {
            return None;
        }

        let click_offset = (click_row - inner_y) as usize;
        let visible_height = inner_height as usize;

        // Use pinned scroll offset if set for this column
        let pinned = state
            .scroll
            .browse
            .and_then(|(pc, po)| if pc == col_idx { Some(po) } else { None });

        // Check if filter is active on this folder column with actual results
        let filter_on_col = state.list_filter.active
            && state.list_filter.category == BrowseCategory::Folders
            && state.list_filter.column == col_idx
            && state.list_filter.results.is_some();

        if filter_on_col {
            if let Some(ref results) = state.list_filter.results {
                if results.matched_indices.is_empty() {
                    return None;
                }
                let total_display = results.matched_indices.len();
                let display_selected = results
                    .matched_indices
                    .iter()
                    .position(|&idx| idx == col.selected_index)
                    .unwrap_or(0);
                let scroll_offset = pinned.unwrap_or_else(|| {
                    helpers::calc_scroll_offset(display_selected, visible_height, total_display)
                });
                let display_idx = scroll_offset + click_offset;
                if display_idx < total_display {
                    return Some((col_idx, results.matched_indices[display_idx], scroll_offset));
                }
            }
            return None;
        }

        let total_items = col.items.len();
        let scroll_offset = pinned.unwrap_or_else(|| {
            helpers::calc_scroll_offset(col.selected_index, visible_height, total_items)
        });
        let item_idx = scroll_offset + click_offset;

        if item_idx < total_items {
            return Some((col_idx, item_idx, scroll_offset));
        }

        return None;
    }

    None
}

/// Identify which Miller column the cursor is over (for scroll events).
/// Returns the column index, or None if not over a column.
fn miller_column_at(
    click_col: u16,
    _nav: &BrowseNavigationState,
    state: &AppState,
) -> Option<usize> {
    let miller = {
        let hr = &state.hit_regions;
        hr.miller_columns.clone()
    };
    let mr = miller?;

    for col_reg in &mr.columns {
        if click_col >= col_reg.area.x && click_col < col_reg.area.right() {
            return Some(col_reg.col_idx);
        }
    }

    None
}

// ============================================================================
// Browse Click Handlers
// ============================================================================

/// Move selection to the row that was right-clicked, without
/// drilling. Used by the right-click → palette path so the palette's
/// context-aware entries (Play Track / Open in Library / Artist Bio
/// / etc.) target the row the user actually right-clicked, not
/// whatever was previously focused. Silent no-op outside Browse +
/// Queue + NowPlaying — those are the views with click-targeted
/// rows whose state.palette can sensibly act on.
fn handle_right_click_select(click_row: u16, click_col: u16, state: &mut AppState) {
    match state.view {
        View::Browse => {
            // Track-details pane: right-clicking a similar-track row
            // should target THAT row in the palette (so "Open in
            // Library" surfaces as a top entry — similar rows always
            // get it, even when the user is in Library view). Without
            // this, the right-click only updates a miller-column
            // selection and the palette ends up targeting the parent
            // miller row instead.
            {
                let pane = state.hit_regions.track_pane.clone();
                if let Some(pane) = pane {
                    // Click on the play button → focus pane on Play
                    // (track_pane_index = 0 = parent track).
                    if click_row == pane.play_button.y
                        && click_col >= pane.play_button.x
                        && click_col < pane.play_button.x + pane.play_button.width
                    {
                        state.track_pane_focused = true;
                        state.track_pane_index = 0;
                        state.category_column_focused = false;
                        return;
                    }
                    // Click on a similar-track row → focus pane on
                    // that row.
                    for (row_rect, sim_idx) in &pane.similar_rows {
                        if click_row == row_rect.y
                            && click_col >= row_rect.x
                            && click_col < row_rect.x + row_rect.width
                        {
                            state.track_pane_focused = true;
                            state.track_pane_index = *sim_idx + 1;
                            state.category_column_focused = false;
                            return;
                        }
                    }
                }
            }

            // Folders + Library/Genres/Playlists use different
            // navigation state shapes. Try each in turn until a hit.
            match state.browse_category {
                BrowseCategory::Folders => {
                    if let Some((col_idx, item_idx, scroll)) =
                        folder_hit_test(click_col, click_row, state)
                    {
                        state.scroll.browse = Some((col_idx, scroll));
                        if let Some(ref mut fs) = state.folder_state {
                            if let Some(col) = fs.columns.get_mut(col_idx) {
                                col.selected_index = item_idx;
                            }
                            fs.focused_column = col_idx;
                        }
                        state.category_column_focused = false;
                        state.track_pane_focused = false;
                    }
                }
                _ => {
                    let nav_view: BrowseNavigationState = match state.browse_category {
                        BrowseCategory::Library => state.artist_nav.clone(),
                        BrowseCategory::Playlists => state.playlist_nav.clone(),
                        BrowseCategory::Folders => return,
                        cat if cat.is_tag_section() => state.tag_nav.clone(),
                        _ => return,
                    };
                    if let Some((col_idx, item_idx, scroll)) =
                        miller_hit_test(click_col, click_row, &nav_view, state)
                    {
                        state.scroll.browse = Some((col_idx, scroll));
                        let nav = match state.browse_category {
                            BrowseCategory::Library => &mut state.artist_nav,
                            BrowseCategory::Playlists => &mut state.playlist_nav,
                            BrowseCategory::Folders => return,
                            cat if cat.is_tag_section() => &mut state.tag_nav,
                            _ => return,
                        };
                        if let Some(col) = nav.columns.get_mut(col_idx) {
                            col.selected_index = item_idx;
                        }
                        nav.focused_column = col_idx;
                        state.category_column_focused = false;
                        // A right-click on a miller row implies the
                        // target is that row, not whatever was in the
                        // pane before — clear pane focus so the
                        // palette's target_track resolves to the
                        // miller selection.
                        state.track_pane_focused = false;
                    }
                }
            }
        }
        View::Queue | View::NowPlaying => {
            // Queue rows: right-click targets the queue row at the
            // click's y-offset within the queue track list region.
            // The palette doesn't currently surface queue-row-
            // specific entries, but updating queue_index keeps
            // future "selected queue track" actions consistent.
            let queue_region = state.hit_regions.queue_content.clone();
            if let Some(region) = queue_region {
                let area = region.track_list_inner;
                if click_col >= area.x
                    && click_col < area.x + area.width
                    && click_row >= area.y
                    && click_row < area.y + area.height
                {
                    let row_offset = (click_row - area.y) as usize;
                    let track_count = match state.playback_mode {
                        PlaybackMode::Radio => state.radio.tracks.len(),
                        _ => state.queue.tracks.len(),
                    };
                    let visible = area.height as usize / 2;
                    let scroll = state.scroll.queue.unwrap_or_else(|| {
                        helpers::calc_scroll_offset(
                            state.list_state.queue_index,
                            visible,
                            track_count,
                        )
                    });
                    let target = scroll + row_offset / 2;
                    if target < track_count {
                        state.scroll.queue = Some(scroll);
                        state.list_state.queue_index = target;
                        state.now_playing_focus = crate::app::state::NowPlayingFocus::Tracks;
                    }
                }
            }
        }
        _ => {}
    }
}

/// Handle click in Browse view using Miller column hit-testing.
fn handle_browse_click(click_row: u16, click_col: u16, state: &mut AppState) -> Vec<Action> {
    // Check category column click first. The leftmost column renders
    // every CategoryRow at its index — the click's y-offset maps
    // directly to a CategoryRow index. Divider rows ignore clicks.
    {
        let hr = &state.hit_regions;
        if let Some(ref cat_region) = hr.category_column {
            if click_col >= cat_region.inner.x
                && click_col < cat_region.inner.x + cat_region.inner.width
                && click_row >= cat_region.inner.y
                && click_row < cat_region.inner.y + cat_region.inner.height
            {
                let item_idx = cat_region.scroll_offset + (click_row - cat_region.inner.y) as usize;
                state.scroll.category = Some(cat_region.scroll_offset);
                if item_idx < cat_region.item_count {
                    let rows = state.category_rows();
                    return match rows.get(item_idx).copied() {
                        Some(crate::app::state::CategoryRow::NavidromeCollection(kind)) => {
                            state.category_column_focused = false;
                            state.category_column_index = item_idx;
                            vec![kind.action()]
                        }
                        Some(crate::app::state::CategoryRow::Category(cat)) => {
                            vec![NavigationAction::set_category(cat).into()]
                        }
                        Some(crate::app::state::CategoryRow::Playlist(i)) => {
                            let Some(p) = state.library.playlists.get(i) else {
                                return vec![];
                            };
                            let key = p.rating_key.clone();
                            let title = p.title.clone();
                            state.set_browse_category(BrowseCategory::Playlists, false);
                            if let Some(col) = state.playlist_nav.columns.get_mut(0) {
                                if let Some(idx) =
                                    col.items.iter().position(|it| it.key() == key.as_str())
                                {
                                    col.selected_index = idx;
                                }
                            }
                            state.playlist_nav.focused_column = 0;
                            state.playlist_nav.truncate_right();
                            state.library.selected_album_title = title;
                            state.category_column_focused = false;
                            state.category_column_index = item_idx;
                            vec![MillerAction::LoadPlaylistTracksForMiller {
                                playlist_key: key,
                                replace_child: false,
                            }
                            .into()]
                        }
                        Some(crate::app::state::CategoryRow::Search) => {
                            state.category_column_index = item_idx;
                            vec![SearchAction::OpenSearchPopup.into()]
                        }
                        Some(crate::app::state::CategoryRow::Header(_)) | None => vec![],
                    };
                }
            }
        }
    }

    // Alphabet strip click: jump the artist root column to the row
    // whose sort key starts with the clicked letter. Pure scroll
    // action — does not change the focused Miller column.
    {
        let strip = state.hit_regions.alphabet_strip.clone();
        if let Some(strip) = strip {
            for (cell, letter_idx) in &strip.letters {
                if click_row == cell.y && click_col >= cell.x && click_col < cell.x + cell.width {
                    let ch = crate::app::handlers::helpers::ALPHABET_STRIP_LETTERS
                        .get(*letter_idx)
                        .copied();
                    if let Some(ch) = ch {
                        let _ = crate::app::handlers::helpers::alphabet_jump(state, ch);
                        state.alphabet_strip_focused = true;
                        state.alphabet_strip_index = *letter_idx;
                    }
                    return vec![];
                }
            }
        }
    }

    // Track-details pane click: close-x + Play button + similar-track rows.
    // Checked before the miller hit-test so a click that lands on
    // the pane's column doesn't fall through to a miller-col selection.
    {
        let pane = state.hit_regions.track_pane.clone();
        if let Some(pane) = pane {
            // Close-x glyph in the top-right corner.
            if let Some(close) = pane.close_x {
                if click_row >= close.y
                    && click_row < close.y + close.height
                    && click_col >= close.x
                    && click_col < close.x + close.width
                {
                    state.track_pane_open = false;
                    state.track_pane_focused = false;
                    state.track_pane_index = 0;
                    return vec![];
                }
            }
            // Play Track button
            if click_row == pane.play_button.y
                && click_col >= pane.play_button.x
                && click_col < pane.play_button.x + pane.play_button.width
            {
                if let Some(track) = state.focused_track().cloned() {
                    state.track_pane_focused = true;
                    state.track_pane_index = 0;
                    return vec![QueueAction::PlayTrack(Box::new(track)).into()];
                }
            }
            // Sonically Similar rows: first click highlights only;
            // a second click on the same row (or pressing Enter on
            // the focused similar row) drills into the track's
            // album in the Library. Mirrors the click-on-highlighted
            // = Enter rule used everywhere else, and surfaces the
            // full palette of context commands (Play Track / Play
            // Track and Following / Open in Library / Artist Bio /
            // Search Apple Music…) for users who right-click on a
            // newly-highlighted similar row.
            for (row_rect, sim_idx) in &pane.similar_rows {
                if click_row == row_rect.y
                    && click_col >= row_rect.x
                    && click_col < row_rect.x + row_rect.width
                {
                    // `track_pane_index = 0` is the Play button;
                    // similar rows occupy indices 1..=N.
                    let new_pane_idx = *sim_idx + 1;
                    let was_selected =
                        state.track_pane_focused && state.track_pane_index == new_pane_idx;
                    state.track_pane_focused = true;
                    state.track_pane_index = new_pane_idx;
                    if !was_selected {
                        return vec![];
                    }
                    // Already selected → open the command palette so
                    // the user picks an action (Play Track / Open in
                    // Library / Artist Bio / Sonic Adventure / external
                    // search…). The palette's contextual section
                    // targets the highlighted similar row via
                    // `palette_target_track()`.
                    crate::app::command_palette::open(state);
                    return vec![];
                }
            }
            // Click anywhere else inside the pane just focuses it
            // (no action). Lets the user "tab into" the pane via
            // mouse.
            if click_row >= pane.outer.y
                && click_row < pane.outer.y + pane.outer.height
                && click_col >= pane.outer.x
                && click_col < pane.outer.x + pane.outer.width
            {
                state.track_pane_focused = true;
                return vec![];
            }
        }
    }

    // Check scrollbar click first (before item selection)
    match state.browse_category {
        BrowseCategory::Folders => {
            if let Some(actions) = try_folder_scrollbar_click(click_col, click_row, state) {
                return actions;
            }
        }
        cat if !matches!(cat, BrowseCategory::Folders) => {
            if let Some(actions) = try_browse_scrollbar_click(click_col, click_row, state) {
                return actions;
            }
        }
        _ => {}
    }

    match state.browse_category {
        BrowseCategory::Folders => {
            return handle_folder_click(click_row, click_col, state);
        }
        cat if !matches!(cat, BrowseCategory::Folders) => {
            // All use BrowseNavigationState
            let nav = match state.browse_category {
                BrowseCategory::Library => &state.artist_nav,
                cat if cat.is_tag_section() => &state.tag_nav,
                BrowseCategory::Playlists => &state.playlist_nav,
                _ => unreachable!(),
            };

            // Check if click is on the column's "x" close glyph
            // (top-right corner). Closes the column and every column
            // to its right.
            {
                let close_target = state.hit_regions.miller_columns.as_ref().and_then(|m| {
                    m.columns
                        .iter()
                        .find(|c| {
                            c.close_x
                                .map(|r| {
                                    click_col >= r.x
                                        && click_col < r.x + r.width
                                        && click_row >= r.y
                                        && click_row < r.y + r.height
                                })
                                .unwrap_or(false)
                        })
                        .map(|c| c.col_idx)
                });
                if let Some(col_idx) = close_target {
                    crate::app::handlers::key_input::close_browse_column_at(state, col_idx);
                    return vec![];
                }
            }

            // Check if click is on a column title bar (border row)
            if let Some(col_idx) = miller_title_hit_test(click_col, click_row, state) {
                // Cycle to the next sort mode for this column
                return cycle_column_sort(state, col_idx);
            }

            // Click on the synthetic "▶ Play …" row: focus the
            // column, park the cursor on the play row, and play
            // the album / playlist / track list. Single click acts
            // as a button — there's no two-step "select then drill"
            // here because the row's whole purpose is the action.
            if let Some(col_idx) = play_row_hit_test(click_col, click_row, nav, state) {
                let nav_mut = match state.browse_category {
                    BrowseCategory::Library => &mut state.artist_nav,
                    cat if cat.is_tag_section() => &mut state.tag_nav,
                    BrowseCategory::Playlists => &mut state.playlist_nav,
                    _ => return vec![],
                };
                nav_mut.focused_column = col_idx;
                let Some(col) = nav_mut.columns.get_mut(col_idx) else {
                    return vec![];
                };
                col.on_play_row = true;
                let Some(row) = col.play_all_row.clone() else {
                    return vec![];
                };
                let tracks = col.tracks.clone();
                state.category_column_focused = false;
                state.track_pane_focused = false;
                use crate::app::state::PlayAllRow;
                let action: Action = match row {
                    PlayAllRow::Album { rating_key, title } => {
                        QueueAction::PlayAlbumNow { rating_key, title }.into()
                    }
                    PlayAllRow::Playlist { rating_key, title } => QueueAction::PlayPlaylistNow {
                        playlist_key: rating_key,
                        title,
                    }
                    .into(),
                    PlayAllRow::AllTracks { .. } => QueueAction::PlayTracksNow(tracks).into(),
                };
                return vec![action];
            }

            if let Some((col_idx, item_idx, scroll_offset)) =
                miller_hit_test(click_col, click_row, nav, state)
            {
                // Double-click detection: same (col_idx, item_idx) clicked twice within 400ms.
                // Checked BEFORE column-focus changes, since a drill from the first click
                // may shift focused_column before the second click arrives.
                let is_double_click = state.scroll.browse_last_click == Some((col_idx, item_idx))
                    && state
                        .scroll
                        .browse_click_time
                        .map(|t| t.elapsed().as_millis() < 400)
                        .unwrap_or(false);

                if is_double_click {
                    // Look up the item and try a double-click play action
                    let item = {
                        let nav = match state.browse_category {
                            BrowseCategory::Library => &state.artist_nav,
                            cat if cat.is_tag_section() => &state.tag_nav,
                            BrowseCategory::Playlists => &state.playlist_nav,
                            _ => return vec![],
                        };
                        nav.columns
                            .get(col_idx)
                            .and_then(|c| c.items.get(item_idx))
                            .cloned()
                    };
                    if let Some(ref item) = item {
                        if let Some(actions) = browse_double_click_action(item, state) {
                            state.scroll.browse_last_click = None; // consume the double-click
                            return actions;
                        }
                    }
                }

                // Record this click for future double-click detection
                state.scroll.browse_last_click = Some((col_idx, item_idx));

                // Check if this click is on a column with an active filter
                let filter_on_click_col = state.list_filter.active
                    && state.list_filter.category == state.browse_category
                    && state.list_filter.column == col_idx
                    && state.list_filter.results.is_some();

                let nav = match state.browse_category {
                    BrowseCategory::Library => &mut state.artist_nav,
                    cat if cat.is_tag_section() => &mut state.tag_nav,
                    BrowseCategory::Playlists => &mut state.playlist_nav,
                    _ => unreachable!(),
                };

                // Update focus and selection
                state.scroll.browse = Some((col_idx, scroll_offset));
                state.scroll.browse_click_time = Some(std::time::Instant::now());

                if col_idx != nav.focused_column {
                    nav.focused_column = col_idx;
                    if state.list_filter.active {
                        state.list_filter.deactivate();
                    }
                }

                // Click on an item below the play row → the cursor
                // is explicitly moving to an item, so the synthetic
                // play row should release the highlight.
                if let Some(col) = nav.columns.get_mut(col_idx) {
                    col.on_play_row = false;
                }

                let col_sel = nav
                    .columns
                    .get(col_idx)
                    .map(|c| c.selected_index)
                    .unwrap_or(0);
                if filter_on_click_col {
                    let drill = handle_filtered_column_click(
                        state,
                        col_idx,
                        item_idx,
                        scroll_offset,
                        col_sel,
                    );
                    let nav_mut = match state.browse_category {
                        BrowseCategory::Library => &mut state.artist_nav,
                        cat if cat.is_tag_section() => &mut state.tag_nav,
                        BrowseCategory::Playlists => &mut state.playlist_nav,
                        _ => return vec![],
                    };
                    if let Some(col) = nav_mut.columns.get_mut(col_idx) {
                        col.selected_index = item_idx;
                    }
                    if !drill {
                        return vec![];
                    }
                    // Filtered click that drills: fall through to the
                    // shared drill service with `activate=true` so the
                    // service's match arm fires regardless of the
                    // sticky "leaf row drills on first click" rule
                    // already enforced by the filter handler.
                }

                // Click on the already-selected row should be treated
                // as a double-click (Enter equivalent). The shared
                // service uses `activate` for that semantic; we
                // promote `was_selected` into `activate` so the
                // existing TUI behaviour (click-on-highlighted =
                // drill) carries through.
                let was_selected = match state.browse_category {
                    BrowseCategory::Library => state.artist_nav.columns.get(col_idx),
                    cat if cat.is_tag_section() => state.tag_nav.columns.get(col_idx),
                    BrowseCategory::Playlists => state.playlist_nav.columns.get(col_idx),
                    _ => None,
                }
                .is_some_and(|c| c.selected_index == item_idx);

                let plan = crate::services::plan_drill(
                    state,
                    crate::services::ClickContext {
                        column_index: col_idx,
                        item_index: item_idx,
                        activate: was_selected || filter_on_click_col,
                    },
                );
                return plan.actions;
            }
        }
        _ => {}
    }

    vec![]
}

/// Handle double-click on a browse item: play immediately instead of drilling.
/// Returns Some(actions) if the item type supports double-click play, None otherwise (fall through to drill).
fn browse_double_click_action(item: &BrowseItem, _state: &mut AppState) -> Option<Vec<Action>> {
    match item {
        BrowseItem::Artist { .. } => {
            // Double-click artist → no special action, fall through to drill
            None
        }
        BrowseItem::Album { key, title, .. } => {
            // Double-click album → play album now
            Some(vec![QueueAction::PlayAlbumNow {
                rating_key: key.clone(),
                title: title.clone(),
            }
            .into()])
        }
        BrowseItem::Playlist { key, title, .. } => {
            // Double-click playlist → play playlist now
            Some(vec![QueueAction::PlayPlaylistNow {
                playlist_key: key.clone(),
                title: title.clone(),
            }
            .into()])
        }
        BrowseItem::ArtistRadio {
            artist_key,
            artist_name,
            ..
        } => {
            // Double-click ArtistRadio entry → start radio
            Some(vec![RadioAction::StartArtistRadio {
                key: artist_key.clone(),
                title: artist_name.clone(),
            }
            .into()])
        }
        BrowseItem::Genre { .. } => {
            // Fall through to drill — playing all genre tracks is complex
            None
        }
        _ => None,
    }
}

/// Handle click in Folder browse mode.
fn handle_folder_click(click_row: u16, click_col: u16, state: &mut AppState) -> Vec<Action> {
    use crate::services::FolderItemType;

    // "x" close-column glyph (top-right corner of every drilled-in
    // column). Closes the column and every column to its right.
    {
        let close_target = state.hit_regions.miller_columns.as_ref().and_then(|m| {
            m.columns
                .iter()
                .find(|c| {
                    c.close_x
                        .map(|r| {
                            click_col >= r.x
                                && click_col < r.x + r.width
                                && click_row >= r.y
                                && click_row < r.y + r.height
                        })
                        .unwrap_or(false)
                })
                .map(|c| c.col_idx)
        });
        if let Some(col_idx) = close_target {
            crate::app::handlers::key_input::close_browse_column_at(state, col_idx);
            return vec![];
        }
    }

    if let Some((col_idx, item_idx, scroll_offset)) = folder_hit_test(click_col, click_row, state) {
        // Double-click detection (before column-focus changes)
        let is_double_click = state.scroll.browse_last_click == Some((col_idx, item_idx))
            && state
                .scroll
                .browse_click_time
                .map(|t| t.elapsed().as_millis() < 400)
                .unwrap_or(false);

        if is_double_click {
            if let Some(item) = state
                .folder_state
                .as_ref()
                .and_then(|fs| fs.columns.get(col_idx))
                .and_then(|c| c.items.get(item_idx))
                .cloned()
            {
                state.scroll.browse_last_click = None;
                match item.item_type {
                    FolderItemType::Folder => {
                        // Double-click folder → play all tracks in it
                        return vec![FolderAction::PlayFolderTracks.into()];
                    }
                    FolderItemType::Track => {
                        // Double-click track → play track + following (matches library behavior)
                        return vec![FolderAction::PlayFolderTracks.into()];
                    }
                }
            }
        }

        state.scroll.browse_last_click = Some((col_idx, item_idx));

        let filter_on_click_col = state.list_filter.active
            && state.list_filter.category == BrowseCategory::Folders
            && state.list_filter.column == col_idx
            && state.list_filter.results.is_some();

        let Some(folder_state) = state.folder_state.as_mut() else {
            return vec![];
        };

        // Clicking a different column: change focus only. Selection-only —
        // truncate stale child columns and let the user press Enter/Right
        // to drill.
        if col_idx != folder_state.focused_column {
            state.scroll.browse = Some((col_idx, scroll_offset));
            state.scroll.browse_click_time = Some(std::time::Instant::now());
            folder_state.focused_column = col_idx;
            if let Some(col) = folder_state.columns.get_mut(col_idx) {
                col.selected_index = item_idx;
            }
            folder_state.truncate_right_columns();
            if state.list_filter.active {
                state.list_filter.deactivate();
            }
            return vec![];
        }

        // Determine if this click should drill down or just select
        let col_sel = folder_state
            .columns
            .get(col_idx)
            .map(|c| c.selected_index)
            .unwrap_or(0);
        let should_drill = if filter_on_click_col {
            let drill =
                handle_filtered_column_click(state, col_idx, item_idx, scroll_offset, col_sel);
            if let Some(ref mut fs) = state.folder_state {
                if let Some(col) = fs.columns.get_mut(col_idx) {
                    col.selected_index = item_idx;
                }
            }
            drill
        } else {
            state.scroll.browse = Some((col_idx, scroll_offset));
            state.scroll.browse_click_time = Some(std::time::Instant::now());
            // Selection-only on click by default. Drill when the
            // user clicks the already-highlighted row (= Enter) OR
            // when a rightward column is already open (committed
            // drill, refresh from new selection).
            let mut should_drill = false;
            if let Some(ref mut fs) = state.folder_state {
                let was_selected = fs
                    .columns
                    .get(col_idx)
                    .is_some_and(|c| c.selected_index == item_idx);
                if let Some(col) = fs.columns.get_mut(col_idx) {
                    col.selected_index = item_idx;
                }
                fs.focused_column = col_idx;
                let had_child = col_idx + 1 < fs.columns.len();
                fs.truncate_right_columns();
                should_drill = had_child || was_selected;
            }
            should_drill
        };

        if should_drill {
            if let Some(item) = state
                .folder_state
                .as_ref()
                .and_then(|fs| fs.columns.get(col_idx))
                .and_then(|c| c.items.get(item_idx))
                .cloned()
            {
                match item.item_type {
                    FolderItemType::Folder => {
                        return vec![FolderAction::NavigateIntoFolder {
                            folder_key: item.key,
                            replace_child: false,
                        }
                        .into()];
                    }
                    FolderItemType::Track => {
                        return vec![FolderAction::PlayFolderTracks.into()];
                    }
                }
            }
        }
    }

    vec![]
}

/// Handle mouse down in Queue or NowPlaying view.
fn handle_now_playing_down(
    click_row: u16,
    click_col: u16,
    modifiers: crossterm::event::KeyModifiers,
    state: &mut AppState,
) -> Vec<Action> {
    use crate::app::state::NowPlayingFocus;

    // Sidebar buttons (Radio / DJ Modes / Remix Tools / Clear Queue)
    // are visible in both Queue and NowPlaying views — both render
    // the combined screen.
    if let Some(buttons) = {
        let hr = &state.hit_regions;
        hr.now_playing_sidebar.clone()
    } {
        for (rect, btn) in &buttons {
            if click_col >= rect.x
                && click_col < rect.right()
                && click_row >= rect.y
                && click_row < rect.bottom()
            {
                state.now_playing_focus = NowPlayingFocus::Sidebar;
                state.now_playing_sidebar_index = state
                    .now_playing_sidebar_buttons()
                    .iter()
                    .position(|b| b == btn)
                    .unwrap_or(0);
                return super::key_input::activate_sidebar(state, *btn);
            }
        }
    }

    if state.view != View::Queue {
        return vec![];
    }
    // Check scrollbar clicks first
    if let Some(actions) = try_queue_scrollbar_click(click_col, click_row, state) {
        return actions;
    }

    // Read registered queue regions (drop borrow before mutating state)
    let queue_regions = {
        let hr = &state.hit_regions;
        hr.queue_content.clone()
    };
    let Some(qr) = queue_regions else {
        return vec![];
    };

    if qr.art_area.contains((click_col, click_row).into()) {
        state.now_playing_focus = NowPlayingFocus::Artwork;
        return vec![];
    }

    // Click on title bar (first content row) of track list toggles shuffle
    if click_row == qr.track_list.y
        && qr.track_list.contains((click_col, click_row).into())
        && !state.queue.tracks.is_empty()
    {
        return vec![QueueAction::ToggleQueueShuffle.into()];
    }

    // Track list area (right column)
    if qr.track_list_inner.contains((click_col, click_row).into()) {
        state.now_playing_focus = NowPlayingFocus::Tracks;
        // Visual row (accounting for border + 2-row layout per item)
        let visual_row = click_row.saturating_sub(qr.track_list_inner.y) as usize;
        let item_row = visual_row / 2;

        // Calculate visible item count (2 rows per item)
        let visible_item_count = qr.track_list_inner.height as usize / 2;

        // Track list
        let tracks_len = if state.playback_mode == PlaybackMode::Radio {
            state.radio.tracks.len()
        } else {
            state.queue.tracks.len()
        };

        // Match the renderer's scroll offset calculation
        let selected = state.list_state.queue_index;
        let scroll_offset = match state.scroll.queue {
            Some(pinned) => pinned,
            None => helpers::calc_scroll_offset(selected, visible_item_count, tracks_len),
        };
        let actual_idx = item_row + scroll_offset;

        if actual_idx < tracks_len {
            // Shift+Click: toggle multi-select
            if modifiers.contains(crossterm::event::KeyModifiers::SHIFT) {
                if state.queue.selected.contains(&actual_idx) {
                    state.queue.selected.remove(&actual_idx);
                } else {
                    state.queue.selected.insert(actual_idx);
                }
                state.scroll.queue = Some(scroll_offset);
                state.list_state.queue_index = actual_idx;
                return vec![];
            }

            // Normal click: clear multi-select
            if !state.queue.selected.is_empty() {
                state.queue.selected.clear();
            }

            let already_selected = state.list_state.queue_index == actual_idx;
            state.scroll.queue = Some(scroll_offset);
            state.list_state.queue_index = actual_idx;

            // Click already-selected item: play it (same as Enter)
            if already_selected {
                match state.playback_mode {
                    PlaybackMode::Queue | PlaybackMode::None => {
                        if actual_idx < state.queue.tracks.len() {
                            return vec![QueueAction::JumpToQueueIndex(actual_idx).into()];
                        }
                    }
                    PlaybackMode::Radio => {
                        if actual_idx < state.radio.tracks.len() {
                            return vec![RadioAction::JumpToRadioTrack(actual_idx).into()];
                        }
                    }
                }
            }
        }
    }

    vec![]
}

/// Handle click in Search view.
fn handle_search_click(click_row: u16, click_col: u16, state: &mut AppState) -> Vec<Action> {
    // Read registered search popup regions (drop borrow before mutating state)
    let regions = {
        let hr = &state.hit_regions;
        hr.search_popup.clone()
    };
    let Some(sp) = regions else { return vec![] };

    // Check if click is within popup
    if click_row < sp.outer.y
        || click_row >= sp.outer.bottom()
        || click_col < sp.outer.x
        || click_col >= sp.outer.right()
    {
        return vec![];
    }

    // Tabs area
    if click_row >= sp.tab_area.y && click_row < sp.tab_area.bottom() {
        let inner_col = click_col.saturating_sub(sp.tab_area.x);
        let actions = handle_search_tab_click(inner_col, state);
        if !actions.is_empty() {
            return actions;
        }
        return vec![];
    }

    // Results area
    if click_row >= sp.results_area.y && click_row < sp.results_area.bottom() {
        let visual_row = (click_row - sp.results_area.y) as usize;
        let results_height = sp.results_area.height as usize;
        let actions = handle_search_result_click(visual_row, results_height, state);
        return actions;
    }

    vec![]
}

/// Handle click in Auth view (login form, server selection).
fn handle_auth_click(click_row: u16, click_col: u16, state: &mut AppState) -> Vec<Action> {
    use crate::app::state::AuthStep;

    match state.auth_state.step {
        AuthStep::Login => {
            // Login form is centered, 50 chars wide, 12 rows tall
            let form_width = 50u16.min(state.terminal_width.saturating_sub(4));
            let form_height = 12u16;
            let form_x = (state.terminal_width.saturating_sub(form_width)) / 2;
            let form_y = (state.terminal_height.saturating_sub(form_height)) / 2;

            // Check if click is within form bounds
            if click_col >= form_x
                && click_col < form_x + form_width
                && click_row >= form_y
                && click_row < form_y + form_height
            {
                let rel_row = click_row - form_y;

                // Form layout:
                // 0-1: Title (2 rows)
                // 2-4: Username field (3 rows)
                // 5-7: Password field (3 rows)
                // 8-9: Button (2 rows)

                if (2..5).contains(&rel_row) {
                    // Username field clicked
                    state.auth_state.field_index = 0;
                    state.auth_state.editing = true;
                } else if (5..8).contains(&rel_row) {
                    // Password field clicked
                    state.auth_state.field_index = 1;
                    state.auth_state.editing = true;
                } else if (8..10).contains(&rel_row) {
                    // Sign In button clicked
                    state.auth_state.field_index = 2;
                    state.auth_state.editing = false;
                    // Trigger login action
                    return vec![SettingsAction::AuthSignIn.into()];
                }
            }
        }
        AuthStep::ServerSelect => {
            // Server list is centered, calculate bounds
            let list_width = 50u16.min(state.terminal_width.saturating_sub(4));
            let list_height = (state.available_servers.len() as u16).min(10) + 4;
            let list_x = (state.terminal_width.saturating_sub(list_width)) / 2;
            let list_y = (state.terminal_height.saturating_sub(list_height)) / 2;

            if click_col >= list_x
                && click_col < list_x + list_width
                && click_row >= list_y
                && click_row < list_y + list_height
            {
                let rel_row = click_row - list_y;

                // Layout: 2 rows instruction, then server list, 1 row hint
                if rel_row >= 2 && rel_row < list_height - 1 {
                    let server_index = (rel_row - 2) as usize;
                    if server_index < state.available_servers.len() {
                        let already_highlighted = state.auth_state.server_index == server_index;
                        if already_highlighted {
                            return vec![SettingsAction::AuthSelectServer.into()];
                        } else {
                            state.auth_state.server_index = server_index;
                        }
                    }
                }
            }
        }
        _ => {}
    }

    vec![]
}

/// Handle click in Settings view.
fn handle_settings_click(click_row: u16, click_col: u16, state: &mut AppState) -> Vec<Action> {
    use crate::app::state::{SettingsFocus, SettingsSection};

    // Settings layout: left panel (sections, 16 wide) | right panel (content)
    let left_panel_width = 16u16;

    // Account for top border (content starts at row 0, border adds 1)
    let visual_row = click_row.saturating_sub(1) as usize;

    if click_col < left_panel_width {
        // Click on section list
        let sections = SettingsSection::all();
        if visual_row < sections.len() {
            state.settings_state.section = sections[visual_row];
            state.scroll.settings_sections = None;
            state.scroll.settings_textamp = None;
            state.settings_state.item_index = 0;
            state.settings_state.focus = SettingsFocus::Sections;
        }
    } else {
        // Click on items in right panel - map visual row to item index
        // Each section has different header/blank line layouts before selectable items
        let item_index = if state.settings_state.section == SettingsSection::Textamp {
            state
                .hit_regions
                .settings_textamp
                .as_ref()
                .and_then(|region| {
                    let (_, index) = region
                        .rows
                        .iter()
                        .find(|(rect, _)| rect.contains((click_col, click_row).into()))?;
                    state.scroll.settings_textamp = Some(region.scroll_offset);
                    Some(*index)
                })
        } else if state.settings_state.section == SettingsSection::Sections {
            state
                .hit_regions
                .settings_sections
                .as_ref()
                .and_then(|region| {
                    if !region.inner.contains((click_col, click_row).into()) {
                        return None;
                    }
                    state.scroll.settings_sections = Some(region.scroll_offset);
                    let index = region.scroll_offset + (click_row - region.inner.y) as usize;
                    (index < region.item_count).then_some(index)
                })
        } else {
            settings_visual_row_to_item(visual_row, state)
        };

        if let Some(idx) = item_index {
            let was_selected = state.settings_state.focus == SettingsFocus::Content
                && state.settings_state.item_index == idx;
            state.settings_state.focus = SettingsFocus::Content;
            state.settings_state.item_index = idx;

            if was_selected {
                // Double-click / click already-selected: activate
                return vec![SettingsAction::SettingsSelect.into()];
            }
        }
    }

    vec![]
}

/// Map a visual row in the settings content panel to an item index.
/// Returns None if the row is a header, blank line, or out of bounds.
fn settings_visual_row_to_item(visual_row: usize, state: &AppState) -> Option<usize> {
    use crate::app::state::SettingsSection;

    match state.settings_state.section {
        SettingsSection::Textamp => None, // Uses registered, scrolled geometry.
        SettingsSection::Sections => None, // Uses registered, scrolled geometry.
        SettingsSection::Cache => visual_row
            .checked_sub(1)
            .filter(|i| *i < if state.sources.active.is_plex() { 5 } else { 2 }),
        SettingsSection::Libraries => Some(0),
        SettingsSection::About => None,
    }
}

/// Handle click in Help view.
fn handle_help_click(click_row: u16, click_col: u16, state: &mut AppState) -> Vec<Action> {
    // Check scrollbar click
    if let Some(actions) = try_help_scrollbar_click(click_col, click_row, state) {
        return actions;
    }
    vec![]
}

/// Handle click in Similar view (popup overlay).
fn handle_similar_click(click_row: u16, click_col: u16, state: &mut AppState) -> Vec<Action> {
    use crate::app::state::SimilarMode;

    // Read registered regions (drop borrow before mutating state)
    let regions = {
        let hr = &state.hit_regions;
        hr.similar_content.clone()
    };
    let Some(regions) = regions else {
        return vec![];
    };

    // Click outside popup: close similar view
    if click_col < regions.outer.x
        || click_col >= regions.outer.right()
        || click_row < regions.outer.y
        || click_row >= regions.outer.bottom()
    {
        return vec![NavigationAction::SetView(state.previous_view.unwrap_or(View::Browse)).into()];
    }

    // Check [Tab] hint click (footer area)
    if let Some(tab_rect) = &regions.tab_hint {
        if click_row >= tab_rect.y
            && click_row < tab_rect.bottom()
            && click_col >= tab_rect.x
            && click_col < tab_rect.right()
        {
            // Trigger same logic as Tab key handler
            return super::key_input::similar::handle_similar_keys(
                crossterm::event::KeyEvent::new(
                    crossterm::event::KeyCode::Tab,
                    crossterm::event::KeyModifiers::NONE,
                ),
                state,
            );
        }
    }

    // Check scrollbar click first
    if let Some(actions) = try_similar_scrollbar_click(click_col, click_row, state) {
        return actions;
    }

    // Content area: inner minus footer (1 row at bottom)
    let content_bottom = regions.inner.y + regions.inner.height.saturating_sub(1);
    if click_row < regions.inner.y || click_row >= content_bottom {
        return vec![];
    }

    let inner_row = (click_row - regions.inner.y) as usize;
    let rows_per_item = regions.rows_per_item as usize;
    let inner_height = (content_bottom - regions.inner.y) as usize;
    let visible_item_count = inner_height / rows_per_item;

    let total = match state.similar.mode {
        SimilarMode::Albums => state.similar.albums.len(),
        SimilarMode::Tracks => state.similar.tracks.len(),
        SimilarMode::Artists => state.similar.artists.len(),
    };

    if total == 0 {
        return vec![];
    }

    let scroll_offset = match state.scroll.similar {
        Some(pinned) => pinned,
        None => {
            helpers::calc_scroll_offset(state.list_state.similar_index, visible_item_count, total)
        }
    };
    let clicked_idx = scroll_offset + inner_row / rows_per_item;

    if clicked_idx >= total {
        return vec![];
    }

    // Click highlights; second click on already-highlighted item activates
    let already_selected = state.list_state.similar_index == clicked_idx;
    state.scroll.similar = Some(scroll_offset);
    state.list_state.similar_index = clicked_idx;

    if already_selected {
        return super::key_input::similar::activate_similar_item(state);
    }

    vec![]
}

/// Handle click in Related view (popup overlay).
fn handle_related_click(click_row: u16, click_col: u16, state: &mut AppState) -> Vec<Action> {
    // Read registered regions (drop borrow before mutating state)
    let regions = {
        let hr = &state.hit_regions;
        hr.related_content.clone()
    };
    let Some(regions) = regions else {
        return vec![];
    };

    // Click outside popup: close related view
    if click_col < regions.outer.x
        || click_col >= regions.outer.right()
        || click_row < regions.outer.y
        || click_row >= regions.outer.bottom()
    {
        return vec![NavigationAction::SetView(state.previous_view.unwrap_or(View::Browse)).into()];
    }

    // Check scrollbar click first
    if let Some(actions) = try_related_scrollbar_click(click_col, click_row, state) {
        return actions;
    }

    // Content area: inner minus footer (1 row at bottom)
    let content_bottom = regions.inner.y + regions.inner.height.saturating_sub(1);
    if click_row < regions.inner.y || click_row >= content_bottom {
        return vec![];
    }

    let inner_row = (click_row - regions.inner.y) as usize;
    let inner_height = (content_bottom - regions.inner.y) as usize;
    let visible_item_count = inner_height; // 1 row per item

    let total = helpers::navigation::related_flat_count(&state.related.groups);
    if total == 0 {
        return vec![];
    }

    let scroll_offset = match state.scroll.related {
        Some(pinned) => pinned,
        None => {
            helpers::calc_scroll_offset(state.list_state.related_index, visible_item_count, total)
        }
    };
    let clicked_idx = scroll_offset + inner_row;

    if clicked_idx >= total {
        return vec![];
    }

    // Click highlights; second click on already-highlighted item activates
    let already_selected = state.list_state.related_index == clicked_idx;
    state.scroll.related = Some(scroll_offset);
    state.scroll.related_click_time = Some(std::time::Instant::now());
    state.list_state.related_index = clicked_idx;

    if already_selected {
        return super::key_input::related::activate_related_item(state);
    }

    vec![]
}

/// Handle scroll wheel events.
fn handle_scroll(up: bool, click_row: u16, click_col: u16, state: &mut AppState) -> Vec<Action> {
    // Coalesce rapid scroll events (normal mouse wheel can fire multiple events per tick)
    let now = std::time::Instant::now();
    if let Some(last) = state.scroll.scroll_cooldown {
        if now.duration_since(last).as_millis() < 50 {
            return vec![];
        }
    }
    state.scroll.scroll_cooldown = Some(now);

    match pointer_view(state, click_col, click_row) {
        View::Settings => {
            if let Some(region) = &state.hit_regions.settings_textamp {
                if region.inner.contains((click_col, click_row).into()) {
                    let max = region
                        .total_lines
                        .saturating_sub(region.inner.height as usize);
                    state.scroll.settings_textamp = Some(if up {
                        region.scroll_offset.saturating_sub(3)
                    } else {
                        region.scroll_offset.saturating_add(3).min(max)
                    });
                }
            }
            if let Some(region) = &state.hit_regions.settings_sections {
                if region.inner.contains((click_col, click_row).into()) {
                    let max = region
                        .item_count
                        .saturating_sub(region.inner.height as usize);
                    state.scroll.settings_sections = Some(if up {
                        region.scroll_offset.saturating_sub(3)
                    } else {
                        region.scroll_offset.saturating_add(3).min(max)
                    });
                }
            }
        }
        View::Browse => {
            return handle_browse_scroll(up, click_row, click_col, state);
        }
        View::Queue => {
            if !state
                .hit_regions
                .queue_content
                .as_ref()
                .is_some_and(|r| r.track_list.contains((click_col, click_row).into()))
            {
                return vec![];
            }

            // Scroll queue (includes play history + current tracks)
            state.scroll.queue = None;
            let delta: i32 = if up { -1 } else { 1 };
            let tracks_len = if state.playback_mode == PlaybackMode::Radio {
                state.radio.tracks.len()
            } else {
                state.queue.tracks.len()
            };
            let max = tracks_len.saturating_sub(1);
            let new_idx =
                (state.list_state.queue_index as i32 + delta).clamp(0, max as i32) as usize;
            state.list_state.queue_index = new_idx;
        }
        View::Search => {
            // Search scrolling handled via keyboard for now
        }
        View::Help => {
            // Scroll help content
            let delta: i32 = if up { -1 } else { 1 };
            let new_scroll = (state.help_scroll as i32 + delta).max(0) as u16;
            state.help_scroll = state
                .hit_regions
                .help
                .as_ref()
                .map_or(new_scroll, |r| new_scroll.min(r.max_scroll()));
        }
        View::Similar => {
            state.scroll.similar = None;
            let delta: i32 = if up { -1 } else { 1 };
            let total = match state.similar.mode {
                crate::app::state::SimilarMode::Albums => state.similar.albums.len(),
                crate::app::state::SimilarMode::Tracks => state.similar.tracks.len(),
                crate::app::state::SimilarMode::Artists => state.similar.artists.len(),
            };
            let max = total.saturating_sub(1);
            let new_idx =
                (state.list_state.similar_index as i32 + delta).clamp(0, max as i32) as usize;
            state.list_state.similar_index = new_idx;
        }
        View::Related => {
            state.scroll.related = None;
            let delta: i32 = if up { -1 } else { 1 };
            let total = helpers::navigation::related_flat_count(&state.related.groups);
            let max = total.saturating_sub(1);
            let new_idx =
                (state.list_state.related_index as i32 + delta).clamp(0, max as i32) as usize;
            state.list_state.related_index = new_idx;
        }
        _ => {}
    }

    vec![]
}

/// Handle scroll in Browse view using Miller column awareness.
fn handle_browse_scroll(
    up: bool,
    click_row: u16,
    click_col: u16,
    state: &mut AppState,
) -> Vec<Action> {
    if let Some(region) = state
        .hit_regions
        .category_column
        .as_ref()
        .filter(|r| r.inner.contains((click_col, click_row).into()))
    {
        let max = region
            .item_count
            .saturating_sub(region.inner.height as usize);
        state.scroll.category = Some(if up {
            region.scroll_offset.saturating_sub(1)
        } else {
            region.scroll_offset.saturating_add(1).min(max)
        });
        return vec![];
    }
    // If a mouse click recently set the scroll pin, ignore scroll events
    // to prevent trackpad inertia from clearing the pin and re-centering.
    if let Some(click_time) = state.scroll.browse_click_time {
        if click_time.elapsed() < std::time::Duration::from_millis(400) {
            return vec![];
        }
        state.scroll.browse_click_time = None;
    }
    // Clear scroll pin — scrolling should use fresh calc_scroll_offset
    state.scroll.browse = None;

    match state.browse_category {
        BrowseCategory::Folders => {
            if let Some((col_idx, _, _)) = folder_hit_test(click_col, click_row, state) {
                let delta: i32 = if up { -1 } else { 1 };

                // Check if filter is active on this folder column
                let filter_on_col = state.list_filter.active
                    && state.list_filter.category == BrowseCategory::Folders
                    && state.list_filter.column == col_idx;

                if filter_on_col {
                    if let Some(ref results) = state.list_filter.results {
                        if !results.matched_indices.is_empty() {
                            let max = results.matched_indices.len().saturating_sub(1);
                            let new_sel = (state.list_filter.selected as i32 + delta)
                                .clamp(0, max as i32)
                                as usize;
                            state.list_filter.selected = new_sel;
                            if let Some(&item_idx) = results.matched_indices.get(new_sel) {
                                if let Some(folder_state) = &mut state.folder_state {
                                    if let Some(col) = folder_state.columns.get_mut(col_idx) {
                                        col.selected_index = item_idx;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if let Some(folder_state) = &mut state.folder_state {
                        if let Some(col) = folder_state.columns.get_mut(col_idx) {
                            let max = col.items.len().saturating_sub(1);
                            let new_idx =
                                (col.selected_index as i32 + delta).clamp(0, max as i32) as usize;
                            col.selected_index = new_idx;
                        }
                        if col_idx != folder_state.focused_column {
                            folder_state.focused_column = col_idx;
                        }
                    }
                }
                // Selection-only: scroll truncates stale child columns
                // and waits for explicit Enter/Right.
                if let Some(folder_state) = &mut state.folder_state {
                    folder_state.truncate_right_columns();
                }
            }
        }
        cat if !matches!(cat, BrowseCategory::Folders) => {
            let nav = match state.browse_category {
                BrowseCategory::Library => &state.artist_nav,
                cat if cat.is_tag_section() => &state.tag_nav,
                BrowseCategory::Playlists => &state.playlist_nav,
                _ => unreachable!(),
            };

            if let Some(col_idx) = miller_column_at(click_col, nav, state) {
                // Check if column has artwork visible (scroll 1 at a time in art mode)
                let is_art_scroll = nav.columns.get(col_idx).is_some_and(|c| c.artwork_visible);

                // Throttle cover art scrolling to prevent trackpad momentum
                if is_art_scroll {
                    let now = std::time::Instant::now();
                    if let Some(last) = state.scroll.art_cooldown {
                        if now.duration_since(last).as_millis() < 120 {
                            return vec![];
                        }
                    }
                    state.scroll.art_cooldown = Some(now);
                }

                let delta: i32 = if up { -1 } else { 1 };

                // Check if filter is active on this column
                let filter_on_col = state.list_filter.active
                    && state.list_filter.category == state.browse_category
                    && state.list_filter.column == col_idx;

                if filter_on_col {
                    // Navigate through filtered items
                    if let Some(ref results) = state.list_filter.results {
                        if !results.matched_indices.is_empty() {
                            let max = results.matched_indices.len().saturating_sub(1);
                            let new_sel = (state.list_filter.selected as i32 + delta)
                                .clamp(0, max as i32)
                                as usize;
                            state.list_filter.selected = new_sel;
                            if let Some(&item_idx) = results.matched_indices.get(new_sel) {
                                let nav = match state.browse_category {
                                    BrowseCategory::Library => &mut state.artist_nav,
                                    cat if cat.is_tag_section() => &mut state.tag_nav,
                                    BrowseCategory::Playlists => &mut state.playlist_nav,
                                    _ => unreachable!(),
                                };
                                if let Some(col) = nav.columns.get_mut(col_idx) {
                                    col.selected_index = item_idx;
                                }
                            }
                        }
                    }
                } else {
                    let nav = match state.browse_category {
                        BrowseCategory::Library => &mut state.artist_nav,
                        cat if cat.is_tag_section() => &mut state.tag_nav,
                        BrowseCategory::Playlists => &mut state.playlist_nav,
                        _ => unreachable!(),
                    };

                    if let Some(col) = nav.columns.get_mut(col_idx) {
                        let max = col.items.len().saturating_sub(1);
                        let new_idx =
                            (col.selected_index as i32 + delta).clamp(0, max as i32) as usize;
                        col.selected_index = new_idx;
                    }

                    if col_idx != nav.focused_column {
                        nav.focused_column = col_idx;
                    }

                    // Selection-only: scroll truncates stale child columns
                    // (matches keyboard Up/Down), child columns reopen on
                    // explicit Enter/Right.
                    nav.truncate_right();
                }
            }
        }
        _ => {}
    }

    // After scroll, lazily load album art for newly visible items
    let mut actions = vec![];
    let art_batch = super::dispatch_miller::collect_viewport_art(state);
    if !art_batch.is_empty() {
        actions.push(SystemAction::LoadAlbumArt(art_batch).into());
    }
    actions
}

/// Handle mouse click when the artist radio picker popup is active.
fn handle_artist_radio_picker_click(
    click_row: u16,
    click_col: u16,
    state: &mut AppState,
) -> Vec<Action> {
    use crate::app::state::{ArtistRadioPickerStep, SearchFocus};

    // Read registered regions (drop borrow before mutating state)
    let regions = {
        let hr = &state.hit_regions;
        hr.artist_radio_picker.clone()
    };
    let Some(regions) = regions else {
        return vec![];
    };

    // Click outside popup — close
    if click_col < regions.outer.x
        || click_col >= regions.outer.right()
        || click_row < regions.outer.y
        || click_row >= regions.outer.bottom()
    {
        return vec![SearchAction::CloseArtistRadioPicker.into()];
    }

    let picker = match &state.popups.artist_radio_picker {
        Some(p) => p,
        None => return vec![],
    };

    // Only handle clicks in SelectArtists step (results list)
    if !matches!(picker.step, ArtistRadioPickerStep::SelectArtists) {
        return vec![];
    }

    // Check if click is in the results area
    if click_row < regions.items_area.y || click_row >= regions.items_area.bottom() {
        return vec![];
    }

    let click_offset = (click_row - regions.items_area.y) as usize;
    let results_height = regions.items_area.height as usize;
    let total = picker.filtered_artists.len();
    let scroll_offset = match picker.scroll_pin {
        Some(pinned) => pinned,
        None => helpers::calc_scroll_offset(picker.item_index, results_height, total),
    };

    let clicked_idx = scroll_offset + click_offset;
    if clicked_idx >= total {
        return vec![];
    }

    let already_selected = picker.item_index == clicked_idx && picker.focus == SearchFocus::Results;

    if already_selected {
        // Second click on same item — toggle selection
        return vec![SearchAction::ArtistRadioPickerToggleArtist.into()];
    }

    // First click — highlight (set scroll pin)
    if let Some(ref mut picker) = state.popups.artist_radio_picker {
        picker.scroll_pin = Some(scroll_offset);
        picker.item_index = clicked_idx;
        picker.focus = SearchFocus::Results;
    }
    vec![]
}

/// Handle mouse click when the adventure launcher popup is active.
fn handle_adventure_launcher_click(
    click_row: u16,
    click_col: u16,
    state: &mut AppState,
) -> Vec<Action> {
    use crate::app::state::{AdventureDrillLevel, SearchFocus};

    // Read registered regions (drop borrow before mutating state)
    let regions = {
        let hr = &state.hit_regions;
        hr.adventure_launcher.clone()
    };
    let Some(regions) = regions else {
        return vec![];
    };

    // Click outside popup — close
    if click_col < regions.outer.x
        || click_col >= regions.outer.right()
        || click_row < regions.outer.y
        || click_row >= regions.outer.bottom()
    {
        return vec![SearchAction::CloseAdventureLauncher.into()];
    }

    let launcher = match &state.popups.adventure_launcher {
        Some(l) => l,
        None => return vec![],
    };

    // Results area from registered regions
    let results_y = regions.inner.y + regions.results_y_offset;
    let results_height = regions
        .inner
        .height
        .saturating_sub(regions.results_y_offset) as usize;

    if click_row < results_y || click_row >= results_y + results_height as u16 {
        return vec![];
    }

    let click_offset = (click_row - results_y) as usize;
    let total = match &launcher.drill {
        AdventureDrillLevel::Search => {
            if let Some(ref results) = launcher.results {
                results.artists.len() + results.albums.len() + results.tracks.len()
            } else {
                0
            }
        }
        AdventureDrillLevel::ArtistAlbums { albums, .. } => albums.len(),
        AdventureDrillLevel::AlbumTracks { tracks, .. } => tracks.len(),
    };

    let scroll_offset = match launcher.scroll_pin {
        Some(pinned) => pinned,
        None => helpers::calc_scroll_offset(launcher.item_index, results_height, total),
    };

    let clicked_display_idx = scroll_offset + click_offset;

    // For Search level with section headers, we need to map display index to item index
    let clicked_item_idx = if matches!(launcher.drill, AdventureDrillLevel::Search) {
        if let Some(ref results) = launcher.results {
            let mut item_idx = 0usize;
            let mut display_idx = 0usize;
            // Artists section
            if !results.artists.is_empty() {
                if display_idx == clicked_display_idx {
                    return vec![];
                } // clicked header
                display_idx += 1;
                for _ in &results.artists {
                    if display_idx == clicked_display_idx {
                        break;
                    }
                    display_idx += 1;
                    item_idx += 1;
                }
                if display_idx == clicked_display_idx {
                    Some(item_idx)
                } else {
                    None
                }
            } else {
                None
            }
            .or_else(|| {
                if !results.albums.is_empty() {
                    if display_idx == clicked_display_idx {
                        return None;
                    } // header
                    display_idx += 1;
                    for _ in &results.albums {
                        if display_idx == clicked_display_idx {
                            return Some(item_idx);
                        }
                        display_idx += 1;
                        item_idx += 1;
                    }
                }
                None
            })
            .or_else(|| {
                if !results.tracks.is_empty() {
                    if display_idx == clicked_display_idx {
                        return None;
                    } // header
                    display_idx += 1;
                    for _ in &results.tracks {
                        if display_idx == clicked_display_idx {
                            return Some(item_idx);
                        }
                        display_idx += 1;
                        item_idx += 1;
                    }
                }
                None
            })
        } else {
            None
        }
    } else {
        if clicked_display_idx < total {
            Some(clicked_display_idx)
        } else {
            None
        }
    };

    let Some(item_idx) = clicked_item_idx else {
        return vec![];
    };

    let already_selected =
        launcher.item_index == item_idx && launcher.focus == SearchFocus::Results;

    if already_selected {
        // Second click — same as Enter: drill into artist/album or select track
        match &launcher.drill {
            AdventureDrillLevel::Search => {
                if let Some(ref results) = launcher.results {
                    let artist_count = results.artists.len();
                    let album_count = results.albums.len();
                    if item_idx < artist_count {
                        let artist = &results.artists[item_idx];
                        return vec![SearchAction::AdventureLauncherDrillArtist {
                            key: artist.rating_key.clone(),
                            name: artist.title.clone(),
                        }
                        .into()];
                    } else if item_idx < artist_count + album_count {
                        let album = &results.albums[item_idx - artist_count];
                        return vec![SearchAction::AdventureLauncherDrillAlbum {
                            key: album.rating_key.clone(),
                            title: album.title.clone(),
                            artist_name: album.artist_name().to_string(),
                        }
                        .into()];
                    } else {
                        return vec![SearchAction::AdventureLauncherSelectTrack.into()];
                    }
                }
            }
            AdventureDrillLevel::ArtistAlbums {
                albums,
                artist_name,
                ..
            } => {
                if let Some(album) = albums.get(item_idx) {
                    return vec![SearchAction::AdventureLauncherDrillAlbum {
                        key: album.rating_key.clone(),
                        title: album.title.clone(),
                        artist_name: artist_name.clone(),
                    }
                    .into()];
                }
            }
            AdventureDrillLevel::AlbumTracks { .. } => {
                return vec![SearchAction::AdventureLauncherSelectTrack.into()];
            }
        }
        return vec![];
    }

    // First click — highlight (set scroll pin)
    if let Some(ref mut launcher) = state.popups.adventure_launcher {
        launcher.scroll_pin = Some(scroll_offset);
        launcher.item_index = item_idx;
        launcher.focus = SearchFocus::Results;
    }
    vec![]
}

// ============================================================================
// Scrollbar click-and-drag support
// ============================================================================

/// Check if a click is on the scrollbar (right border column) of a bordered area.
/// Returns Some((track_y_start, track_height, thumb_pos, thumb_size, scroll_offset))
/// if the click is on the scrollbar column within the track area.
#[derive(Clone, Copy)]
struct ScrollbarThumb {
    track_y_start: u16,
    track_height: u16,
    thumb_pos: usize,
    thumb_size: usize,
}

fn scrollbar_hit_test_bordered(
    click_col: u16,
    click_row: u16,
    area: Rect,
    total_items: usize,
    visible_items: usize,
    scroll_offset: usize,
) -> Option<ScrollbarThumb> {
    // Scrollbar is on the rightmost column of the bordered area
    let bar_x = area.x + area.width.saturating_sub(1);
    if click_col != bar_x {
        return None;
    }

    let track_y_start = area.y + 1; // skip top border
    let track_height = area.height.saturating_sub(2); // exclude top/bottom border

    if track_height == 0 || total_items == 0 || visible_items >= total_items {
        return None;
    }

    if click_row < track_y_start || click_row >= track_y_start + track_height {
        return None;
    }

    let (thumb_size, thumb_pos) = calc_thumb(
        total_items,
        visible_items,
        scroll_offset,
        track_height as usize,
    );
    Some(ScrollbarThumb {
        track_y_start,
        track_height,
        thumb_pos,
        thumb_size,
    })
}

/// Start a scrollbar drag from a click. Sets `scrollbar_drag` on state.
/// If the click is on the thumb, grab_offset is the offset within the thumb.
/// If the click is on the track (not thumb), jump to position and center grab.
fn start_scrollbar_drag(
    click_row: u16,
    thumb: ScrollbarThumb,
    total_items: usize,
    visible_items: usize,
    view: ScrollbarView,
    col_idx: usize,
    state: &mut AppState,
) -> usize {
    let ScrollbarThumb {
        track_y_start,
        track_height,
        thumb_pos,
        thumb_size,
    } = thumb;
    let rel_row = (click_row - track_y_start) as usize;
    let on_thumb = rel_row >= thumb_pos && rel_row < thumb_pos + thumb_size;

    let grab_offset = if on_thumb {
        (rel_row - thumb_pos) as u16
    } else {
        (thumb_size / 2) as u16
    };

    // Compute the scroll offset for the target position
    let new_offset = if on_thumb {
        // Don't move — just start dragging
        scroll_offset_from_y(
            click_row,
            track_y_start,
            track_height,
            total_items,
            visible_items,
            grab_offset,
        )
    } else {
        // Jump: position thumb centered on click
        scroll_offset_from_y(
            click_row,
            track_y_start,
            track_height,
            total_items,
            visible_items,
            grab_offset,
        )
    };

    state.scroll.scrollbar_drag = Some(ScrollbarDrag {
        view,
        col_idx,
        total_items,
        visible_items,
        track_y_start,
        track_height,
        grab_offset,
    });

    new_offset
}

/// Handle scrollbar drag events (MouseDrag while scrollbar_drag is active).
fn handle_scrollbar_drag(mouse_y: u16, state: &mut AppState) -> Vec<Action> {
    let drag = match state.scroll.scrollbar_drag.as_ref() {
        Some(d) => d.clone(),
        None => return vec![],
    };

    let new_offset = scroll_offset_from_y(
        mouse_y,
        drag.track_y_start,
        drag.track_height,
        drag.total_items,
        drag.visible_items,
        drag.grab_offset,
    );

    match drag.view {
        ScrollbarView::Browse | ScrollbarView::Folder => {
            state.scroll.browse = Some((drag.col_idx, new_offset));
            state.scroll.browse_click_time = Some(std::time::Instant::now());

            // Adjust selected index to stay within the visible range.
            // When filter is active, offsets are positions in the filtered list,
            // so we must map through matched_indices.
            let first_visible = new_offset;
            let last_visible = new_offset + drag.visible_items.saturating_sub(1);

            let filter_indices = if state.list_filter.active
                && state.list_filter.column == drag.col_idx
                && ((drag.view == ScrollbarView::Browse
                    && state.list_filter.category == state.browse_category)
                    || (drag.view == ScrollbarView::Folder
                        && state.list_filter.category == BrowseCategory::Folders))
            {
                state
                    .list_filter
                    .results
                    .as_ref()
                    .map(|r| r.matched_indices.clone())
            } else {
                None
            };

            match drag.view {
                ScrollbarView::Browse => {
                    let nav = match state.browse_category {
                        BrowseCategory::Library => &mut state.artist_nav,
                        cat if cat.is_tag_section() => &mut state.tag_nav,
                        BrowseCategory::Playlists => &mut state.playlist_nav,
                        _ => return vec![],
                    };
                    if let Some(col) = nav.columns.get_mut(drag.col_idx) {
                        if let Some(ref indices) = filter_indices {
                            // Map display position to actual item index
                            let display_pos = indices
                                .iter()
                                .position(|&idx| idx == col.selected_index)
                                .unwrap_or(0);
                            let clamped = display_pos
                                .max(first_visible)
                                .min(last_visible.min(indices.len().saturating_sub(1)));
                            col.selected_index = indices[clamped];
                        } else {
                            if col.selected_index < first_visible {
                                col.selected_index = first_visible;
                            } else if col.selected_index > last_visible {
                                col.selected_index = last_visible;
                            }
                        }
                    }
                }
                ScrollbarView::Folder => {
                    if let Some(folder_state) = &mut state.folder_state {
                        if let Some(col) = folder_state.columns.get_mut(drag.col_idx) {
                            if let Some(ref indices) = filter_indices {
                                let display_pos = indices
                                    .iter()
                                    .position(|&idx| idx == col.selected_index)
                                    .unwrap_or(0);
                                let clamped = display_pos
                                    .max(first_visible)
                                    .min(last_visible.min(indices.len().saturating_sub(1)));
                                col.selected_index = indices[clamped];
                            } else {
                                if col.selected_index < first_visible {
                                    col.selected_index = first_visible;
                                } else if col.selected_index > last_visible {
                                    col.selected_index = last_visible;
                                }
                            }
                        }
                    }
                }
                _ => unreachable!(),
            }
        }
        ScrollbarView::Queue => {
            state.scroll.queue = Some(new_offset);
        }
        ScrollbarView::Similar => {
            state.scroll.similar = Some(new_offset);
        }
        ScrollbarView::Related => {
            state.scroll.related = Some(new_offset);
        }
        ScrollbarView::Help => {
            state.help_scroll = new_offset as u16;
        }
    }

    vec![]
}

/// Try to handle a scrollbar click in a browse Miller column.
/// Returns Some(actions) if the click was on a scrollbar, None otherwise.
fn try_browse_scrollbar_click(
    click_col: u16,
    click_row: u16,
    state: &mut AppState,
) -> Option<Vec<Action>> {
    let miller = {
        let hr = &state.hit_regions;
        hr.miller_columns.clone()
    };
    let mr = miller?;

    let nav = match state.browse_category {
        BrowseCategory::Library => &state.artist_nav,
        cat if cat.is_tag_section() => &state.tag_nav,
        BrowseCategory::Playlists => &state.playlist_nav,
        _ => return None,
    };

    // Check if filter is active on a column in this category
    let filter_on_col = if state.list_filter.active
        && state.list_filter.category == state.browse_category
        && state.list_filter.results.is_some()
    {
        Some(state.list_filter.column)
    } else {
        None
    };

    for col_reg in &mr.columns {
        let col_idx = col_reg.col_idx;
        if col_idx >= nav.columns.len() {
            continue;
        }

        let col = &nav.columns[col_idx];
        let inner_height = col_reg.inner.height as usize;

        // When filter is active on this column, use filtered item count
        let (total_items, display_selected) = if filter_on_col == Some(col_idx) {
            if let Some(ref results) = state.list_filter.results {
                if results.matched_indices.is_empty() {
                    continue;
                }
                let ds = results
                    .matched_indices
                    .iter()
                    .position(|&idx| idx == col.selected_index)
                    .unwrap_or(0);
                (results.matched_indices.len(), ds)
            } else {
                continue;
            }
        } else {
            (col.items.len(), col.selected_index)
        };

        if total_items == 0 {
            continue;
        }

        let visible_items = if col_reg.is_art_mode && filter_on_col != Some(col_idx) {
            // Use the renderer-supplied art_row_height; do not recompute.
            let art_row_height = col_reg.art_row_height.max(1) as usize;
            let mut y = 0usize;
            let mut count = 0;
            let offset = state
                .scroll
                .browse
                .and_then(|(pc, po)| if pc == col_idx { Some(po) } else { None })
                .unwrap_or(0);
            for i in offset..col.items.len() {
                let h = if is_one_row_item(&col.items[i]) {
                    1
                } else {
                    art_row_height
                };
                let spacer = if i + 1 < col.items.len()
                    && is_one_row_item(&col.items[i]) != is_one_row_item(&col.items[i + 1])
                {
                    1
                } else {
                    0
                };
                if y + h + spacer > inner_height {
                    break;
                }
                y += h + spacer;
                count += 1;
            }
            count.max(1)
        } else {
            let rows_per_item = col_reg.rows_per_item as usize;
            inner_height / rows_per_item
        };

        let pinned = state
            .scroll
            .browse
            .and_then(|(pc, po)| if pc == col_idx { Some(po) } else { None });
        let scroll_offset = pinned.unwrap_or_else(|| {
            helpers::calc_scroll_offset(display_selected, visible_items, total_items)
        });

        if let Some(thumb) = scrollbar_hit_test_bordered(
            click_col,
            click_row,
            col_reg.area,
            total_items,
            visible_items,
            scroll_offset,
        ) {
            let new_offset = start_scrollbar_drag(
                click_row,
                thumb,
                total_items,
                visible_items,
                ScrollbarView::Browse,
                col_idx,
                state,
            );
            state.scroll.browse = Some((col_idx, new_offset));
            state.scroll.browse_click_time = Some(std::time::Instant::now());
            return Some(vec![]);
        }
    }

    None
}

/// Try to handle a scrollbar click in a folder Miller column.
fn try_folder_scrollbar_click(
    click_col: u16,
    click_row: u16,
    state: &mut AppState,
) -> Option<Vec<Action>> {
    let folder_state = state.folder_state.as_ref()?;

    let miller = {
        let hr = &state.hit_regions;
        hr.miller_columns.clone()
    };
    let mr = miller?;

    // Check if filter is active on a folder column
    let filter_on_col = if state.list_filter.active
        && state.list_filter.category == BrowseCategory::Folders
        && state.list_filter.results.is_some()
    {
        Some(state.list_filter.column)
    } else {
        None
    };

    for col_reg in &mr.columns {
        let col_idx = col_reg.col_idx;
        if col_idx >= folder_state.columns.len() {
            continue;
        }

        let col = &folder_state.columns[col_idx];
        let inner_height = col_reg.inner.height as usize;

        // When filter is active on this column, use filtered item count
        let (total_items, display_selected) = if filter_on_col == Some(col_idx) {
            if let Some(ref results) = state.list_filter.results {
                if results.matched_indices.is_empty() {
                    continue;
                }
                let ds = results
                    .matched_indices
                    .iter()
                    .position(|&idx| idx == col.selected_index)
                    .unwrap_or(0);
                (results.matched_indices.len(), ds)
            } else {
                continue;
            }
        } else {
            (col.items.len(), col.selected_index)
        };

        if total_items == 0 {
            continue;
        }

        let visible_items = inner_height;
        let pinned = state
            .scroll
            .browse
            .and_then(|(pc, po)| if pc == col_idx { Some(po) } else { None });
        let scroll_offset = pinned.unwrap_or_else(|| {
            helpers::calc_scroll_offset(display_selected, visible_items, total_items)
        });

        if let Some(thumb) = scrollbar_hit_test_bordered(
            click_col,
            click_row,
            col_reg.area,
            total_items,
            visible_items,
            scroll_offset,
        ) {
            let new_offset = start_scrollbar_drag(
                click_row,
                thumb,
                total_items,
                visible_items,
                ScrollbarView::Folder,
                col_idx,
                state,
            );
            state.scroll.browse = Some((col_idx, new_offset));
            state.scroll.browse_click_time = Some(std::time::Instant::now());
            return Some(vec![]);
        }
    }

    None
}

/// Try to handle a scrollbar click in the queue track list.
fn try_queue_scrollbar_click(
    click_col: u16,
    click_row: u16,
    state: &mut AppState,
) -> Option<Vec<Action>> {
    let qr = {
        let hr = &state.hit_regions;
        hr.queue_content.clone()
    }?;

    // Track list is the right column, bordered
    if click_col < qr.track_list.x {
        return None;
    }

    let tracks_len = if state.playback_mode == PlaybackMode::Radio {
        state.radio.tracks.len()
    } else {
        state.queue.tracks.len()
    };

    // 2-row items
    let inner_height = qr.track_list_inner.height as usize;
    let visible_items = inner_height / 2;
    let selected = state.list_state.queue_index;
    let scroll_offset = state
        .scroll
        .queue
        .unwrap_or_else(|| helpers::calc_scroll_offset(selected, visible_items, tracks_len));

    if let Some(thumb) = scrollbar_hit_test_bordered(
        click_col,
        click_row,
        qr.track_list,
        tracks_len,
        visible_items,
        scroll_offset,
    ) {
        let new_offset = start_scrollbar_drag(
            click_row,
            thumb,
            tracks_len,
            visible_items,
            ScrollbarView::Queue,
            0,
            state,
        );
        state.scroll.queue = Some(new_offset);
        return Some(vec![]);
    }

    None
}

/// Try to handle a scrollbar click in the similar popup.
fn try_similar_scrollbar_click(
    click_col: u16,
    click_row: u16,
    state: &mut AppState,
) -> Option<Vec<Action>> {
    use crate::app::state::SimilarMode;

    let sr = {
        let hr = &state.hit_regions;
        hr.similar_content.clone()
    }?;

    let total_items = match state.similar.mode {
        SimilarMode::Albums => state.similar.albums.len(),
        SimilarMode::Tracks => state.similar.tracks.len(),
        SimilarMode::Artists => state.similar.artists.len(),
    };
    if total_items == 0 {
        return None;
    }

    let rows_per_item = sr.rows_per_item as usize;
    let inner_height = sr.inner.height.saturating_sub(1) as usize; // -1 for footer
    let visible_items = inner_height / rows_per_item;
    let scroll_offset = state.scroll.similar.unwrap_or_else(|| {
        helpers::calc_scroll_offset(state.list_state.similar_index, visible_items, total_items)
    });

    if let Some(thumb) = scrollbar_hit_test_bordered(
        click_col,
        click_row,
        sr.outer,
        total_items,
        visible_items,
        scroll_offset,
    ) {
        let new_offset = start_scrollbar_drag(
            click_row,
            thumb,
            total_items,
            visible_items,
            ScrollbarView::Similar,
            0,
            state,
        );
        state.scroll.similar = Some(new_offset);
        return Some(vec![]);
    }

    None
}

/// Try to handle a scrollbar click in the related popup.
fn try_related_scrollbar_click(
    click_col: u16,
    click_row: u16,
    state: &mut AppState,
) -> Option<Vec<Action>> {
    let sr = {
        let hr = &state.hit_regions;
        hr.related_content.clone()
    }?;

    let total_items = helpers::navigation::related_flat_count(&state.related.groups);
    if total_items == 0 {
        return None;
    }

    let inner_height = sr.inner.height.saturating_sub(1) as usize; // -1 for footer
    let visible_items = inner_height; // 1 row per item
    let scroll_offset = state.scroll.related.unwrap_or_else(|| {
        helpers::calc_scroll_offset(state.list_state.related_index, visible_items, total_items)
    });

    if let Some(thumb) = scrollbar_hit_test_bordered(
        click_col,
        click_row,
        sr.outer,
        total_items,
        visible_items,
        scroll_offset,
    ) {
        let new_offset = start_scrollbar_drag(
            click_row,
            thumb,
            total_items,
            visible_items,
            ScrollbarView::Related,
            0,
            state,
        );
        state.scroll.related = Some(new_offset);
        return Some(vec![]);
    }

    None
}

/// Try to handle a scrollbar click in the help view.
fn try_help_scrollbar_click(
    click_col: u16,
    click_row: u16,
    state: &mut AppState,
) -> Option<Vec<Action>> {
    let region = state.hit_regions.help.clone()?;
    let total_lines = region.lines;
    let visible_items = region.visible;
    let scroll_offset = state.help_scroll.min(region.max_scroll()) as usize;

    if let Some(thumb) = scrollbar_hit_test_bordered(
        click_col,
        click_row,
        region.area,
        total_lines,
        visible_items,
        scroll_offset,
    ) {
        let new_offset = start_scrollbar_drag(
            click_row,
            thumb,
            total_lines,
            visible_items,
            ScrollbarView::Help,
            0,
            state,
        );
        state.help_scroll = new_offset as u16;
        return Some(vec![]);
    }

    None
}

/// Handle mouse click on the sort popup overlay.
fn handle_sort_popup_click(click_row: u16, click_col: u16, state: &mut AppState) -> Vec<Action> {
    if state.popups.sort.is_none() {
        return vec![];
    }

    // Read registered regions (drop borrow before mutating state)
    let regions = {
        let hr = &state.hit_regions;
        hr.sort_popup.clone()
    };
    let Some(regions) = regions else {
        return vec![];
    };

    // Click outside popup → close
    if click_col < regions.outer.x
        || click_col >= regions.outer.right()
        || click_row < regions.outer.y
        || click_row >= regions.outer.bottom()
    {
        return vec![SearchAction::CloseSortPopup.into()];
    }

    // Options occupy inner area minus footer (last row)
    let options_end = regions.inner.y + regions.inner.height.saturating_sub(1);
    if click_row >= regions.inner.y && click_row < options_end {
        let option_idx = (click_row - regions.inner.y) as usize;
        if option_idx < regions.option_count {
            let already_selected = state
                .popups
                .sort
                .as_ref()
                .map(|p| p.selected_index == option_idx)
                .unwrap_or(false);
            if let Some(p) = &mut state.popups.sort {
                p.selected_index = option_idx;
            }
            if already_selected {
                return super::key_input::sort_popup::apply_selected_option(state);
            }
        }
    }

    vec![]
}
