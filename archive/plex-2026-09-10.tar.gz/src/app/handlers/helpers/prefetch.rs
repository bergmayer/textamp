//! Plex URL resolution and ownership of upcoming-track prefetch effects.
use crate::audio::cache::{download_track_audio_inner, TrackAudioCache};
use crate::plex::{models::Track, PlexClient};
use std::sync::Arc;

/// Spawn background tasks to pre-fetch upcoming tracks.
///
/// Non-blocking: spawns tokio tasks and returns immediately.
/// Limits concurrent downloads via semaphore.
pub fn trigger_prefetch(
    cache: &Arc<TrackAudioCache>,
    upcoming_tracks: &[Track],
    client: &PlexClient,
    transcode_kbps: u32,
) {
    for track in upcoming_tracks.iter().filter(|track| track.is_plex()) {
        // Skip if already cached or being downloaded
        let Some(fetch_generation) = cache.start_fetch(&track.rating_key) else {
            continue;
        };

        // For direct play, build URL synchronously. For transcode, defer to async task.
        let direct_url = if transcode_kbps == 0 {
            match client.get_stream_url(track) {
                Ok(url) => Some(url),
                Err(_) => {
                    cache.finish_fetch(&track.rating_key, fetch_generation);
                    continue;
                }
            }
        } else {
            None
        };

        let cache = Arc::clone(cache);
        let rating_key = track.rating_key.clone();
        let title = track.title.clone();
        let track_clone = track.clone();
        let semaphore = Arc::clone(&cache.semaphore);
        // Transcode URLs have all auth in the query string — headers would duplicate and cause 400
        let stream_headers = if transcode_kbps > 0 {
            reqwest::header::HeaderMap::new()
        } else {
            client.stream_headers()
        };
        let http_client = client.http_client().clone();
        let plex_client = client.clone();

        crate::app::tasks::spawn(async move {
            struct InFlightGuard {
                cache: Arc<TrackAudioCache>,
                key: String,
                generation: u64,
            }

            impl Drop for InFlightGuard {
                fn drop(&mut self) {
                    self.cache.finish_fetch(&self.key, self.generation);
                }
            }

            let _in_flight = InFlightGuard {
                cache: cache.clone(),
                key: rating_key.clone(),
                generation: fetch_generation,
            };

            let operation = async {
                // Acquire semaphore permit (limits concurrent downloads)
                let _permit = match semaphore.acquire().await {
                    Ok(permit) => permit,
                    Err(_) => return,
                };

                // Resolve URL (transcode requires async HLS playlist fetch)
                let primary_url = if let Some(url) = direct_url {
                    url
                } else {
                    match plex_client
                        .get_transcoded_stream_url(&track_clone, transcode_kbps)
                        .await
                    {
                        Ok(url) => url,
                        Err(e) => {
                            tracing::warn!("Pre-fetch transcode URL failed for {}: {}", title, e);
                            return;
                        }
                    }
                };

                tracing::debug!("Pre-fetching: {}", title);
                match download_track_audio_inner(
                    &primary_url,
                    None,
                    stream_headers,
                    http_client,
                    Some((&cache, fetch_generation)),
                )
                .await
                {
                    Ok(data) => {
                        let size = data.len();
                        if cache.insert_if_current(rating_key.clone(), data, fetch_generation) {
                            tracing::debug!("Pre-fetched: {} ({} bytes)", title, size);
                        } else {
                            tracing::debug!("Discarded stale prefetch for {}", title);
                        }
                    }
                    Err(e) => {
                        if cache.generation_is_current(fetch_generation) {
                            tracing::warn!("Pre-fetch failed for {}: {}", title, e);
                        } else {
                            tracing::debug!("Cancelled stale prefetch for {}", title);
                        }
                    }
                }
            };
            tokio::select! {
                _ = cache.cancelled(fetch_generation) => {}
                _ = operation => {}
            }
        });
    }
}
