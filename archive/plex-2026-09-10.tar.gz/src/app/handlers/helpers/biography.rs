//! Provider-first biography loading, owned by the popup that requested it.
use crate::app::event::UiEvent;
use crate::app::state::ArtistBioPopup;
use crate::app::tasks::{self, TaskLease};
use crate::app::{AppState, Event};
use crate::plex::PlexClient;
use crate::services::biography::{self, BioImage, Biography};
use tokio::sync::mpsc;

pub fn show(
    state: &mut AppState,
    client: &PlexClient,
    tx: &mpsc::Sender<Event>,
    key: String,
    name: String,
) {
    state.artist_bio_request_id = state.artist_bio_request_id.wrapping_add(1);
    let request_id = state.artist_bio_request_id;
    let generation = state.library_generation;
    state.popups.close_all();
    let provider = (state.sources.active.is_plex() && !key.is_empty()).then(|| client.clone());
    let navidrome = state.sources.active.navidrome().cloned();
    let tx = tx.clone();
    let artist = name.clone();
    let task = tasks::spawn(async move {
        let result = if let Some(session) = navidrome {
            load_navidrome(&session, &key, &artist).await
        } else {
            load(provider, &key, &artist).await
        };
        let _ = tx
            .send(
                UiEvent::ArtistBioLoaded {
                    generation,
                    request_id,
                    result,
                }
                .into(),
            )
            .await;
    });
    state.popups.artist_bio = Some(ArtistBioPopup {
        artist_name: name,
        document: Biography::default(),
        scroll: 0,
        loading: true,
        image_index: 0,
        task: Some(TaskLease::new(&task)),
    });
}

async fn load_navidrome(
    session: &crate::app::sources::navidrome::Session,
    key: &str,
    name: &str,
) -> Result<Biography, String> {
    let provider = async {
        let id = session.id(key)?;
        let params = [("id", id), ("count", "0".into())];
        let response = tokio::time::timeout(
            std::time::Duration::from_secs(8),
            session.client.call("getArtistInfo2", &params),
        )
        .await??;
        let info = &response["artistInfo2"];
        let text = biography::fragment(info["biography"].as_str().unwrap_or_default());
        let mut document = Biography {
            text,
            ..Default::default()
        };
        if let Some(url) = info["lastFmUrl"]
            .as_str()
            .and_then(|s| reqwest::Url::parse(s).ok())
            .filter(|u| matches!(u.scheme(), "https" | "http"))
        {
            document.source_url = Some(url.to_string());
        }
        if !document.text.trim().is_empty() {
            if let Some(url) = info["largeImageUrl"]
                .as_str()
                .and_then(|s| reqwest::Url::parse(s).ok())
                .filter(|u| {
                    matches!(u.scheme(), "https" | "http")
                        && u.username().is_empty()
                        && u.password().is_none()
                })
            {
                // This client has no default Authorization header; never append server credentials to agent URLs.
                match tokio::time::timeout(
                    std::time::Duration::from_secs(3),
                    session.client.bytes(url.clone(), 8 * 1024 * 1024),
                )
                .await
                {
                    Ok(Ok(data)) => document.images.push(BioImage {
                        key: url.to_string(),
                        data,
                        caption: "Artist image supplied by Navidrome".into(),
                    }),
                    Ok(Err(error)) => tracing::warn!("Navidrome biography image: {error}"),
                    Err(_) => tracing::warn!("Navidrome biography image timed out"),
                }
            }
        }
        Ok::<_, anyhow::Error>(document)
    };
    match tokio::time::timeout(std::time::Duration::from_secs(12), provider).await {
        Ok(Ok(document)) if !document.text.trim().is_empty() => return Ok(document),
        Ok(Err(error)) => tracing::warn!("Navidrome biography: {error:#}"),
        Err(_) => tracing::warn!("Navidrome biography timed out"),
        _ => {}
    }
    biography::wikipedia(name)
        .await
        .map_err(|e| format!("Wikipedia: {e:#}"))
}

async fn load(provider: Option<PlexClient>, key: &str, name: &str) -> Result<Biography, String> {
    let mut provider_error = None;
    if let Some(client) = provider {
        match tokio::time::timeout(std::time::Duration::from_secs(8), client.get_artist(key)).await
        {
            Ok(Ok(artist)) => {
                if let Some(text) = artist.summary.filter(|s| !s.trim().is_empty()) {
                    let mut document = Biography {
                        text: crate::util::sanitize_display_text(&text).into_owned(),
                        ..Default::default()
                    };
                    if let Some(thumb) = artist.thumb {
                        match tokio::time::timeout(
                            std::time::Duration::from_secs(5),
                            client.fetch_artwork(&thumb, 600),
                        )
                        .await
                        {
                            Ok(Ok(data)) => document.images.push(BioImage {
                                key: thumb,
                                data,
                                caption: String::new(),
                            }),
                            _ => tracing::warn!("Artist biography loaded without Plex artwork"),
                        }
                    }
                    return Ok(document);
                }
            }
            Ok(Err(error)) => provider_error = Some(error.user_message("Plex biography")),
            Err(_) => provider_error = Some("Plex biography timed out".into()),
        }
    }
    biography::wikipedia(name)
        .await
        .map_err(|error| match provider_error {
            Some(provider) => format!("{provider}\n\nWikipedia: {error:#}"),
            None => format!("Wikipedia: {error:#}"),
        })
}
