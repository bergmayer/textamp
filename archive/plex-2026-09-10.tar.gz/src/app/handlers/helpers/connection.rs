//! Server connection discovery and testing.

/// Measure all discovered routes and return the fastest robust connection.
pub async fn find_working_connection(
    server: &crate::plex::models::PlexServer,
    token: &str,
    client_identifier: &str,
) -> Option<String> {
    find_working_connection_with_urls(server, token, client_identifier, &[])
        .await
        .map(|selection| selection.selected.url)
}

pub async fn find_working_connection_with_urls(
    server: &crate::plex::models::PlexServer,
    token: &str,
    client_identifier: &str,
    extra_urls: &[String],
) -> Option<crate::plex::ConnectionSelection> {
    match crate::plex::select_connection(server, token, client_identifier, extra_urls).await {
        Ok(selection) => Some(selection),
        Err(error) => {
            tracing::warn!(
                "All connection probes failed for {}: {}",
                server.name,
                error
            );
            None
        }
    }
}

/// Find the first working connection across multiple servers.
pub async fn find_working_connection_from_servers(
    servers: &[crate::plex::models::PlexServer],
    token: &str,
    client_identifier: &str,
) -> Option<String> {
    find_working_connection_from_servers_with_urls(servers, token, client_identifier, &[]).await
}

pub async fn find_working_connection_from_servers_with_urls(
    servers: &[crate::plex::models::PlexServer],
    token: &str,
    client_identifier: &str,
    extra_urls: &[String],
) -> Option<String> {
    for server in servers {
        if let Some(selection) =
            find_working_connection_with_urls(server, token, client_identifier, extra_urls).await
        {
            return Some(selection.selected.url);
        }
    }
    None
}
