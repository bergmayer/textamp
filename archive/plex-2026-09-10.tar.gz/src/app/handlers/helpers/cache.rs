//! Cache saving and background data refresh.

use crate::app::event::*;
use crate::app::{AppState, Event};
use crate::plex::LibraryCache;
use tokio::sync::mpsc;

/// Check if we should save the cache and spawn async save if conditions are met.
pub fn maybe_save_cache_async(event_tx: &mpsc::Sender<Event>, state: &mut AppState) {
    if !state.sources.active.is_plex() {
        return;
    }
    if !state.cache_mgmt.dirty || state.cache_mgmt.save_in_progress {
        return;
    }

    let lib_key = match &state.active_library {
        Some(k) => k.clone(),
        None => return,
    };

    let idle_threshold = std::time::Duration::from_secs(30);
    if state.cache_mgmt.last_input_time.elapsed() < idle_threshold {
        return;
    }

    let save_interval = std::time::Duration::from_secs(120);
    if state.cache_mgmt.last_save.elapsed() < save_interval {
        return;
    }

    state.cache_mgmt.save_in_progress = true;
    state.cache_mgmt.dirty = false;
    state.cache_mgmt.last_save = std::time::Instant::now();

    let Some(cache_data) = snapshot(state, SnapshotMode::Preserve) else {
        return;
    };
    let event_tx = LibraryEventSender::new(event_tx.clone(), state.library_generation);
    crate::app::tasks::spawn(async move {
        let result = crate::app::tasks::spawn_blocking(move || {
            let cache = LibraryCache::new()
                .ok_or_else(|| "Library cache directory is unavailable".to_string())?;
            if cache.save_preserving_unloaded(cache_data) {
                Ok(())
            } else {
                Err(format!(
                    "Failed to save cache for library {lib_key}; see log for details"
                ))
            }
        })
        .await
        .unwrap_or_else(|error| Err(format!("Cache worker failed: {error}")));
        let _ = event_tx
            .send(CacheEvent::CacheSaved { result }.into())
            .await;
    });
}

#[derive(Clone, Copy)]
pub enum SnapshotMode {
    Preserve,
    Drain,
}

impl SnapshotMode {
    fn collect<T: Clone + Default>(self, value: &mut T) -> T {
        match self {
            Self::Preserve => value.clone(),
            Self::Drain => std::mem::take(value),
        }
    }
}

/// One field mapping for periodic snapshots and ownership transfer at quit.
pub fn snapshot(state: &mut AppState, mode: SnapshotMode) -> Option<crate::plex::CacheData> {
    let lib_key = state.active_library.clone()?;
    let lib_key = lib_key.as_str();
    let smart_playlist_keys: std::collections::HashSet<String> = state
        .library
        .playlists
        .iter()
        .filter(|playlist| playlist.smart)
        .map(|playlist| playlist.rating_key.clone())
        .collect();
    use crate::plex::CacheData;
    let mut cache_data = CacheData::new_scoped(lib_key, state.active_server_id.as_deref());
    // Write per-category timestamps
    cache_data.category_timestamps = state
        .cache_mgmt
        .category_timestamps
        .iter()
        .map(|(cat, &ts)| (cat.cache_key().to_string(), ts))
        .collect();
    // Write legacy timestamps for backward compat
    if let Some(&ts) = state
        .cache_mgmt
        .category_timestamps
        .get(&crate::app::state::RefreshCategory::Artists)
    {
        cache_data.timestamp = ts;
    }
    if let Some(&ts) = state
        .cache_mgmt
        .category_timestamps
        .get(&crate::app::state::RefreshCategory::Playlists)
    {
        cache_data.playlist_timestamp = ts;
    }
    cache_data.artists = mode.collect(&mut state.library.artists);
    cache_data.albums = mode.collect(&mut state.library.albums);
    cache_data.playlists = mode.collect(&mut state.library.playlists);
    if let Some(ref folder_state) = state.folder_state {
        if folder_state.library_key == lib_key {
            if let Some(root_col) = folder_state.columns.first() {
                cache_data.root_folders = root_col.unshuffled_items().to_vec();
            }
        } else {
            tracing::debug!("Not saving folder_state (periodic) - belongs to different library (expected {}, got {})",
                lib_key, folder_state.library_key);
        }
    }
    cache_data.folder_contents = mode.collect(&mut state.folder_contents_cache);
    if !state.keep_subfolder_cache {
        cache_data.folder_contents.retain(|_, cached| {
            !cached.is_older_than(crate::plex::constants::CACHE_RETENTION_THRESHOLD_SECS)
        });
    }
    cache_data.artist_genres = mode.collect(&mut state.library.artist_genres);
    cache_data.album_genres = mode.collect(&mut state.library.album_genres);
    cache_data.genres = cache_data.album_genres.clone();
    cache_data.moods = mode.collect(&mut state.library.moods);
    cache_data.styles = mode.collect(&mut state.library.styles);
    cache_data.decades = mode.collect(&mut state.library.decades);
    cache_data.years = mode.collect(&mut state.library.years);
    cache_data.collections = mode.collect(&mut state.library.collections);
    cache_data.countries = mode.collect(&mut state.library.countries);
    cache_data.labels = mode.collect(&mut state.library.labels);
    cache_data.formats = mode.collect(&mut state.library.formats);
    cache_data.studios = mode.collect(&mut state.library.studios);
    // Save root column stations (not state.stations which may be drilled children)
    cache_data.stations = state
        .station_nav
        .columns
        .first()
        .map(|c| c.unshuffled_stations().to_vec())
        .unwrap_or_default();
    cache_data.station_children = mode.collect(&mut state.station_children_cache);

    // All tracks + track-level artists + aliases
    // Only save if non-empty to avoid overwriting cached data when preload is in-flight
    if !state.library.all_tracks.is_empty() {
        cache_data.all_tracks = mode.collect(&mut state.library.all_tracks);
        cache_data.track_artists = mode.collect(&mut state.library.track_artists);
    }
    cache_data.artist_aliases = mode.collect(&mut state.library.artist_aliases);
    cache_data.album_display_artist = mode.collect(&mut state.library.album_display_artist);

    // Compilation detection results
    cache_data.compilation_albums = mode.collect(&mut state.library.compilations.albums);
    cache_data.compilation_artist_keys = mode.collect(&mut state.library.compilations.artist_keys);
    cache_data.compilation_track_artist_keys =
        mode.collect(&mut state.library.compilations.track_artist_keys);
    cache_data.artist_compilation_map = mode.collect(&mut state.library.compilations.artist_map);
    cache_data.single_artist_compilations =
        mode.collect(&mut state.library.compilations.single_artist);

    cache_data.playlist_tracks = mode.collect(&mut state.playlist_tracks_cache);
    cache_data
        .playlist_tracks
        .retain(|key, _| !smart_playlist_keys.contains(key));
    Some(cache_data)
}
