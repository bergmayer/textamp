//! Background data preloading for faster access.

use crate::app::event::LibraryEventSender;
use crate::app::event::*;
use crate::app::Event;
use crate::plex::PlexClient;
use tokio::sync::mpsc;

use crate::app::state::RefreshCategory;

impl RefreshCategory {
    /// One request implementation shared by startup preloads and refreshes.
    /// Errors stay errors until the caller decides how to surface them.
    pub(super) async fn fetch(
        self,
        client: &PlexClient,
        library_key: String,
        lib_title: String,
    ) -> Result<Event, crate::plex::ApiError> {
        use crate::app::state::RefreshCategory;
        use crate::services::{FolderColumn, FolderNavigationState, FolderService};

        // Larger database queries get one minute per page/request, while the
        // enclosing job still has a hard total deadline. Audio is unaffected.
        let library_client = matches!(self, Self::Albums | Self::AllTracks | Self::Folders)
            .then(|| client.clone_with_timeout(std::time::Duration::from_secs(60)));
        let client = library_client.as_ref().unwrap_or(client);

        match self {
            Self::Artists | Self::AlbumArtists => {
                let items = client.get_artists(&library_key).await?;
                Ok(DataEvent::ArtistsLoaded {
                    library_key,
                    result: Ok(items),
                }
                .into())
            }
            Self::Albums => {
                let items = client.get_albums(&library_key).await?;
                Ok(PreloadEvent::AlbumsPreloaded {
                    library_key,
                    albums: items,
                }
                .into())
            }
            Self::Playlists => {
                let items = client.get_playlists(None).await?;
                Ok(DataEvent::PlaylistsLoaded {
                    server_url: client.server_url().map(str::to_owned),
                    result: Ok(items),
                }
                .into())
            }
            Self::Moods => {
                let items = client.get_moods(&library_key).await?;
                Ok(PreloadEvent::MoodsPreloaded {
                    library_key,
                    moods: items,
                }
                .into())
            }
            Self::ArtistGenres => {
                let items = client.get_artist_genres(&library_key).await?;
                Ok(PreloadEvent::ArtistGenresPreloaded {
                    library_key,
                    genres: items,
                }
                .into())
            }
            Self::AlbumGenres => {
                let items = client.get_album_genres(&library_key).await?;
                Ok(PreloadEvent::AlbumGenresPreloaded {
                    library_key,
                    genres: items,
                }
                .into())
            }
            Self::Styles => {
                let items = client.get_styles(&library_key).await?;
                Ok(PreloadEvent::StylesPreloaded {
                    library_key,
                    styles: items,
                }
                .into())
            }
            Self::Decades => {
                let items = client.get_decades(&library_key).await?;
                Ok(PreloadEvent::TagListPreloaded {
                    library_key,
                    category: RefreshCategory::Decades,
                    items,
                }
                .into())
            }
            Self::Years => {
                let items = client.get_years(&library_key).await?;
                Ok(PreloadEvent::TagListPreloaded {
                    library_key,
                    category: RefreshCategory::Years,
                    items,
                }
                .into())
            }
            Self::Collections => {
                let items = client.get_collections(&library_key).await?;
                Ok(PreloadEvent::TagListPreloaded {
                    library_key,
                    category: RefreshCategory::Collections,
                    items,
                }
                .into())
            }
            Self::Countries => {
                let items = client.get_countries(&library_key).await?;
                Ok(PreloadEvent::TagListPreloaded {
                    library_key,
                    category: RefreshCategory::Countries,
                    items,
                }
                .into())
            }
            Self::Labels => {
                let items = client.get_labels(&library_key).await?;
                Ok(PreloadEvent::TagListPreloaded {
                    library_key,
                    category: RefreshCategory::Labels,
                    items,
                }
                .into())
            }
            Self::Formats => {
                let items = client.get_formats(&library_key).await?;
                Ok(PreloadEvent::TagListPreloaded {
                    library_key,
                    category: RefreshCategory::Formats,
                    items,
                }
                .into())
            }
            Self::Studios => {
                let items = client.get_studios(&library_key).await?;
                Ok(PreloadEvent::TagListPreloaded {
                    library_key,
                    category: RefreshCategory::Studios,
                    items,
                }
                .into())
            }
            Self::Stations => {
                let items = client.get_stations(&library_key).await?;
                Ok(PreloadEvent::StationsPreloaded {
                    library_key,
                    stations: items,
                }
                .into())
            }
            Self::AllTracks => {
                let items = client.get_tracks(&library_key).await?;
                Ok(PreloadEvent::AllTracksPreloaded {
                    library_key,
                    tracks: items,
                }
                .into())
            }
            Self::Folders => {
                let response = client.get_library_folders(&library_key).await?;
                let items = FolderService::from_response(&response);
                let root = FolderColumn::new(None, lib_title, items);
                let folder_state = FolderNavigationState::with_root(library_key.clone(), root);
                Ok(FolderEvent::FoldersPreloaded {
                    library_key,
                    folder_state,
                }
                .into())
            }
        }
    }
}

/// Preload data in background for faster access.
pub fn preload_data(
    event_tx: &mpsc::Sender<Event>,
    category: RefreshCategory,
    lib_key: &str,
    client: &PlexClient,
    state: &mut crate::app::AppState,
) {
    let category = category.canonical();
    if state.cache_mgmt.requests.contains_key(&category)
        || state.cache_mgmt.pending.contains(&category)
    {
        return;
    }
    if state.cache_mgmt.failures.contains_key(&category) {
        state
            .cache_mgmt
            .preloads_in_progress
            .remove(category.progress_label());
        if state.cache_mgmt.preloads_in_progress.is_empty() {
            state.cache_mgmt.preloads_total = 0;
        }
        match category {
            RefreshCategory::Artists => state.library.artists_loading = false,
            RefreshCategory::Playlists => state.library.playlists_loading = false,
            _ => {}
        }
        return;
    }
    state.cache_mgmt.background_refresh.insert(category);
    state.cache_mgmt.pending.push_back(category);
    pump_category_loads(event_tx, state, client);
    // All callers use the active library; never enqueue cross-library work.
    debug_assert_eq!(state.active_library.as_deref(), Some(lib_key));
}

/// At most two expensive category requests run at once. Interactive lookups
/// and playback do not wait in this queue. Tick/completion events drain it.
pub fn pump_category_loads(
    event_tx: &mpsc::Sender<Event>,
    state: &mut crate::app::AppState,
    client: &PlexClient,
) {
    if state.should_quit {
        return;
    }
    let Some(lib_key) = state.active_library.clone() else {
        return;
    };
    let now = std::time::Instant::now();
    for (&category, failure) in &mut state.cache_mgmt.failures {
        if failure.retry_at.is_some_and(|at| now >= at) {
            failure.retry_at = None;
            if !state.cache_mgmt.requests.contains_key(&category)
                && !state.cache_mgmt.pending.contains(&category)
            {
                state.cache_mgmt.pending.push_back(category);
                state.cache_mgmt.background_refresh.insert(category);
            }
        }
    }
    if let Some(category) = super::refresh::current_view_category(state).map(|c| c.canonical()) {
        if let Some(index) = state.cache_mgmt.pending.iter().position(|c| *c == category) {
            state.cache_mgmt.pending.remove(index);
            state.cache_mgmt.pending.push_front(category);
        }
    }
    while state.cache_mgmt.requests.len() < 2 {
        let Some(category) = state.cache_mgmt.pending.pop_front() else {
            break;
        };
        start_category_load(event_tx, category, &lib_key, client, state);
    }
}

fn start_category_load(
    event_tx: &mpsc::Sender<Event>,
    category: RefreshCategory,
    lib_key: &str,
    client: &PlexClient,
    state: &mut crate::app::AppState,
) {
    let lib_title = state
        .libraries
        .iter()
        .find(|library| library.key == lib_key)
        .map(|library| library.title.clone())
        .unwrap_or_else(|| "Music".into());
    state.cache_mgmt.request_sequence = state.cache_mgmt.request_sequence.wrapping_add(1);
    let request_id = state.cache_mgmt.request_sequence;
    let generation = state.library_generation;
    let event_tx = event_tx.clone();
    let client = client.clone();
    let library_key = lib_key.to_string();
    let task = crate::app::tasks::spawn(async move {
        let started = std::time::Instant::now();
        let deadline = std::time::Duration::from_secs(if category == RefreshCategory::AllTracks {
            600
        } else {
            120
        });
        let fetch = tokio::time::timeout(deadline, category.fetch(&client, library_key, lib_title))
            .await
            .unwrap_or(Err(crate::plex::ApiError::Timeout));
        let result = match fetch {
            Ok(event) => Ok(Box::new(event)),
            Err(error) => {
                tracing::error!(
                    "{} load failed after {:?} (timeout={}): {:?}",
                    category.display_name(),
                    started.elapsed(),
                    error.is_timeout(),
                    error
                );
                let mut failure = crate::app::action::AsyncError::from_api(
                    &format!("Load {}", category.display_name()),
                    &error,
                );
                if error.is_timeout() {
                    // A slow library query is not evidence of a dead route.
                    failure.connection_error = match client.server_url() {
                        Some(url) => crate::plex::test_connection_for_server(
                            url,
                            &client.shared_token_or_empty(),
                            client.client_identifier(),
                            None,
                        )
                        .await
                        .is_err(),
                        None => true,
                    };
                }
                Err(CategoryLoadError {
                    error: failure,
                    retryable: error.is_retryable(),
                })
            }
        };
        let _ = event_tx
            .send(Event::CategoryResult {
                generation,
                category,
                request_id,
                result,
            })
            .await;
    });
    state.cache_mgmt.requests.insert(
        category,
        (request_id, crate::app::tasks::TaskLease::new(&task)),
    );
}

/// Start background subfolder pre-caching if root folders are available.
///
/// Crawls root-level folder keys and fetches their immediate contents from the Plex API,
/// sending results back in batches. Skips folders that are already cached and fresh
/// (< one week old). Stale entries are re-fetched incrementally — the old data stays
/// available as a warm cache until overwritten by fresh results.
/// Rate-limited to ~50ms between requests to avoid overloading the server.
/// Result of attempting to start a subfolder preload.
pub enum SubfolderPreloadResult {
    /// Crawl started successfully
    Started,
    /// Already running
    AlreadyActive,
    /// No active library selected
    NoLibrary,
    /// Root folders not loaded yet
    NoRootFolders,
    /// Root has no subfolders (only tracks)
    NoSubfolders,
    /// All subfolders already cached and fresh
    AllCached { count: usize },
}

pub fn maybe_start_subfolder_preload(
    event_tx: &mpsc::Sender<Event>,
    state: &mut crate::app::AppState,
    client: &PlexClient,
) -> SubfolderPreloadResult {
    use crate::plex::constants::CACHE_STALE_THRESHOLD_SECS;
    use std::collections::HashSet;

    // Guard: already active
    if state.subfolder_preload.is_some() {
        return SubfolderPreloadResult::AlreadyActive;
    }

    // Guard: no active library
    let Some(lib_key) = state.active_library.clone() else {
        return SubfolderPreloadResult::NoLibrary;
    };

    // Guard: no root folders loaded yet
    let Some(ref folder_state) = state.folder_state else {
        return SubfolderPreloadResult::NoRootFolders;
    };
    if folder_state.columns.is_empty() {
        return SubfolderPreloadResult::NoRootFolders;
    }

    // Extract root folder keys (only folders, not tracks)
    let root_folder_keys: Vec<String> = folder_state.columns[0]
        .items
        .iter()
        .filter(|item| item.is_folder())
        .map(|item| item.key.clone())
        .collect();

    if root_folder_keys.is_empty() {
        return SubfolderPreloadResult::NoSubfolders;
    }

    // BFS through cache to collect ALL known child folder keys at any depth
    let all_cached_child_keys =
        collect_cached_child_keys(&root_folder_keys, &state.folder_contents_cache);

    // Determine which keys need fetching (missing or at least one week old)
    let root_keys_to_fetch = crate::services::keys_needing_refresh(
        &root_folder_keys,
        &state.folder_contents_cache,
        CACHE_STALE_THRESHOLD_SECS,
    );

    let child_keys_to_fetch = if all_cached_child_keys.is_empty() {
        Vec::new()
    } else {
        crate::services::keys_needing_refresh(
            &all_cached_child_keys,
            &state.folder_contents_cache,
            CACHE_STALE_THRESHOLD_SECS,
        )
    };

    if root_keys_to_fetch.is_empty() && child_keys_to_fetch.is_empty() {
        let total = root_folder_keys.len() + all_cached_child_keys.len();
        tracing::debug!(
            "All {} folder listings cached and fresh ({} root, {} descendant), skipping preload",
            total,
            root_folder_keys.len(),
            all_cached_child_keys.len()
        );
        return SubfolderPreloadResult::AllCached { count: total };
    }

    // Combine into initial fetch list
    let mut keys_to_fetch = root_keys_to_fetch;
    keys_to_fetch.extend(child_keys_to_fetch);

    let uncached_count = keys_to_fetch
        .iter()
        .filter(|k| !state.folder_contents_cache.contains_key(k.as_str()))
        .count();
    let stale_count = keys_to_fetch.len() - uncached_count;
    tracing::info!(
        "Starting subfolder preload: {} to fetch ({} uncached, {} stale), {} already fresh",
        keys_to_fetch.len(),
        uncached_count,
        stale_count,
        root_folder_keys.len() + all_cached_child_keys.len() - keys_to_fetch.len()
    );

    if !client.has_server() {
        return SubfolderPreloadResult::NoLibrary;
    }
    state.subfolder_preload_id = state.subfolder_preload_id.wrapping_add(1);
    let request_id = state.subfolder_preload_id;
    let client = client.clone();
    let event_tx = LibraryEventSender::new(event_tx.clone(), state.library_generation);

    let task = crate::app::tasks::spawn(async move {
        use crate::plex::CachedFolder;
        use crate::services::FolderService;
        use futures::{stream, StreamExt};

        // Let other preloads finish first
        tokio::time::sleep(std::time::Duration::from_secs(10)).await;

        // Track all keys we've ever queued for fetching (cycle prevention)
        let mut all_fetched_keys: HashSet<String> = keys_to_fetch.iter().cloned().collect();
        let mut current_keys = keys_to_fetch;
        let mut batch: Vec<(String, CachedFolder)> = Vec::new();
        let mut total_fetched = 0u64;
        let mut depth = 0u32;

        // Iterative crawl: fetch current level, discover children, repeat
        loop {
            if current_keys.is_empty() {
                break;
            }

            tracing::info!(
                "Subfolder crawl depth {}: {} keys to fetch",
                depth,
                current_keys.len()
            );

            // Only four request futures exist at a time; dropping the stream
            // cancels them, without detached tasks waiting on a semaphore.
            let mut requests = stream::iter(current_keys)
                .map(|folder_key| {
                    let client = &client;
                    async move {
                        let response = client.get_folder_contents(&folder_key).await?;
                        let items = FolderService::from_response(&response);
                        let path = FolderService::folder_path(&response);
                        Ok::<_, crate::plex::ApiError>((
                            folder_key,
                            CachedFolder::with_path(items, path),
                        ))
                    }
                })
                .buffer_unordered(4);
            let mut next_keys = Vec::new();

            while let Some(result) = requests.next().await {
                match result {
                    Err(error) => tracing::warn!("Subfolder preload failed: {error}"),
                    Ok(entry) => {
                        // Discover child folder keys from this result
                        for item in &entry.1.items {
                            if item.is_folder() && all_fetched_keys.insert(item.key.clone()) {
                                next_keys.push(item.key.clone());
                            }
                        }

                        batch.push(entry);
                        total_fetched += 1;

                        // Send batch every 10 entries for responsive UI updates
                        if batch.len() >= 10 {
                            tracing::debug!(
                                "Subfolder preload batch: {} fetched so far",
                                total_fetched
                            );
                            let _ = event_tx
                                .send(
                                    FolderEvent::SubfoldersPreloaded {
                                        library_key: lib_key.clone(),
                                        request_id,
                                        entries: std::mem::take(&mut batch),
                                        done: false,
                                    }
                                    .into(),
                                )
                                .await;
                        }
                    }
                }
            }

            // Send remaining batch from this level
            if !batch.is_empty() {
                let _ = event_tx
                    .send(
                        FolderEvent::SubfoldersPreloaded {
                            library_key: lib_key.clone(),
                            request_id,
                            entries: std::mem::take(&mut batch),
                            done: false,
                        }
                        .into(),
                    )
                    .await;
            }

            if next_keys.is_empty() {
                break;
            }

            current_keys = next_keys;
            depth += 1;
        }

        // This is an incremental crawl: fresh branches are skipped and failed
        // requests provide no evidence of deletion. Never prune unseen keys.
        let _ = event_tx
            .send(
                FolderEvent::SubfoldersPreloaded {
                    library_key: lib_key,
                    request_id,
                    entries: batch,
                    done: true,
                }
                .into(),
            )
            .await;
    });

    state.subfolder_preload = Some(crate::app::tasks::TaskLease::new(&task));
    SubfolderPreloadResult::Started
}

/// BFS through cached folder contents to collect all known child folder keys.
fn collect_cached_child_keys(
    parent_keys: &[String],
    cache: &std::collections::HashMap<String, crate::plex::CachedFolder>,
) -> Vec<String> {
    use std::collections::HashSet;

    let mut all_keys = Vec::new();
    let mut frontier = parent_keys.to_vec();
    let mut visited: HashSet<String> = parent_keys.iter().cloned().collect();

    while !frontier.is_empty() {
        let mut next = Vec::new();
        for key in &frontier {
            if let Some(cached) = cache.get(key.as_str()) {
                for item in &cached.items {
                    if item.is_folder() && visited.insert(item.key.clone()) {
                        all_keys.push(item.key.clone());
                        next.push(item.key.clone());
                    }
                }
            }
        }
        frontier = next;
    }

    all_keys
}

/// Preload all library data in background.
pub fn preload_all_library_data(
    event_tx: &mpsc::Sender<Event>,
    lib_key: &str,
    _lib_title: &str,
    client: &PlexClient,
    state: &mut crate::app::AppState,
) {
    let mut preloads: Vec<_> = RefreshCategory::all()
        .iter()
        .copied()
        .filter(|c| c.canonical() == *c)
        .collect();
    let visible = super::refresh::current_view_category(state).map(|c| c.canonical());
    preloads.sort_by_key(|category| Some(*category) != visible);
    state.cache_mgmt.preloads_in_progress = preloads
        .iter()
        .map(|preload| preload.progress_label().to_string())
        .collect();
    state.cache_mgmt.preloads_total = preloads.len();
    for preload in preloads {
        preload_data(event_tx, preload, lib_key, client, state);
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::collections::HashSet;

    #[test]
    fn initial_progress_entries_exactly_match_unique_jobs() {
        let preloads: Vec<_> = RefreshCategory::all()
            .iter()
            .filter(|c| c.canonical() == **c)
            .collect();
        let labels: HashSet<_> = preloads.iter().map(|c| c.progress_label()).collect();

        assert_eq!(preloads.len(), 17);
        assert_eq!(labels.len(), preloads.len());
        assert!(!labels.contains("Genres"));
        assert!(labels.contains("Artist Genres"));
        assert!(labels.contains("Album Genres"));
        assert!(labels.contains("Tracks"));
    }

    #[test]
    fn changing_library_clears_progress_from_discarded_results() {
        let mut state = crate::app::AppState::new();
        state
            .cache_mgmt
            .preloads_in_progress
            .insert("Artists".to_string());
        state.cache_mgmt.preloads_total = 1;

        state.advance_library_generation();

        assert!(state.cache_mgmt.preloads_in_progress.is_empty());
        assert_eq!(state.cache_mgmt.preloads_total, 0);
    }
}
