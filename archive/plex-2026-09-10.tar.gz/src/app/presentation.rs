//! Render feedback shared by the renderer and input reducer.
//! Rendering builds a fresh value; only the event loop installs it in AppState.

use ratatui::layout::Rect;

/// Registry of all clickable regions, populated each frame during render.
#[derive(Debug, Default, Clone)]
pub struct HitRegions {
    pub settings_sections: Option<CategoryColumnRegion>,
    pub settings_textamp: Option<SettingsContentRegion>,
    /// Actual wrapped help content and viewport, including split layouts.
    pub help: Option<HelpRegion>,
    // ── Modal popups (checked first, highest priority) ──────────────────────
    /// Confirm dialog (Yes/No buttons).
    pub confirm_dialog: Option<DialogRegions>,
    /// Ordered form controls / account action buttons.
    pub library_dialog: Vec<Rect>,

    /// Library picker (F3 popup).
    pub library_picker: Option<PopupListRegions>,
    pub library_manager_tabs: Vec<(Rect, crate::app::sources::manager::Tab)>,
    pub library_sonic_toggle: Option<Rect>,
    pub library_audiomuse: Option<Rect>,

    /// Search/filter popup (Ctrl+F overlay).
    pub search_popup: Option<SearchPopupRegions>,

    /// Command palette overlay (`:` palette).
    pub command_palette: Option<CommandPaletteRegions>,

    /// Sort popup (Ctrl+S).
    pub sort_popup: Option<SortPopupRegions>,

    /// Artist radio picker popup.
    pub artist_radio_picker: Option<PopupListRegions>,

    /// Adventure launcher popup.
    pub adventure_launcher: Option<AdventureLauncherRegions>,

    // ── Chrome (always present when not in Auth view) ───────────────────────
    /// Tab bar (top row).
    pub tab_bar: Option<TabBarRegions>,

    /// Transport bar (playback controls, seek bar).
    pub transport: Option<TransportRegions>,

    /// Command/shortcut bar (bottom rows).
    pub command_bar: Option<CommandBarRegions>,

    // ── Content (view-dependent, mutually exclusive) ────────────────────────
    /// Category selector column (Browse view, column 0).
    pub category_column: Option<CategoryColumnRegion>,
    /// Noninteractive Search landing panel, replacing the retained browse columns.
    pub search_landing: Option<Rect>,

    /// Browse alphabet jump strip (between category column and the
    /// first Miller column when on Library + sortable).
    pub alphabet_strip: Option<AlphabetStripRegions>,

    /// Miller columns (Browse view, content columns).
    pub miller_columns: Option<MillerRegions>,

    /// Track-details pane regions (right-side pane on Browse view
    /// when a Track row is focused). Holds the Play button rect
    /// and the per-similar-track row rects so the mouse handler
    /// can dispatch the right action.
    pub track_pane: Option<TrackPaneRegions>,

    /// Queue view content areas.
    pub queue_content: Option<QueueRegions>,

    /// Now Playing visualizer content areas.
    pub now_playing_content: Option<NowPlayingRegions>,

    /// Now Playing left sidebar buttons (Radio / DJ Modes / Remix /
    /// Clear Queue). Cleared and rebuilt every render of the queue
    /// view. Stored as a flat list of `(area, which)` pairs because
    /// the set is small and the click site only needs sequential
    /// hit-testing.
    pub now_playing_sidebar: Option<Vec<(Rect, NpSidebarButton)>>,

    /// Similar popup (outer rect).
    pub similar_content: Option<SimilarRegions>,

    /// Related popup (outer rect).
    pub related_content: Option<RelatedRegions>,

    /// Tall-mode split: top half (library / browse) and bottom half
    /// (now-playing / queue). Populated only when `state.tall_mode` is
    /// active and the current view is tall-eligible. Used by the
    /// mouse handler to flip the active view (`Browse` ↔ `NowPlaying`)
    /// when the user clicks across the boundary.
    pub tall_mode_split: Option<TallModeSplit>,

    /// Niri-style horizontal scrollbar at the bottom of the Browse
    /// view in scrolling Miller-column mode. Populated when there
    /// are more ribbon slots than fit on screen; the mouse handler
    /// translates click / drag positions into a manual ribbon
    /// scroll position.
    pub miller_h_scrollbar: Option<MillerHScrollbar>,
}

/// Visible selectable rows in settings; headings and spacers have no hit target.
#[derive(Debug, Clone)]
pub struct SettingsContentRegion {
    pub inner: Rect,
    pub rows: Vec<(Rect, usize)>,
    pub scroll_offset: usize,
    pub total_lines: usize,
}

impl HitRegions {
    /// Reset all regions. Called at the start of each render frame.
    pub fn clear(&mut self) {
        *self = Self::default();
    }
}

// ── Sub-structs ─────────────────────────────────────────────────────────────

#[derive(Debug, Clone)]
pub struct HelpRegion {
    pub area: Rect,
    pub lines: usize,
    pub visible: usize,
}
impl HelpRegion {
    pub fn max_scroll(&self) -> u16 {
        self.lines
            .saturating_sub(self.visible)
            .min(u16::MAX as usize) as u16
    }
}

/// Tall-mode vertical split: where the boundary between the two halves
/// lives in the current frame. The top half includes everything up to
/// (but excluding) the separator row; the bottom half is below the
/// separator and includes the transport bar.
#[derive(Debug, Clone)]
pub struct TallModeSplit {
    pub top: Rect,
    pub bottom: Rect,
}

/// Horizontal scrollbar for the scrolling Miller-column ribbon.
/// `rail` is the full clickable strip (one row tall, full content
/// width). The thumb visually highlights the segment
/// `[thumb_x, thumb_x + thumb_w)` inside the rail.
#[derive(Debug, Clone)]
pub struct MillerHScrollbar {
    pub rail: Rect,
    pub thumb_x: u16,
    pub thumb_w: u16,
    /// Total ribbon slots — used to map a click x-position into a
    /// ribbon scroll offset (`(rel_x * total) / rail.width`).
    pub total: usize,
    pub visible: usize,
}

/// Confirm dialog regions (Yes/No buttons).
#[derive(Debug, Clone)]
pub struct DialogRegions {
    pub outer: Rect,
    pub yes_button: Rect,
    pub no_button: Rect,
}

/// A simple popup with a list of items.
#[derive(Debug, Clone)]
pub struct PopupListRegions {
    /// Outer popup rect (border included).
    pub outer: Rect,
    /// Inner area where items are rendered.
    pub items_area: Rect,
    /// Number of items in the list.
    pub item_count: usize,
}

/// Search/filter popup regions.
#[derive(Debug, Clone)]
pub struct SearchPopupRegions {
    /// Outer popup rect.
    pub outer: Rect,
    /// Tab bar area (2 rows).
    pub tab_area: Rect,
    /// Search input area (3 rows with border).
    pub input_area: Rect,
    /// Results list area.
    pub results_area: Rect,
}

/// Command palette overlay regions. Clicking inside `outer` but not
/// on a `rows` rect is a no-op (keeps the palette open). Clicking
/// outside `outer` cancels (closes) the palette. Clicking a row
/// selects that row and executes its command.
#[derive(Debug, Clone)]
pub struct CommandPaletteRegions {
    /// Outer popup rect (border included).
    pub outer: Rect,
    /// One rect per visible row, paired with the index into
    /// `state.palette.matches` (NOT `state.palette.entries` —
    /// `matches` is the filtered slice the renderer iterates over).
    pub rows: Vec<(Rect, usize)>,
}

/// Sort popup regions.
#[derive(Debug, Clone)]
pub struct SortPopupRegions {
    /// Outer popup rect (border included).
    pub outer: Rect,
    /// Inner area where options are rendered.
    pub inner: Rect,
    /// Number of options.
    pub option_count: usize,
}

/// Adventure launcher popup regions (multi-step).
#[derive(Debug, Clone)]
pub struct AdventureLauncherRegions {
    /// Outer popup rect.
    pub outer: Rect,
    /// Inner area (border excluded).
    pub inner: Rect,
    /// Number of items currently visible in the results list.
    pub item_count: usize,
    /// Y offset where the results list starts (relative to inner.y).
    pub results_y_offset: u16,
}

/// Tab bar regions.
#[derive(Debug, Clone)]
pub struct TabBarRegions {
    /// Library name label (clickable to open library picker).
    pub library_label: Option<Rect>,
    /// Quit button.
    pub quit_button: Option<Rect>,
    /// Navigation tabs: (rect, tab_index).
    pub tabs: Vec<(Rect, usize)>,
}

/// Transport bar regions.
#[derive(Debug, Clone)]
pub struct TransportRegions {
    /// Play/pause button area.
    pub play_pause: Rect,
    /// Seek bar area.
    pub seekbar: Rect,
    /// Previous track button.
    pub prev_track: Rect,
    /// Next track button.
    pub next_track: Rect,
    /// Track info area (clickable to go to Now Playing).
    pub track_info: Option<Rect>,
    /// Search/filter icon area (left of speaker icon).
    pub search_icon: Option<Rect>,
    /// Speaker icon area (clickable to show volume slider).
    pub speaker_icon: Option<Rect>,
    /// Volume slider bar area (when visible).
    pub volume_slider: Option<Rect>,
}

/// Command/shortcut bar regions.
#[derive(Debug, Clone)]
pub struct CommandBarRegions {
    /// Top row items: (rect, action_key).
    pub top_row: Vec<(Rect, String)>,
    /// Bottom row items: (rect, action_key).
    pub bottom_row: Vec<(Rect, String)>,
}

/// Browse alphabet jump strip — one rect per visible letter, in
/// `ALPHABET_STRIP_LETTERS` order (or reversed for descending sort).
#[derive(Debug, Clone)]
pub struct AlphabetStripRegions {
    pub area: Rect,
    /// (rect, alphabet-strip index) per letter cell. The index is
    /// into `ALPHABET_STRIP_LETTERS`, not the rendered visual order
    /// — that way descending sort doesn't flip click handling.
    pub letters: Vec<(Rect, usize)>,
}

/// Track-details pane click regions — Play button + similar-track
/// rows. Index space matches `state.track_pane_index`: 0 is the
/// Play button, 1..=N are the similar tracks in order.
#[derive(Debug, Clone)]
pub struct TrackPaneRegions {
    pub outer: Rect,
    pub play_button: Rect,
    /// (rect, index-into-similar-list) per visible similar track.
    pub similar_rows: Vec<(Rect, usize)>,
    /// Hit rect for the small "x" close glyph in the top-right
    /// corner. The pane is treated as a standard rightmost column
    /// for closing purposes — clicking the glyph clears the pane.
    pub close_x: Option<Rect>,
}

/// Category selector column region (Browse view, column 0).
#[derive(Debug, Clone)]
pub struct CategoryColumnRegion {
    pub scroll_offset: usize,
    /// Outer area (including border).
    pub area: Rect,
    /// Inner area (border excluded).
    pub inner: Rect,
    /// Number of category items.
    pub item_count: usize,
}

/// A single Miller column's registered geometry.
#[derive(Debug, Clone)]
pub struct MillerColumnRegion {
    /// Which column index in the navigation this represents.
    pub col_idx: usize,
    /// Outer area (including border).
    pub area: Rect,
    /// Inner area (border excluded).
    pub inner: Rect,
    /// Rows per item (1 or 2). Meaningless when `is_art_mode` is true.
    pub rows_per_item: u16,
    /// Whether this column is in artwork grid mode.
    pub is_art_mode: bool,
    /// Cell-row height the art-grid renderer used for art-height items
    /// in this column. Only meaningful when `is_art_mode` is true. The
    /// mouse hit-test reads this so it can never drift from the renderer
    /// (a previous mismatched formula was making clicks land on the
    /// album below the one the user clicked on).
    pub art_row_height: u16,
    /// Hit rect for the small "x" close glyph in the top-right
    /// corner. `None` for the root column (which isn't closeable).
    /// A click anywhere in this rect closes this column and every
    /// column to its right.
    pub close_x: Option<Rect>,
}

/// Miller columns layout regions.
#[derive(Debug, Clone)]
pub struct MillerRegions {
    /// Full area encompassing all columns.
    pub area: Rect,
    /// Per-column geometry.
    pub columns: Vec<MillerColumnRegion>,
}

/// Queue view regions.
#[derive(Debug, Clone)]
pub struct QueueRegions {
    /// Track list area (middle column).
    pub track_list: Rect,
    /// Track list inner area (border excluded).
    pub track_list_inner: Rect,
    /// Artwork area (right column).
    pub art_area: Rect,
}

/// Now Playing visualizer regions.
#[derive(Debug, Clone)]
pub struct NowPlayingRegions {
    /// Visualizer panel tab bar area (1 row for waveform/spectrum/spectrogram tabs).
    pub visualizer_tab_area: Rect,
    /// Visualizer panel content area (seekable waveform/spectrum/spectrogram area).
    pub visualizer_content_area: Rect,
}

/// Similar popup regions.
#[derive(Debug, Clone)]
pub struct SimilarRegions {
    /// Outer popup rect.
    pub outer: Rect,
    /// Inner content area (border excluded).
    pub inner: Rect,
    /// Rows per item (always 2 for similar view).
    pub rows_per_item: u16,
    /// Footer [Tab] hint clickable area.
    pub tab_hint: Option<Rect>,
}

/// Related popup regions.
#[derive(Debug, Clone)]
pub struct RelatedRegions {
    /// Outer popup rect.
    pub outer: Rect,
    /// Inner content area (border excluded).
    pub inner: Rect,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum NpSidebarButton {
    Radio,
    DjModes,
    Remix,
    ClearQueue,
}

impl NpSidebarButton {
    pub fn label(self) -> &'static str {
        match self {
            Self::Radio => "Radio",
            Self::DjModes => "DJ Modes",
            Self::Remix => "Remix Tools",
            Self::ClearQueue => "Clear Queue",
        }
    }
}

impl super::AppState {
    /// One order for keyboard, mouse and rendering; omit unsupported groups.
    pub fn now_playing_sidebar_buttons(&self) -> Vec<NpSidebarButton> {
        use NpSidebarButton::*;
        let mut buttons = vec![Radio];
        if super::state::DjMode::ALL.into_iter().any(|mode| {
            super::sources::command_visible(self, &super::state::PaletteCommandKind::ToggleDj(mode))
        }) {
            buttons.push(DjModes);
        }
        buttons.extend([Remix, ClearQueue]);
        buttons
    }
}

pub struct RenderFeedback {
    pub hit_regions: HitRegions,
    pub marquee: super::state::MarqueeState,
    pub marquee_subtitle: super::state::MarqueeState,
}

impl super::AppState {
    pub fn apply_render_feedback(&mut self, feedback: RenderFeedback) {
        self.hit_regions = feedback.hit_regions;
        self.marquee = feedback.marquee;
        self.marquee_subtitle = feedback.marquee_subtitle;
    }
}
