//! Library-manager lifecycle, independent of the selected playback source.
use super::*;
use crate::plex::library_directory::{self, Account};
use futures::{stream, StreamExt};

#[derive(Debug, Clone, Copy, Default, PartialEq, Eq)]
pub enum Tab {
    #[default]
    Libraries,
    Accounts,
    Add,
}
impl Tab {
    pub const ALL: [Self; 3] = [Self::Libraries, Self::Accounts, Self::Add];
    pub fn previous(self) -> Option<Self> {
        match self {
            Self::Libraries => None,
            Self::Accounts => Some(Self::Libraries),
            Self::Add => Some(Self::Accounts),
        }
    }
    pub fn next(self) -> Option<Self> {
        match self {
            Self::Libraries => Some(Self::Accounts),
            Self::Accounts => Some(Self::Add),
            Self::Add => None,
        }
    }
    pub fn title(self) -> &'static str {
        match self {
            Self::Libraries => "Libraries",
            Self::Accounts => "Accounts",
            Self::Add => "Add library",
        }
    }
}

pub fn select_tab(state: &mut AppState, tab: Tab) {
    state.sources.manager_tab = tab;
    state.popups.library_picker_index = 0;
    state.sources.picker_scroll_pin = None;
}

/// Restore configured sources without replacing the normal startup screen.
pub fn initialize(state: &mut AppState, config: &Config) {
    state.sources.audiomuse.connections = config.audiomuse_connections.clone();
    state.sources.sonic_disabled_libraries = config.sonic_disabled_libraries.clone();
    state.sources.folders = config.folder_sources.clone();
    state.sources.navidrome = config.navidrome_sources.clone();
    state.connection = ConnectionState::Authenticating;
    state.auth_state.step = super::super::state::AuthStep::Checking;
    state.popups.library_picker_active = false;
    select_tab(state, Tab::Libraries);
}

pub fn startup_choice(config: &Config) -> Option<LibraryChoice> {
    if let Some(selection) = &config.default_navidrome {
        if let Some(source) = config
            .navidrome_sources
            .iter()
            .find(|s| s.id == selection.source_id)
        {
            return Some(LibraryChoice::Navidrome {
                source: source.clone(),
                folder: selection.folder.clone(),
                name: String::new(),
            });
        }
    }
    config.default_folder_source.as_ref().and_then(|id| {
        config
            .folder_sources
            .iter()
            .find(|s| &s.id == id)
            .cloned()
            .map(LibraryChoice::Folder)
    })
}

pub fn settings_active(state: &AppState) -> bool {
    state.view == View::Settings
        && state.settings_state.section == super::super::state::SettingsSection::Libraries
        && !state.popups.library_picker_active
}

pub fn refresh(state: &mut AppState, tx: &mpsc::Sender<Event>) {
    // F5 or a newly authenticated account supersedes older discovery. Results
    // carry this operation ID rather than the unrelated playback generation.
    state.sources.directory_task = None;
    state.sources.directory_request = library_directory::begin_update();
    let request = state.sources.directory_request;
    state.sources.directory_status = "Finding Plex libraries…".into();
    let tx = tx.clone();
    let task = super::super::tasks::spawn(async move {
        let result = super::super::tasks::spawn_blocking(library_directory::load).await;
        let mut accounts = match result {
            Ok(Ok(accounts)) => accounts,
            other => {
                let error = match other {
                    Ok(Err(e)) => e.to_string(),
                    Err(e) => e.to_string(),
                    _ => unreachable!(),
                };
                let _ = tx
                    .send(Event::Effect(
                        SourceAction::Directory {
                            request,
                            result: Err(error),
                            status: String::new(),
                            finished: true,
                        }
                        .into(),
                    ))
                    .await;
                return;
            }
        };
        let _ = tx
            .send(Event::Effect(
                SourceAction::Directory {
                    request,
                    result: Ok(accounts.clone()),
                    status: "Finding Plex libraries…".into(),
                    finished: false,
                }
                .into(),
            ))
            .await;
        let mut discoveries = stream::iter(accounts.clone())
            .map(|account| async move {
                let name = account.name.clone();
                (name, library_directory::discover(account).await)
            })
            .buffer_unordered(2);
        let mut warnings = Vec::new();
        while let Some((name, result)) = discoveries.next().await {
            match result {
                Ok((updated, errors)) => {
                    warnings.extend(errors);
                    if let Some(account) = accounts.iter_mut().find(|a| a.id == updated.id) {
                        *account = updated;
                    }
                }
                Err(_) => warnings.push(format!("{name}: Plex unavailable; saved libraries kept")),
            }
            let _ = tx
                .send(Event::Effect(
                    SourceAction::Directory {
                        request,
                        result: Ok(accounts.clone()),
                        status: "Finding Plex libraries…".into(),
                        finished: false,
                    }
                    .into(),
                ))
                .await;
        }
        // The revision guard also covers a blocking save already in progress
        // when the async discovery is cancelled by F5 or account removal.
        let persisted = accounts.clone();
        if let Err(error) = super::super::tasks::spawn_blocking(move || {
            library_directory::save_current(request, &persisted)
        })
        .await
        .map_err(anyhow::Error::from)
        .and_then(|r| r)
        {
            warnings.push(format!("Save library list: {error}"));
        }
        let _ = tx
            .send(Event::Effect(
                SourceAction::Directory {
                    request,
                    result: Ok(accounts),
                    status: warnings.join("; "),
                    finished: true,
                }
                .into(),
            ))
            .await;
    });
    state.sources.directory_task = Some(TaskLease::new(&task));
}

pub fn receive(
    state: &mut AppState,
    request: u64,
    result: Result<Vec<Account>, String>,
    status: String,
    finished: bool,
) {
    if request != state.sources.directory_request {
        return;
    }
    if finished {
        state.sources.directory_task = None;
    }
    // Network completions must not silently change the highlighted library.
    let selected = choices(state)
        .get(state.popups.library_picker_index)
        .map(identity);
    match result {
        Ok(accounts) => {
            state.sources.accounts = accounts;
            state.sources.directory_status = status;
            if let Some(selected) = selected {
                if let Some(index) = choices(state).iter().position(|c| identity(c) == selected) {
                    state.popups.library_picker_index = index;
                }
            }
        }
        Err(error) => {
            state.sources.directory_status = format!("Read saved Plex libraries: {error}")
        }
    }
    state.popups.library_picker_index = state
        .popups
        .library_picker_index
        .min(choices(state).len().saturating_sub(1));
}

fn identity(choice: &LibraryChoice) -> String {
    match choice {
        LibraryChoice::SavedPlex {
            account_id,
            library,
            ..
        } => format!("plex:{account_id}:{}:{}", library.server_id, library.key),
        LibraryChoice::Folder(source) => format!("folder:{}", source.id),
        LibraryChoice::Navidrome { source, folder, .. } => format!("nav:{}:{folder:?}", source.id),
        LibraryChoice::Account { id, .. } => format!("account:{id}"),
        LibraryChoice::NavidromeAccount(source) => format!("nav-account:{}", source.id),
        other => other.label(),
    }
}

impl LibraryChoice {
    pub fn provider(&self) -> &'static str {
        match self {
            Self::Folder(source) => source.kind_name(),
            Self::Navidrome { .. } | Self::NavidromeAccount(_) | Self::AddNavidrome => "Navidrome",
            Self::AddFolder => "Local",
            Self::AddWebdav => "WebDAV",
            _ => "Plex",
        }
    }

    pub fn is_active_plex_account(&self, state: &AppState) -> bool {
        state.sources.active.is_plex()
            && state.connection.is_authenticated()
            && matches!(self, Self::Account { name, .. } if name == &state.settings_state.username_input)
    }

    pub fn description(&self) -> String {
        match self {
            Self::SavedPlex { account_name, library, .. } => format!("Plex\nAccount: {account_name}\nServer: {}\n\nEnter to open this library.\nManage the sign-in in Accounts.", library.server_name),
            Self::Plex { label, .. } => format!("{label}\n\nEnter to open this library."),
            Self::Account { name, .. } => format!("Plex account\n{name}\n\nEnter to manage this sign-in.\nChoose Sign out or Cancel in the dialog.\nOpen music from the Libraries tab."),
            Self::NavidromeAccount(source) => format!("Navidrome account\n{}\n\nEnter to manage this sign-in.\nChoose Sign out or Cancel in the dialog.\nOpen music from the Libraries tab.", source.name),
            Self::Folder(source) => {
                let location = match &source.location {
                    FolderLocation::Local { path } => path.display().to_string(),
                    FolderLocation::Webdav { url, username, .. } => format!("{url}\nUser: {}", username.as_deref().unwrap_or("anonymous")),
                };
                let credentials = if matches!(source.location, FolderLocation::Webdav { .. }) { " · C edit connection" } else { "" };
                format!("{}\n{location}\n\nBrowse folders in filename order.\nR rename{credentials}\nDelete removes this entry, not music.", source.kind_name())
            }
            Self::Navidrome { source, folder, .. } => format!("Navidrome\n{}\n{}\nUser: {}\nLibrary: {}\n\nR rename account · C credentials\nDelete removes the account, not music.", source.name, source.url, source.username, folder.as_deref().unwrap_or("All music")),
            Self::AddFolder => "Local folder\n\nChoose a folder on this computer.\nSubfolders are browsed on demand.\n\nEnter to choose a path and name.".into(),
            Self::AddWebdav => "WebDAV library\n\nEnter to open the connection form.\nURL, username, password and name\nare entered together. The connection\nis checked before the library is saved.\nUse HTTPS outside trusted networks.".into(),
            Self::ConnectPlex => "Plex library\n\nSign in to add libraries from Plex.\nYour accessible music libraries appear\nin Libraries; saved sign-ins are\nmanaged separately in Accounts.".into(),
            Self::AddNavidrome => "Navidrome library\n\nEnter a server URL, username and\npassword to add its music libraries.\nManage the saved sign-in in Accounts.".into(),
        }
    }
}
