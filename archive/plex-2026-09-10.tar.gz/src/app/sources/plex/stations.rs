//! Plex station categories; ordinary station playback uses the shared runtime.
use crate::app::action::AsyncError;
use crate::app::event::{LibraryEventSender, RadioEvent};
use crate::app::{Action, AppState, Event};
use crate::plex::PlexClient;
use tokio::sync::mpsc;

pub fn children(
    event_tx: &mpsc::Sender<Event>,
    state: &mut AppState,
    client: &PlexClient,
    station_key: String,
    station_title: String,
) -> Vec<Action> {
    state.station_navigation_generation = state.station_navigation_generation.wrapping_add(1);
    // A cached drill supersedes any previous request too.
    state.stations_loading = false;
    state.station_nav.loading = false;
    // Check cache first for instant loading
    if let Some(cached_children) = state.station_children_cache.get(&station_key).cloned() {
        state
            .station_nav
            .push_column(crate::app::state::StationColumn::new(
                Some(station_key),
                station_title,
                cached_children.clone(),
            ));
        state.stations = cached_children;
        state.clear_error();
        if state.palette.open {
            crate::app::command_palette::refresh_matches(state);
        }
        return vec![];
    }

    // Drill into a station category (e.g., Mood Radio -> sub-moods)
    state.stations_loading = true;
    state.station_nav.loading = true;
    state.set_status(format!("Loading {}...", station_title));

    // Spawn background task for child loading (non-blocking)
    let tx = LibraryEventSender::new(event_tx.clone(), state.library_generation)
        .with_radio(state.radio_generation)
        .with_station_navigation(state.station_navigation_generation);
    let client_clone = client.clone();
    let sk = station_key.clone();
    let st = station_title.clone();
    crate::app::tasks::spawn(async move {
        match client_clone.get_station_children(&sk).await {
            Ok(children) => {
                let _ = tx
                    .send(
                        RadioEvent::StationChildrenLoaded {
                            station_key: sk,
                            station_title: st,
                            children,
                        }
                        .into(),
                    )
                    .await;
            }
            Err(e) => {
                let _ = tx
                    .send(
                        RadioEvent::StationChildrenFailed(AsyncError::from_api(
                            "Failed to load station choices",
                            &e,
                        ))
                        .into(),
                    )
                    .await;
            }
        }
    });

    vec![]
}
