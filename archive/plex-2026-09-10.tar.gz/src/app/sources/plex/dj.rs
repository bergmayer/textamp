//! Plex-only DJ candidate requests. Shared queue insertion stays in app handlers.
use crate::app::action::AsyncError;
use crate::app::event::{LibraryEventSender, UiEvent};
use crate::app::state::{AppState, PlaybackMode};
use crate::app::Event;
use crate::plex::PlexClient;
use anyhow::Result;
use tokio::sync::mpsc;

const SIMILAR_TRACKS_FETCH_LIMIT: u32 = 50;
const DJ_INSERT_COUNT: usize = 2;
const NEARBY_TRACKS_WINDOW: usize = 5;

/// Build sets of artist/album keys from tracks near the current playback position.
/// Used to seed diversity filtering so DJ picks avoid recently-heard artists/albums.
fn build_diversity_context(
    state: &AppState,
) -> (
    std::collections::HashSet<String>,
    std::collections::HashSet<String>,
) {
    let mut used_artists = std::collections::HashSet::new();
    let mut used_albums = std::collections::HashSet::new();

    // Add current track
    if let Some(t) = state.current_track() {
        if let Some(a) = t.grandparent_rating_key.as_deref() {
            used_artists.insert(a.to_string());
        }
        if let Some(a) = t.parent_rating_key.as_deref() {
            used_albums.insert(a.to_string());
        }
    }

    // Gather from nearby queue tracks
    let nearby: &[crate::plex::models::Track] = match state.playback_mode {
        PlaybackMode::Queue | PlaybackMode::None => {
            let idx = state.queue.index.unwrap_or(0);
            let start = idx.saturating_sub(NEARBY_TRACKS_WINDOW);
            let end = (idx + NEARBY_TRACKS_WINDOW).min(state.queue.tracks.len());
            &state.queue.tracks[start..end]
        }
        PlaybackMode::Radio => {
            let idx = state.radio.track_index.unwrap_or(0);
            let start = idx.saturating_sub(NEARBY_TRACKS_WINDOW);
            let end = (idx + NEARBY_TRACKS_WINDOW).min(state.radio.tracks.len());
            &state.radio.tracks[start..end]
        }
    };
    for t in nearby {
        if let Some(a) = t.grandparent_rating_key.as_deref() {
            used_artists.insert(a.to_string());
        }
        if let Some(a) = t.parent_rating_key.as_deref() {
            used_albums.insert(a.to_string());
        }
    }

    (used_artists, used_albums)
}

// ---------------------------------------------------------------------------
// DJ continuous processing (all modes are continuous)
// ---------------------------------------------------------------------------

/// Pick up to `count` diverse tracks from candidates, avoiding already-used tracks,
/// and preferring different artists and albums from those recently seen.
///
/// Three-phase selection:
/// 1. Different artist AND different album from all `used_artists`/`used_albums`
/// 2. Relax: just different track (not in history)
/// 3. Last resort: any candidate not already picked in this batch
fn pick_diverse(
    candidates: Vec<crate::plex::models::Track>,
    count: usize,
    history: &[String],
    used_artists: &std::collections::HashSet<String>,
    used_albums: &std::collections::HashSet<String>,
) -> Vec<crate::plex::models::Track> {
    let mut result = Vec::with_capacity(count);
    let mut picked_keys: std::collections::HashSet<String> = std::collections::HashSet::new();
    let mut picked_artists: std::collections::HashSet<String> = used_artists.clone();
    let mut picked_albums: std::collections::HashSet<String> = used_albums.clone();

    // Phase 1: Diverse — different track, different artist, different album
    for t in &candidates {
        if result.len() >= count {
            break;
        }
        if history.contains(&t.rating_key) || picked_keys.contains(&t.rating_key) {
            continue;
        }
        let artist = t.grandparent_rating_key.as_deref().unwrap_or("");
        let album = t.parent_rating_key.as_deref().unwrap_or("");
        if !artist.is_empty() && picked_artists.contains(artist) {
            continue;
        }
        if !album.is_empty() && picked_albums.contains(album) {
            continue;
        }
        picked_keys.insert(t.rating_key.clone());
        if !artist.is_empty() {
            picked_artists.insert(artist.to_string());
        }
        if !album.is_empty() {
            picked_albums.insert(album.to_string());
        }
        result.push(t.clone());
    }

    // Phase 2: Relax artist/album — just avoid history and already-picked
    if result.len() < count {
        for t in &candidates {
            if result.len() >= count {
                break;
            }
            if history.contains(&t.rating_key) || picked_keys.contains(&t.rating_key) {
                continue;
            }
            picked_keys.insert(t.rating_key.clone());
            result.push(t.clone());
        }
    }

    // Phase 3: Last resort — any candidate not yet picked
    if result.len() < count {
        for t in &candidates {
            if result.len() >= count {
                break;
            }
            if picked_keys.contains(&t.rating_key) {
                continue;
            }
            picked_keys.insert(t.rating_key.clone());
            result.push(t.clone());
        }
    }

    result
}

/// Process DJ mode logic for all modes.
/// Called on every track transition.
///
/// - **Interleaving modes** (Gemini, Twofer, Stretch): only insert after original
///   queue tracks, not after DJ-inserted tracks. This alternates: original → DJ → original → DJ.
/// - **Continuous modes** (Freeze, Contempo, Groupie): always insert after the current
///   track, pushing original queue tracks further down so you only hear DJ picks.
pub fn process(event_tx: &mpsc::Sender<Event>, state: &mut AppState, client: &mut PlexClient) {
    use crate::app::state::DjMode;

    let mode = match state.dj.active_mode {
        Some(m) => m,
        None => {
            tracing::warn!("dispatch_dj_continuous: no active DJ mode");
            return;
        }
    };

    tracing::info!(
        "dispatch_dj_continuous: mode={:?}, playback_mode={:?}, queue_len={}, queue_index={:?}",
        mode,
        state.playback_mode,
        state.queue.tracks.len(),
        state.queue.index
    );

    // Interleaving modes: skip insertion when the last track was DJ-inserted
    // (let the next original queue track play through)
    if mode.is_interleaving() && state.dj.last_was_inserted {
        state.dj.last_was_inserted = false;
        tracing::info!(
            "{}: skipping (last was DJ-inserted, letting original play)",
            mode.name()
        );
        return;
    }

    let current_track = match state.current_track().cloned() {
        Some(t) => {
            tracing::info!(
                "{}: seed track = {} (key={})",
                mode.name(),
                t.title,
                t.rating_key
            );
            t
        }
        None => {
            tracing::warn!("{}: no current track, cannot process DJ mode", mode.name());
            state.set_status(format!("{}: no track playing", mode.name()));
            state.dj.inserting = false;
            return;
        }
    };

    // Get the next track in queue (needed for Twofer and Stretch)
    let next_track = match state.playback_mode {
        PlaybackMode::Queue | PlaybackMode::None => {
            let idx = state.queue.index.unwrap_or(0);
            state.queue.tracks.get(idx + 1).cloned()
        }
        PlaybackMode::Radio => {
            let idx = state.radio.track_index.unwrap_or(0);
            state.radio.tracks.get(idx + 1).cloned()
        }
    };

    state.dj.inserting = true;

    let (used_artists, used_albums) = build_diversity_context(state);

    let tx = LibraryEventSender::new(event_tx.clone(), state.library_generation)
        .with_radio(state.radio_generation);
    let client_clone = client.clone();
    let history = state.dj.history.clone();
    let lib_key = state.active_library.clone();

    let task = crate::app::tasks::spawn(async move {
        tracing::info!(
            "{}: spawning async task for track key={}",
            mode.name(),
            current_track.rating_key
        );
        let result: Result<Vec<crate::plex::models::Track>, crate::plex::ApiError> = match mode {
            DjMode::Gemini => {
                dispatch_dj_gemini(
                    &client_clone,
                    &current_track,
                    &history,
                    &used_artists,
                    &used_albums,
                )
                .await
            }
            DjMode::Twofer => {
                dispatch_dj_twofer(&client_clone, &current_track, next_track.as_ref(), &history)
                    .await
            }
            DjMode::Stretch => {
                dispatch_dj_stretch(
                    &client_clone,
                    &current_track,
                    next_track.as_ref(),
                    &history,
                    &used_artists,
                    &used_albums,
                )
                .await
            }
            DjMode::Freeze => {
                dispatch_dj_freeze(
                    &client_clone,
                    &current_track,
                    &history,
                    &used_artists,
                    &used_albums,
                )
                .await
            }
            DjMode::Contempo => {
                dispatch_dj_contempo(
                    &client_clone,
                    &current_track,
                    &history,
                    &used_artists,
                    &used_albums,
                    lib_key.as_deref(),
                )
                .await
            }
            DjMode::Groupie => {
                dispatch_dj_groupie(&client_clone, &current_track, &history, &used_albums).await
            }
        };

        if let Ok(tracks) = &result {
            tracing::info!(
                "{}: async task completed, {} tracks found",
                mode.name(),
                tracks.len()
            );
        }
        // Always send the event, even if empty — this ensures dj_inserting gets cleared
        let result = result
            .map_err(|error| AsyncError::from_api(&format!("{} failed", mode.name()), &error));
        let _ = tx
            .send(
                UiEvent::DjTracksReady {
                    result,
                    insert_next: true,
                }
                .into(),
            )
            .await;
    });
    if crate::app::sources::sonic::dj_requires_sonic(mode) {
        state
            .sources
            .sonic_tasks
            .insert("dj", crate::app::tasks::TaskLease::new(&task));
    }
}

/// DJ Gemini (continuous): insert the most sonically similar track after current.
async fn dispatch_dj_gemini(
    client: &PlexClient,
    current_track: &crate::plex::models::Track,
    history: &[String],
    used_artists: &std::collections::HashSet<String>,
    used_albums: &std::collections::HashSet<String>,
) -> Result<Vec<crate::plex::models::Track>, crate::plex::ApiError> {
    match client
        .get_similar_tracks(&current_track.rating_key, SIMILAR_TRACKS_FETCH_LIMIT)
        .await
    {
        Ok(tracks) => Ok(pick_diverse(tracks, 1, history, used_artists, used_albums)),
        Err(error) => Err(error),
    }
}

/// DJ Twofer (continuous): insert a same-artist track when the next track differs.
/// Skips insertion if the next track is already by the same artist.
async fn dispatch_dj_twofer(
    client: &PlexClient,
    current_track: &crate::plex::models::Track,
    next_track: Option<&crate::plex::models::Track>,
    history: &[String],
) -> Result<Vec<crate::plex::models::Track>, crate::plex::ApiError> {
    let current_artist = current_track
        .grandparent_rating_key
        .as_deref()
        .unwrap_or("");
    if current_artist.is_empty() {
        return Ok(vec![]);
    }

    // Skip if next track is already by the same artist
    if let Some(next) = next_track {
        let next_artist = next.grandparent_rating_key.as_deref().unwrap_or("");
        if next_artist == current_artist {
            tracing::debug!("DJ Twofer: next track is same artist, skipping");
            return Ok(vec![]);
        }
    }

    match client.get_artist_all_tracks(current_artist).await {
        Ok(tracks) => {
            let candidates: Vec<_> = tracks
                .into_iter()
                .filter(|t| {
                    t.rating_key != current_track.rating_key && !history.contains(&t.rating_key)
                })
                .collect();
            if candidates.is_empty() {
                return Ok(vec![]);
            }
            use rand::prelude::IndexedRandom;
            let mut rng = rand::rng();
            match candidates.choose(&mut rng) {
                Some(pick) => Ok(vec![pick.clone()]),
                None => Ok(vec![]),
            }
        }
        Err(error) => Err(error),
    }
}

/// DJ Stretch (continuous): insert a bridge track between current and next.
/// Uses looser sonic distance (0.5) to find a midpoint bridge.
async fn dispatch_dj_stretch(
    client: &PlexClient,
    current_track: &crate::plex::models::Track,
    next_track: Option<&crate::plex::models::Track>,
    history: &[String],
    used_artists: &std::collections::HashSet<String>,
    used_albums: &std::collections::HashSet<String>,
) -> Result<Vec<crate::plex::models::Track>, crate::plex::ApiError> {
    let next = match next_track {
        Some(t) => t,
        None => {
            tracing::debug!("DJ Stretch: no next track, skipping");
            return Ok(vec![]);
        }
    };

    // Get similar tracks for both current and next with looser distance
    let current_similar = client
        .get_similar_tracks_with_distance(
            &current_track.rating_key,
            SIMILAR_TRACKS_FETCH_LIMIT,
            0.5,
        )
        .await;
    let next_similar = client
        .get_similar_tracks_with_distance(&next.rating_key, SIMILAR_TRACKS_FETCH_LIMIT, 0.5)
        .await;

    let current_tracks = match current_similar {
        Ok(t) => t,
        Err(error) => return Err(error),
    };
    let next_tracks = match next_similar {
        Ok(t) => t,
        Err(error) => return Err(error),
    };

    // Find tracks in the intersection of both sets (bridge candidates)
    let next_keys: std::collections::HashSet<&str> =
        next_tracks.iter().map(|t| t.rating_key.as_str()).collect();

    let bridge_candidates: Vec<_> = current_tracks
        .into_iter()
        .filter(|t| {
            next_keys.contains(t.rating_key.as_str())
                && t.rating_key != current_track.rating_key
                && t.rating_key != next.rating_key
                && !history.contains(&t.rating_key)
        })
        .collect();

    if !bridge_candidates.is_empty() {
        return Ok(pick_diverse(
            bridge_candidates,
            1,
            history,
            used_artists,
            used_albums,
        ));
    }

    // Fallback: pick from current's similar tracks (not in intersection)
    let fallback: Vec<_> = next_tracks
        .into_iter()
        .filter(|t| {
            t.rating_key != current_track.rating_key
                && t.rating_key != next.rating_key
                && !history.contains(&t.rating_key)
        })
        .collect();

    Ok(pick_diverse(
        fallback,
        1,
        history,
        used_artists,
        used_albums,
    ))
}

/// DJ Freeze: sonically similar tracks to the current one.
/// Tries increasing maxDistance (0.25 → 0.5 → 0.75) if initial results are empty.
/// Used when the probe call was not made (non-Freeze modes that fall back here won't use this).
async fn dispatch_dj_freeze(
    client: &PlexClient,
    current_track: &crate::plex::models::Track,
    history: &[String],
    used_artists: &std::collections::HashSet<String>,
    used_albums: &std::collections::HashSet<String>,
) -> Result<Vec<crate::plex::models::Track>, crate::plex::ApiError> {
    let distances = [0.25f32, 0.5, 0.75];
    for &distance in &distances {
        let result = client
            .get_similar_tracks_with_distance(
                &current_track.rating_key,
                SIMILAR_TRACKS_FETCH_LIMIT,
                distance,
            )
            .await;
        match result {
            Ok(tracks) => {
                let picked =
                    pick_diverse(tracks, DJ_INSERT_COUNT, history, used_artists, used_albums);
                if !picked.is_empty() {
                    if distance > 0.25 {
                        tracing::info!("DJ Freeze: found tracks at maxDistance={}", distance);
                    }
                    return Ok(picked);
                }
                tracing::debug!(
                    "DJ Freeze: no diverse tracks at maxDistance={}, widening",
                    distance
                );
            }
            Err(error) => return Err(error),
        }
    }
    tracing::warn!("DJ Freeze: no tracks found at any distance");
    Ok(vec![])
}

/// DJ Contempo: tracks from the same era/decade.
async fn dispatch_dj_contempo(
    client: &PlexClient,
    current_track: &crate::plex::models::Track,
    history: &[String],
    used_artists: &std::collections::HashSet<String>,
    used_albums: &std::collections::HashSet<String>,
    lib_key: Option<&str>,
) -> Result<Vec<crate::plex::models::Track>, crate::plex::ApiError> {
    let year = current_track
        .year
        .or(current_track.parent_year)
        .unwrap_or(0);
    let decade = (year / 10) * 10;
    if decade == 0 {
        return Ok(vec![]);
    }
    let Some(lk) = lib_key else {
        return Ok(vec![]);
    };
    match client
        .create_album_filter_radio_tracks(lk, "decade", &decade.to_string())
        .await
    {
        Ok(tracks) => Ok(pick_diverse(
            tracks,
            DJ_INSERT_COUNT,
            history,
            used_artists,
            used_albums,
        )),
        Err(error) => Err(error),
    }
}

/// DJ Groupie: tracks from current artist AND related artists.
/// Falls back to same-artist-only if related artists endpoint fails.
async fn dispatch_dj_groupie(
    client: &PlexClient,
    current_track: &crate::plex::models::Track,
    history: &[String],
    used_albums: &std::collections::HashSet<String>,
) -> Result<Vec<crate::plex::models::Track>, crate::plex::ApiError> {
    let artist_key = current_track
        .grandparent_rating_key
        .as_deref()
        .unwrap_or("");
    if artist_key.is_empty() {
        return Ok(vec![]);
    }

    // Build cluster of current artist + related artist keys
    let mut cluster_keys = vec![artist_key.to_string()];

    // Try to get related artists
    match client.get_related_artists(artist_key).await {
        Ok(related) => {
            for artist in related.iter().take(5) {
                cluster_keys.push(artist.rating_key.clone());
            }
            tracing::debug!(
                "DJ Groupie: cluster of {} artists (1 current + {} related)",
                cluster_keys.len(),
                related.len().min(5)
            );
        }
        Err(e) => {
            tracing::debug!(
                "DJ Groupie: related artists failed ({}), using same artist only",
                e
            );
        }
    }

    // Fetch tracks from the cluster (sample from each artist)
    let mut all_candidates = Vec::new();
    let mut successful_track_requests = 0usize;
    let mut first_error = None;
    for key in &cluster_keys {
        match client.get_artist_all_tracks(key).await {
            Ok(tracks) => {
                successful_track_requests += 1;
                let filtered: Vec<_> = tracks
                    .into_iter()
                    .filter(|t| {
                        t.rating_key != current_track.rating_key && !history.contains(&t.rating_key)
                    })
                    .collect();
                all_candidates.extend(filtered);
            }
            Err(e) => {
                tracing::warn!("DJ Groupie: tracks for artist {} failed: {}", key, e);
                if first_error.is_none() {
                    first_error = Some(e);
                }
            }
        }
    }

    if all_candidates.is_empty() && successful_track_requests == 0 {
        if let Some(error) = first_error {
            return Err(error);
        }
    }

    use rand::seq::SliceRandom;
    let mut rng = rand::rng();
    all_candidates.shuffle(&mut rng);

    // Groupie stays with the artist cluster, so only enforce album diversity
    Ok(pick_diverse(
        all_candidates,
        DJ_INSERT_COUNT,
        history,
        &std::collections::HashSet::new(),
        used_albums,
    ))
}
