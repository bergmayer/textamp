//! Plex station requests; no playback state changes or task ownership here.
use crate::app::action::AsyncError;
use crate::app::sources::radio::Batch;
use crate::plex::{models::RadioSource, PlexClient};

pub struct Request {
    pub client: PlexClient,
    pub source: RadioSource,
    pub catalog: Vec<crate::library::track::Track>,
    pub excluded: std::collections::HashSet<String>,
    pub decades: Vec<String>,
    pub index: usize,
    pub refill: bool,
}

impl Request {
    pub async fn fetch(mut self) -> Result<Batch, AsyncError> {
        if let Some(key) = self
            .source
            .station_key()
            .filter(|key| key.ends_with("/randomArtist"))
        {
            // Catalog policy belongs here, not in the HTTP client. Missing
            // eligible artists are not malformed Plex responses.
            let library = crate::plex::station_library_key(key)
                .map_err(|e| AsyncError::from_api("Random Artist Radio", &e))?;
            if self.catalog.is_empty() {
                self.catalog = self
                    .client
                    .get_tracks(library)
                    .await
                    .map_err(|e| AsyncError::from_api("Random Artist Radio", &e))?;
            }
            return crate::services::radio::select(
                &self.catalog,
                &[],
                crate::services::radio::Recipe::RandomArtist {
                    minimum_tracks: crate::services::radio::MIN_RANDOM_ARTIST_TRACKS,
                },
                &self.excluded.iter().map(String::as_str).collect(),
            )
            .map(|selection| Batch::tracks(selection.tracks))
            .map_err(|e| AsyncError {
                message: e.to_string(),
                connection_error: false,
            });
        }
        let operation = async {
            if self
                .source
                .station_key()
                .is_some_and(|key| key.ends_with("/stations/timeTravel"))
            {
                let key = self.source.station_key().expect("time travel station");
                let library = crate::plex::station_library_key(key)?;
                if self.refill && !self.decades.is_empty() {
                    let (tracks, next) = self
                        .client
                        .fetch_time_travel_track_batch(library, &self.decades, self.index)
                        .await?;
                    Ok(Batch {
                        tracks,
                        decades: self.decades,
                        next_decade: Some(next),
                    })
                } else {
                    let (tracks, decades, next_decade) =
                        self.client.create_time_travel_station(library).await?;
                    Ok(Batch {
                        tracks,
                        decades,
                        next_decade,
                    })
                }
            } else {
                self.client
                    .create_radio_queue(&self.source)
                    .await
                    .map(Batch::tracks)
            }
        };
        operation
            .await
            .map_err(|error| AsyncError::from_api("Radio request failed", &error))
    }
}
