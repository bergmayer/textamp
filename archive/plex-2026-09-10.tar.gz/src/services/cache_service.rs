//! Selection of missing or stale folder listings for an incremental crawl.
use crate::plex::{CacheData, CachedFolder};
use std::collections::HashMap;

pub fn keys_needing_refresh(
    root_folder_keys: &[String],
    folder_contents: &HashMap<String, CachedFolder>,
    stale_threshold_secs: u64,
) -> Vec<String> {
    let now = CacheData::now();
    root_folder_keys
        .iter()
        .filter(|key| {
            match folder_contents.get(key.as_str()) {
                Some(cached) => {
                    // Stale: older than threshold
                    now.saturating_sub(cached.timestamp) >= stale_threshold_secs
                }
                None => true, // Missing: always needs fetch
            }
        })
        .cloned()
        .collect()
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn test_keys_needing_refresh() {
        let now = CacheData::now();
        let one_day = 24 * 60 * 60;
        let threshold = 32 * one_day;

        let mut folder_contents = HashMap::new();

        // Fresh entry (1 day old) — should NOT need refresh
        folder_contents.insert(
            "fresh_key".to_string(),
            CachedFolder {
                items: vec![],
                timestamp: now - one_day,
                path: None,
            },
        );

        // Stale entry (40 days old) — should need refresh
        folder_contents.insert(
            "stale_key".to_string(),
            CachedFolder {
                items: vec![],
                timestamp: now - (40 * one_day),
                path: None,
            },
        );

        let root_keys = vec![
            "fresh_key".to_string(),
            "stale_key".to_string(),
            "missing_key".to_string(),
        ];

        let needs_refresh = keys_needing_refresh(&root_keys, &folder_contents, threshold);

        // stale_key and missing_key need refresh, fresh_key does not
        assert_eq!(needs_refresh.len(), 2);
        assert!(needs_refresh.contains(&"stale_key".to_string()));
        assert!(needs_refresh.contains(&"missing_key".to_string()));
        assert!(!needs_refresh.contains(&"fresh_key".to_string()));
    }

    #[test]
    fn test_keys_needing_refresh_all_fresh() {
        let now = CacheData::now();
        let one_day = 24 * 60 * 60;
        let threshold = 32 * one_day;

        let mut folder_contents = HashMap::new();
        folder_contents.insert(
            "a".to_string(),
            CachedFolder {
                items: vec![],
                timestamp: now - one_day,
                path: None,
            },
        );
        folder_contents.insert(
            "b".to_string(),
            CachedFolder {
                items: vec![],
                timestamp: now - (10 * one_day),
                path: None,
            },
        );

        let root_keys = vec!["a".to_string(), "b".to_string()];
        let needs_refresh = keys_needing_refresh(&root_keys, &folder_contents, threshold);

        assert!(needs_refresh.is_empty());
    }

    #[test]
    fn test_keys_needing_refresh_all_missing() {
        let folder_contents = HashMap::new();
        let root_keys = vec!["x".to_string(), "y".to_string()];
        let threshold = 32 * 24 * 60 * 60;

        let needs_refresh = keys_needing_refresh(&root_keys, &folder_contents, threshold);

        assert_eq!(needs_refresh.len(), 2);
    }
}
