//! Settings: Libraries, Textamp, Sections, Cache and About.

use crate::app::state::{SettingsFocus, SettingsSection};
use crate::ui::theme::theme;

use ratatui::prelude::*;
use ratatui::widgets::{Block, Borders, List, ListItem, Paragraph};

pub fn render(frame: &mut Frame, state: &AppState, area: Rect) {
    let t = theme();

    // Fill background
    frame.render_widget(
        Block::default().style(Style::default().bg(t.colors.bg_primary)),
        area,
    );

    // Split into left (sections) and right (content) panels
    let chunks = Layout::default()
        .direction(Direction::Horizontal)
        .constraints([Constraint::Length(16), Constraint::Min(0)])
        .split(area);

    render_sections(frame, state, chunks[0]);
    render_content(frame, state, chunks[1]);
}

fn render_sections(frame: &mut Frame, state: &AppState, area: Rect) {
    let t = theme();
    let is_focused = state.settings_state.focus == SettingsFocus::Sections;
    let border_color = if is_focused {
        t.colors.border_focused
    } else {
        t.colors.border
    };

    let block = Block::default()
        .title(" settings ")
        .title_style(Style::default().fg(t.colors.fg_accent))
        .borders(Borders::ALL)
        .border_style(Style::default().fg(border_color))
        .style(Style::default().bg(t.colors.bg_primary));

    let inner = block.inner(area);
    frame.render_widget(block, area);

    let sections: Vec<ListItem> = SettingsSection::all()
        .iter()
        .map(|section| {
            let is_selected = *section == state.settings_state.section;
            let prefix = if is_selected && is_focused {
                "> "
            } else {
                "  "
            };
            let style = if is_selected && is_focused {
                Style::default()
                    .fg(t.colors.selection_text)
                    .bg(t.colors.selection_bar_bg)
            } else if is_selected {
                Style::default().fg(t.colors.fg_accent)
            } else {
                Style::default().fg(t.colors.fg_primary)
            };
            ListItem::new(format!("{}{}", prefix, section.name())).style(style)
        })
        .collect();

    let list = List::new(sections);
    frame.render_widget(list, inner);
}

fn render_content(frame: &mut Frame, state: &AppState, area: Rect) {
    let t = theme();
    let is_focused = state.settings_state.focus == SettingsFocus::Content;
    let border_color = if is_focused {
        t.colors.border_focused
    } else {
        t.colors.border
    };

    let title = format!(" {} ", state.settings_state.section.name());
    let block = Block::default()
        .title(title)
        .title_style(Style::default().fg(t.colors.fg_accent))
        .borders(Borders::ALL)
        .border_style(Style::default().fg(border_color))
        .style(Style::default().bg(t.colors.bg_primary));
    let inner = block.inner(area);
    frame.render_widget(block, area);

    match state.settings_state.section {
        SettingsSection::Libraries => {
            super::super::app::render_library_manager(frame, state, inner);
        }
        SettingsSection::Textamp => render_textamp_content(frame, state, area, inner),
        SettingsSection::Sections => render_sections_content(frame, state, area, inner),
        SettingsSection::Cache => render_cache_content(frame, state, inner),
        SettingsSection::About => render_about_content(frame, state, area, inner),
    }
}

/// Cache panel: one clear/reload action, then current-source metadata statistics.
fn render_cache_content(frame: &mut Frame, state: &AppState, area: Rect) {
    use ratatui::text::Line;
    let t = theme();
    let selected = state.settings_state.focus == SettingsFocus::Content;
    let action_style = if selected {
        Style::default()
            .fg(t.colors.selection_text)
            .bg(t.colors.selection_bar_bg)
    } else {
        Style::default().fg(t.colors.fg_primary)
    };
    let bytes = state
        .library_cache_stats
        .as_ref()
        .map(|(bytes, _)| *bytes)
        .unwrap_or(0);
    let kind = if state.sources.active.navidrome().is_some() {
        "Navidrome catalog"
    } else if state.sources.active.folder().is_some() {
        "Visited folder listings"
    } else {
        "Plex library metadata"
    };
    let mut actions = vec![
        "Clear library caches and reload".to_string(),
        "Clear artwork cache".to_string(),
    ];
    if state.sources.active.is_plex() {
        actions.extend([
            "Clear subfolder cache".into(),
            if state.subfolder_preload.is_some() {
                "Stop folder crawl"
            } else {
                "Cache all subfolders"
            }
            .into(),
            format!(
                "Keep subfolder cache: {}",
                if state.keep_subfolder_cache {
                    "on"
                } else {
                    "off"
                }
            ),
        ]);
    }
    let mut lines = vec![Line::from("")];
    lines.extend(actions.into_iter().enumerate().map(|(i, label)| {
        Line::styled(
            label,
            if selected && i == state.settings_state.item_index {
                action_style
            } else {
                Style::default().fg(t.colors.fg_primary)
            },
        )
    }));
    lines.extend(vec![
        Line::from(""),
        Line::from(format!("{kind}: {}", crate::util::format_bytes(bytes))),
        Line::from(""),
        Line::from("Metadata refresh: weekly · F5 refreshes the current view."),
        Line::from("Includes AudioMuse. Cached data stays usable during updates."),
        Line::from("Folder libraries cache visited directories, without a scan."),
        Line::from("Music files and credentials are not deleted by clearing."),
        Line::from(""),
        Line::from("Enter clear · F5 update sizes · Esc back"),
    ]);
    if state.library_loading {
        lines.push(Line::from("Refreshing library…"));
    }
    frame.render_widget(
        Paragraph::new(lines)
            .wrap(ratatui::widgets::Wrap { trim: false })
            .style(Style::default().fg(t.colors.fg_primary)),
        area,
    );
}

/// Sections: fixed heading / scrollable source-aware checkboxes / keyboard hint.
fn render_sections_content(frame: &mut Frame, state: &AppState, _outer: Rect, area: Rect) {
    let t = theme();
    let is_focused = state.settings_state.focus == SettingsFocus::Content;
    let sections = state.sidebar_sections();
    let rows = Layout::vertical([
        Constraint::Length(2),
        Constraint::Min(0),
        Constraint::Length(1),
    ])
    .split(area);
    let list_area = rows[1];
    let offset = state
        .scroll
        .settings_sections
        .unwrap_or_else(|| {
            crate::services::NavigationService::calc_scroll_offset(
                state.settings_state.item_index,
                list_area.height as usize,
                sections.len(),
            )
        })
        .min(sections.len().saturating_sub(list_area.height as usize));
    state.hit_regions.borrow_mut().settings_sections =
        Some(crate::app::presentation::CategoryColumnRegion {
            area: list_area,
            inner: list_area,
            scroll_offset: offset,
            item_count: sections.len(),
        });

    let mut lines: Vec<ratatui::text::Line> = vec![
        ratatui::text::Line::from(ratatui::text::Span::styled(
            "Show in left column:",
            Style::default().fg(t.colors.fg_accent),
        )),
        ratatui::text::Line::from(""),
    ];

    frame.render_widget(Paragraph::new(std::mem::take(&mut lines)), rows[0]);
    for (idx, section) in sections
        .iter()
        .enumerate()
        .skip(offset)
        .take(list_area.height as usize)
    {
        let visible = !section.hidden(state);
        let check = if visible { "\u{2611}" } else { "\u{2610}" };
        let is_selected = is_focused && idx == state.settings_state.item_index;
        let style = if is_selected {
            Style::default()
                .fg(t.colors.selection_text)
                .bg(t.colors.bg_selection)
        } else {
            Style::default().fg(t.colors.fg_primary)
        };
        let arrow = if is_selected { "\u{25b8} " } else { "  " };
        lines.push(ratatui::text::Line::from(vec![
            ratatui::text::Span::styled(arrow, style),
            ratatui::text::Span::styled(format!("{} {}", check, section.label()), style),
        ]));
    }

    let para =
        ratatui::widgets::Paragraph::new(lines).style(Style::default().bg(t.colors.bg_primary));
    frame.render_widget(para, list_area);
    frame.render_widget(
        Paragraph::new("Enter / Space toggle · ← back")
            .style(Style::default().fg(t.colors.fg_muted)),
        rows[2],
    );
}

fn render_textamp_content(frame: &mut Frame, state: &AppState, outer: Rect, area: Rect) {
    use crate::app::state::{OutputTarget, TextampSetting};
    use crate::services::external_search::SearchTarget;

    let t = theme();
    let is_focused = state.settings_state.focus == SettingsFocus::Content;
    let settings = state.textamp_settings();
    // Theme list on the left; the highlighted theme's artwork on the right.
    // Previewing is render-only. Enter still applies and saves the selection.
    let area = if let Some(TextampSetting::Theme(name)) = settings
        .get(state.settings_state.item_index)
        .filter(|_| area.width >= 60)
    {
        let panes = Layout::horizontal([Constraint::Length(30), Constraint::Min(0)]).split(area);
        let preview = crate::ui::theme::Theme::new(*name);
        crate::ui::widgets::logo::render_themed(frame, panes[1], &preview.colors);
        panes[0]
    } else {
        area
    };
    let mut lines = vec![];
    let mut selected_line = None;
    let mut previous_heading = "";
    let mut item_lines = Vec::new();
    for (index, item) in settings.into_iter().enumerate() {
        let (heading, label, active) = match item {
            TextampSetting::Theme(name) => (
                "theme:",
                name.display_name().to_string(),
                name == state.theme,
            ),
            TextampSetting::Artwork(mode) => (
                "artwork:",
                mode.name().to_string(),
                mode == state.artwork.mode,
            ),
            TextampSetting::LocalOutput => (
                "Plex playback output:",
                "local".into(),
                matches!(state.remote.output_target, OutputTarget::Local),
            ),
            TextampSetting::RemoteOutput(index) => {
                let player = &state.remote.players[index];
                (
                    "Plex playback output:",
                    format!("{} ({})", player.name, player.product),
                    matches!(&state.remote.output_target, OutputTarget::Remote { player_id, .. } if player_id == &player.client_identifier),
                )
            }
            TextampSetting::DiscoverPlayers => (
                "Plex playback output:",
                if state.remote.discovering {
                    "discovering…"
                } else {
                    "refresh players"
                }
                .into(),
                false,
            ),
            TextampSetting::Transcode => (
                "streaming quality:",
                if state.transcode_kbps == 0 {
                    "original (direct play)".into()
                } else {
                    format!("transcode to {}kbps", state.transcode_kbps)
                },
                false,
            ),
            TextampSetting::ExternalSearch(target) => {
                let (label, enabled) = match target {
                    SearchTarget::AppleMusic => ("Apple Music", state.external_search.apple_music),
                    SearchTarget::Spotify => ("Spotify", state.external_search.spotify),
                    SearchTarget::YouTube => ("YouTube", state.external_search.youtube),
                };
                (
                    "search in external services:",
                    format!("{} {label}", if enabled { "[x]" } else { "[ ]" }),
                    false,
                )
            }
        };
        if heading != previous_heading {
            if !lines.is_empty() {
                lines.push(Line::from(""));
            }
            lines.push(Line::from(Span::styled(
                heading,
                Style::default().fg(t.colors.fg_accent),
            )));
            previous_heading = heading;
        }
        let selected = is_focused && index == state.settings_state.item_index;
        item_lines.push((lines.len(), index));
        if selected {
            selected_line = Some(lines.len());
        }
        let style = if selected {
            Style::default()
                .fg(t.colors.selection_text)
                .bg(t.colors.selection_bar_bg)
        } else {
            Style::default().fg(t.colors.fg_primary)
        };
        lines.push(Line::from(Span::styled(
            format!("  {}{label}", if active { "♪ " } else { "" }),
            style,
        )));
    }

    lines.push(Line::from(""));
    lines.push(Line::from(Span::styled(
        format!(
            "graphics: {} | terminal: {}x{}",
            crate::ui::screens::now_playing::artwork_protocol_name(),
            state.terminal_width,
            state.terminal_height
        ),
        Style::default().fg(t.colors.fg_muted),
    )));
    lines.push(Line::from(Span::styled(
        "enter: select",
        Style::default().fg(t.colors.fg_muted),
    )));

    // Auto-scroll to keep selected item visible
    let total = lines.len() as u16;
    let visible = area.height;
    let scroll = if let Some(sel) = selected_line {
        let sel = sel as u16;
        if total <= visible {
            0
        } else {
            sel.saturating_sub(visible / 3)
                .min(total.saturating_sub(visible))
        }
    } else {
        0
    };

    let scroll = state
        .scroll
        .settings_textamp
        .unwrap_or(scroll as usize)
        .min(total.saturating_sub(visible) as usize);
    let rows = item_lines
        .into_iter()
        .filter_map(|(line, index)| {
            let row = line.checked_sub(scroll)?;
            (row < area.height as usize)
                .then_some((Rect::new(area.x, area.y + row as u16, area.width, 1), index))
        })
        .collect();
    state.hit_regions.borrow_mut().settings_textamp =
        Some(crate::app::presentation::SettingsContentRegion {
            inner: area,
            rows,
            scroll_offset: scroll,
            total_lines: total as usize,
        });

    let paragraph = Paragraph::new(lines).scroll((scroll as u16, 0));
    frame.render_widget(paragraph, area);

    // Scrollbar when content overflows
    if total > visible {
        crate::ui::widgets::render_scrollbar(
            frame,
            outer,
            total as usize,
            visible as usize,
            scroll,
            None,
        );
    }
}

fn render_about_content(frame: &mut Frame, state: &AppState, outer: Rect, area: Rect) {
    let t = theme();

    let mut lines = crate::ui::widgets::logo::original(t.colors.bg_primary);

    lines.push(Line::from(""));
    lines.push(Line::from(Span::styled(
        format!("version {}", env!("CARGO_PKG_VERSION")),
        Style::default().fg(t.colors.fg_primary),
    )));
    lines.push(Line::from(Span::styled(
        "a keyboard-driven TUI for Plex, Navidrome and music folders",
        Style::default().fg(t.colors.fg_muted),
    )));
    lines.push(Line::from(Span::styled(
        "author: John Bergmayer | license: Unlicense",
        Style::default().fg(t.colors.fg_primary),
    )));
    lines.push(Line::from(Span::styled(
        "https://github.com/bergmayer/textamp",
        Style::default().fg(t.colors.fg_accent),
    )));

    // Graphics info
    lines.push(Line::from(""));
    lines.push(Line::from(Span::styled(
        "graphics:",
        Style::default().fg(t.colors.fg_accent),
    )));
    let protocol = crate::ui::screens::now_playing::artwork_protocol_name();
    lines.push(Line::from(Span::styled(
        format!(
            "  protocol: {} | terminal: {}x{}",
            protocol, state.terminal_width, state.terminal_height
        ),
        Style::default().fg(t.colors.fg_muted),
    )));

    // Manual scroll (no selectable items)
    let total = lines.len() as u16;
    let visible = area.height;
    let max_scroll = total.saturating_sub(visible);
    let scroll = state.settings_state.scroll.min(max_scroll);

    let paragraph = Paragraph::new(lines).scroll((scroll, 0));
    frame.render_widget(paragraph, area);

    // Scrollbar when content overflows
    if total > visible {
        crate::ui::widgets::render_scrollbar(
            frame,
            outer,
            total as usize,
            visible as usize,
            scroll as usize,
            None,
        );
    }
}

use crate::ui::RenderState as AppState;
