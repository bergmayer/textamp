//! Search popup screen (Ctrl+F).
//!
//! Local-first search with tabs: All | Artists | Albums | Playlists | Tracks | Genres

use crate::app::state::{SearchFocus, SearchTab};
use crate::plex::models::SearchResults;
use crate::services::NavigationService;
use crate::ui::layout::centered_rect;
use crate::ui::theme::theme;
use crate::ui::RenderState as AppState;

use ratatui::prelude::*;
use ratatui::widgets::{Block, Borders, Clear, List, ListItem, Paragraph, Tabs};

/// Render the search popup as an overlay.
pub fn render(frame: &mut Frame, state: &AppState, area: Rect) {
    let t = theme();

    // Popup takes 50% width, 70% height, centered
    let popup_area = centered_rect(50, 70, area);

    // Clear the area behind the popup
    frame.render_widget(Clear, popup_area);

    let block = Block::default()
        .title(" search ")
        .title_style(Style::default().fg(t.colors.fg_accent))
        .borders(Borders::ALL)
        .border_style(Style::default().fg(t.colors.fg_accent))
        .style(Style::default().bg(t.colors.bg_primary));
    let inner = block.inner(popup_area);
    frame.render_widget(block, popup_area);

    // Split inner area: tabs, search input, results
    let chunks = ratatui::layout::Layout::default()
        .direction(ratatui::layout::Direction::Vertical)
        .constraints([
            ratatui::layout::Constraint::Length(2),
            ratatui::layout::Constraint::Length(3),
            ratatui::layout::Constraint::Min(3),
        ])
        .split(inner);

    // Register hit regions for mouse handler
    {
        let mut hr = state.hit_regions.borrow_mut();
        hr.search_popup = Some(crate::app::presentation::SearchPopupRegions {
            outer: popup_area,
            tab_area: chunks[0],
            input_area: chunks[1],
            results_area: chunks[2],
        });
    }

    // Tabs
    render_tabs(frame, state, chunks[0]);

    // Search input
    render_search_input(frame, state, chunks[1]);

    // Results
    render_results(frame, state, chunks[2]);
}

fn render_tabs(frame: &mut Frame, state: &AppState, area: Rect) {
    let t = theme();
    if state.sources.active.folder().is_some() {
        frame.render_widget(
            Paragraph::new("Audio files in current folder · / filters folders")
                .style(Style::default().fg(t.colors.fg_muted)),
            area,
        );
        return;
    }

    let labels = SearchTab::all();
    let selected_idx = match state.search.tab {
        SearchTab::Global => 0,
        SearchTab::Artists => 1,
        SearchTab::Albums => 2,
        SearchTab::Playlists => 3,
        SearchTab::Tracks => 4,
        SearchTab::Genres => 5,
    };

    let is_tab_focused = state.search.focus == SearchFocus::Input;

    let titles: Vec<Line> = labels
        .iter()
        .enumerate()
        .map(|(i, tab)| {
            if i == selected_idx && is_tab_focused {
                Line::from(Span::styled(
                    format!(" {} ", tab.name()),
                    Style::default()
                        .fg(t.colors.selection_text)
                        .bg(t.colors.selection_bar_bg),
                ))
            } else if i == selected_idx {
                Line::from(Span::styled(
                    format!(" {} ", tab.name()),
                    Style::default()
                        .fg(t.colors.fg_accent)
                        .add_modifier(Modifier::BOLD),
                ))
            } else {
                Line::from(Span::styled(
                    format!(" {} ", tab.name()),
                    Style::default().fg(t.colors.fg_muted),
                ))
            }
        })
        .collect();

    let tabs = Tabs::new(titles)
        .select(selected_idx)
        .highlight_style(Style::default())
        .style(
            Style::default()
                .bg(t.colors.bg_primary)
                .fg(t.colors.fg_muted),
        )
        .divider(Span::styled(" │ ", Style::default().fg(t.colors.fg_muted)))
        .padding("", "");

    frame.render_widget(tabs, area);
}

fn render_search_input(frame: &mut Frame, state: &AppState, area: Rect) {
    let t = theme();

    let is_input_focused = state.search.focus == SearchFocus::Input;

    let input_block = Block::default()
        .title(" search ")
        .borders(Borders::ALL)
        .border_style(Style::default().fg(if is_input_focused {
            t.colors.border_focused
        } else {
            t.colors.border
        }))
        .style(Style::default().bg(t.colors.bg_primary));

    let input_inner = input_block.inner(area);
    frame.render_widget(input_block, area);

    // Show search query with cursor only when input is focused
    let query_text = if is_input_focused {
        format!("{}▋", state.search.query)
    } else {
        state.search.query.clone()
    };
    let fg = if is_input_focused {
        t.colors.fg_primary
    } else {
        t.colors.fg_muted
    };
    let input = Paragraph::new(query_text).style(Style::default().fg(fg));
    frame.render_widget(input, input_inner);
}

fn render_results(frame: &mut Frame, state: &AppState, area: Rect) {
    let scroll_pin = state.scroll.search;
    let t = theme();

    let results = match &state.search.results {
        Some(r) => r,
        None => {
            let msg = if state.search.query.is_empty() {
                "Type to search library"
            } else {
                "Searching..."
            };
            let empty = Paragraph::new(msg)
                .style(Style::default().fg(t.colors.fg_muted))
                .alignment(Alignment::Center);
            frame.render_widget(empty, area);
            return;
        }
    };

    let is_results_focused = state.search.focus == SearchFocus::Results;
    let selected_idx = state.list_state.search_item_index;

    match state.search.tab {
        SearchTab::Global => render_all_tab(
            frame,
            results,
            is_results_focused,
            selected_idx,
            scroll_pin,
            area,
        ),
        SearchTab::Artists => render_single_section(
            frame,
            &results.artists,
            |a| {
                if a.title.is_empty() {
                    "Unknown Artist".to_string()
                } else {
                    a.title.clone()
                }
            },
            is_results_focused,
            selected_idx,
            scroll_pin,
            area,
        ),
        SearchTab::Albums => render_single_section(
            frame,
            &results.albums,
            |a| {
                let artist = a.artist_name();
                let title = if a.title.is_empty() {
                    format!("Unknown Album ({})", artist)
                } else if let Some(year) = a.year {
                    format!("{} ({})", a.title, year)
                } else {
                    a.title.clone()
                };
                format!("{} - {}", title, artist)
            },
            is_results_focused,
            selected_idx,
            scroll_pin,
            area,
        ),
        SearchTab::Playlists => render_single_section(
            frame,
            &results.playlists,
            |p| p.title.clone(),
            is_results_focused,
            selected_idx,
            scroll_pin,
            area,
        ),
        SearchTab::Tracks => {
            if state.search.track_loading && results.tracks.is_empty() {
                let loading = Paragraph::new("Searching tracks...")
                    .style(Style::default().fg(t.colors.fg_muted))
                    .alignment(Alignment::Center);
                frame.render_widget(loading, area);
            } else {
                render_single_section(
                    frame,
                    &results.tracks,
                    |tr| {
                        let title = if tr.title.is_empty() {
                            tr.file_name().unwrap_or("Unknown Track")
                        } else {
                            &tr.title
                        };
                        format!("{} - {}", title, tr.track_artist())
                    },
                    is_results_focused,
                    selected_idx,
                    scroll_pin,
                    area,
                );
            }
        }
        SearchTab::Genres => render_single_section(
            frame,
            &results.genres,
            |g| g.title.clone(),
            is_results_focused,
            selected_idx,
            scroll_pin,
            area,
        ),
    }
}

/// Render the All tab with section headers.
fn render_all_tab(
    frame: &mut Frame,
    results: &SearchResults,
    is_focused: bool,
    selected_idx: usize,
    scroll_pin: Option<usize>,
    area: Rect,
) {
    let t = theme();

    if results.is_empty() {
        let empty = Paragraph::new("No matches found")
            .style(Style::default().fg(t.colors.fg_muted))
            .alignment(Alignment::Center);
        frame.render_widget(empty, area);
        return;
    }

    let section_lengths = [
        results.artists.len(),
        results.albums.len(),
        results.playlists.len(),
        results.genres.len(),
        results.tracks.len(),
    ];
    let total_entries: usize = section_lengths
        .iter()
        .map(|length| if *length == 0 { 0 } else { length + 1 })
        .sum();

    let visible_height = area.height as usize;

    // Find display position of selected item
    let display_selected = {
        let mut selectable_base = 0;
        let mut display_base = 0;
        let mut found = None;
        for length in section_lengths {
            if length == 0 {
                continue;
            }
            if selected_idx < selectable_base + length {
                found = Some(display_base + 1 + selected_idx - selectable_base);
                break;
            }
            selectable_base += length;
            display_base += length + 1;
        }
        found.unwrap_or(0)
    };
    let scroll_offset = match scroll_pin {
        Some(pinned) => pinned,
        None => {
            NavigationService::calc_scroll_offset(display_selected, visible_height, total_entries)
        }
    };

    let mut items = Vec::with_capacity(visible_height.min(total_entries));
    for display_index in scroll_offset..(scroll_offset + visible_height).min(total_entries) {
        let mut local = display_index;
        let mut global_base = 0;
        for (section, length) in section_lengths.iter().copied().enumerate() {
            if length == 0 {
                continue;
            }
            if local == 0 {
                let name = ["Artists", "Albums", "Playlists", "Genres", "Tracks"][section];
                items.push(
                    ListItem::new(format!("── {} ({}) ──", name, length))
                        .style(Style::default().fg(t.colors.fg_accent)),
                );
                break;
            }
            local -= 1;
            if local < length {
                let text = match section {
                    0 => format!("  {}", results.artists[local].title),
                    1 => {
                        let album = &results.albums[local];
                        let artist = album.artist_name();
                        if album.title.is_empty() {
                            format!("  Unknown Album ({artist}) - {artist}")
                        } else if let Some(year) = album.year {
                            format!("  {} ({year}) - {artist}", album.title)
                        } else {
                            format!("  {} - {artist}", album.title)
                        }
                    }
                    2 => format!("  {}", results.playlists[local].title),
                    3 => format!("  {}", results.genres[local].title),
                    _ => {
                        let track = &results.tracks[local];
                        let title = if track.title.is_empty() {
                            track.file_name().unwrap_or("Unknown Track")
                        } else {
                            &track.title
                        };
                        format!("  {} - {}", title, track.track_artist())
                    }
                };
                let global_index = global_base + local;
                let style = if is_focused && global_index == selected_idx {
                    Style::default()
                        .fg(t.colors.selection_text)
                        .bg(t.colors.selection_bar_bg)
                } else {
                    Style::default().fg(t.colors.fg_primary)
                };
                items.push(ListItem::new(text).style(style));
                break;
            }
            local -= length;
            global_base += length;
        }
    }

    frame.render_widget(List::new(items), area);

    // Scrollbar for long lists
    if total_entries > visible_height {
        crate::ui::widgets::render_scrollbar_borderless(
            frame,
            area,
            total_entries,
            visible_height,
            scroll_offset,
        );
    }
}

/// Render a single-section list (for Artists, Albums, Playlists, Tracks, Genres tabs).
fn render_single_section<T, F>(
    frame: &mut Frame,
    items: &[T],
    format_item: F,
    is_focused: bool,
    selected_idx: usize,
    scroll_pin: Option<usize>,
    area: Rect,
) where
    F: Fn(&T) -> String,
{
    let t = theme();

    if items.is_empty() {
        let msg = "No matches";
        let empty = Paragraph::new(msg)
            .style(Style::default().fg(t.colors.fg_muted))
            .alignment(Alignment::Center);
        frame.render_widget(empty, area);
        return;
    }

    let visible_height = area.height as usize;
    let total = items.len();
    let scroll_offset = match scroll_pin {
        Some(pinned) => pinned,
        None => NavigationService::calc_scroll_offset(selected_idx, visible_height, total),
    };

    let list_items: Vec<ListItem> = items
        .iter()
        .enumerate()
        .skip(scroll_offset)
        .take(visible_height)
        .map(|(i, item)| {
            let is_selected = is_focused && i == selected_idx;
            let style = if is_selected {
                Style::default()
                    .fg(t.colors.selection_text)
                    .bg(t.colors.selection_bar_bg)
            } else {
                Style::default().fg(t.colors.fg_primary)
            };
            ListItem::new(format_item(item)).style(style)
        })
        .collect();

    frame.render_widget(List::new(list_items), area);

    // Scrollbar for long lists
    if total > visible_height {
        crate::ui::widgets::render_scrollbar_borderless(
            frame,
            area,
            total,
            visible_height,
            scroll_offset,
        );
    }
}
