//! Album artwork support using ratatui-image.
//!
//! Displays album art in terminals that support graphics protocols
//! (Kitty, iTerm2, Sixel) or falls back to halfblocks.

use std::cell::RefCell;
use std::collections::{HashMap, VecDeque};
use std::hash::{Hash, Hasher};

use image::DynamicImage;
use ratatui::prelude::*;
use ratatui_image::{picker::Picker, protocol::StatefulProtocol, Resize, StatefulImage};

use crate::app::state::ArtworkMode;

/// Artwork renderer using ratatui-image.
///
/// This struct manages the picker (terminal capability detection) and the
/// current image protocol for rendering.
pub struct ArtworkRenderer {
    picker: Option<Picker>,
    protocol: Option<StatefulProtocol>,
    current_thumb: Option<String>,
    current_image_id: Option<u64>,
    braille_image: Option<DynamicImage>,
    mode: ArtworkMode,
    /// The protocol type detected at startup (for restoring after Halfblocks override).
    native_protocol: Option<ratatui_image::picker::ProtocolType>,
}

impl Default for ArtworkRenderer {
    fn default() -> Self {
        Self::new()
    }
}

impl ArtworkRenderer {
    /// Create without a picker (no graphics, placeholder fallback).
    pub fn new() -> Self {
        Self {
            picker: None,
            protocol: None,
            current_thumb: None,
            current_image_id: None,
            braille_image: None,
            mode: ArtworkMode::Auto,
            native_protocol: None,
        }
    }

    /// Create with a pre-initialized picker for graphics support.
    pub fn new_with_picker(picker: Picker) -> Self {
        let native = picker.protocol_type();
        tracing::info!("Artwork protocol: {:?}", native);
        Self {
            picker: Some(picker),
            protocol: None,
            current_thumb: None,
            current_image_id: None,
            braille_image: None,
            mode: ArtworkMode::Auto,
            native_protocol: Some(native),
        }
    }

    /// Check if graphics are supported.
    pub fn is_supported(&self) -> bool {
        self.picker.is_some()
    }

    /// Get the detected protocol type name (for display in settings).
    pub fn protocol_name(&self) -> &'static str {
        match &self.picker {
            Some(picker) => match picker.protocol_type() {
                ratatui_image::picker::ProtocolType::Halfblocks => "halfblocks",
                ratatui_image::picker::ProtocolType::Sixel => "sixel",
                ratatui_image::picker::ProtocolType::Kitty => "kitty",
                ratatui_image::picker::ProtocolType::Iterm2 => "iterm2",
            },
            None => "none",
        }
    }

    /// Load and prepare an image for rendering.
    /// Returns true if the image was loaded successfully.
    pub fn load_image(&mut self, image_data: &[u8], thumb_path: &str) -> bool {
        // Skip if same image already loaded
        if self.current_thumb.as_deref() == Some(thumb_path) {
            if self.mode == ArtworkMode::Braille && self.braille_image.is_some() {
                return true;
            }
            if self.mode != ArtworkMode::Braille && self.protocol.is_some() {
                return true;
            }
        }

        // Load image from bytes
        let Ok(img) = image::load_from_memory(image_data) else {
            return false;
        };

        if self.mode == ArtworkMode::Braille {
            self.braille_image = Some(img);
            self.protocol = None;
            self.current_thumb = Some(thumb_path.to_string());
            self.current_image_id = Some(artwork_id(thumb_path, image_data));
            return true;
        }

        let Some(ref mut picker) = self.picker else {
            return false;
        };

        // Create protocol for rendering (this handles resizing automatically)
        self.protocol = Some(picker.new_resize_protocol(img));
        self.braille_image = None;
        self.current_thumb = Some(thumb_path.to_string());
        self.current_image_id = Some(artwork_id(thumb_path, image_data));
        true
    }

    /// Load an image with the top portion cropped (for scrolling).
    /// `crop_fraction` is 0.0..1.0 indicating how much of the top to remove.
    pub fn load_image_cropped(
        &mut self,
        image_data: &[u8],
        thumb_path: &str,
        crop_fraction: f32,
    ) -> bool {
        if crop_fraction <= 0.0 {
            return self.load_image(image_data, thumb_path);
        }

        // Cache key includes crop amount to avoid re-creating protocol unnecessarily
        let crop_key = format!("{}:c{}", thumb_path, (crop_fraction * 100.0) as u32);
        let image_id = artwork_id(&crop_key, image_data);
        if self.current_thumb.as_deref() == Some(&crop_key) {
            return self.has_image();
        }

        let Ok(img) = image::load_from_memory(image_data) else {
            return false;
        };

        let crop_pixels =
            (img.height() as f32 * crop_fraction).min(img.height() as f32 - 1.0) as u32;
        let cropped = if crop_pixels > 0 && crop_pixels < img.height() {
            img.crop_imm(0, crop_pixels, img.width(), img.height() - crop_pixels)
        } else {
            img
        };

        if self.mode == ArtworkMode::Braille {
            self.braille_image = Some(cropped);
            self.protocol = None;
            self.current_thumb = Some(crop_key);
            self.current_image_id = Some(image_id);
            return true;
        }

        let Some(ref mut picker) = self.picker else {
            return false;
        };
        self.protocol = Some(picker.new_resize_protocol(cropped));
        self.braille_image = None;
        self.current_thumb = Some(crop_key);
        self.current_image_id = Some(image_id);
        true
    }

    /// Clear the current image.
    pub fn clear(&mut self) {
        self.protocol = None;
        self.braille_image = None;
        self.current_thumb = None;
        self.current_image_id = None;
    }

    /// Render the artwork to a frame area.
    ///
    /// `Resize::Scale` rather than `Resize::Crop`/`Resize::Fit` because
    /// in ratatui-image 9 only `Scale` actually upscales when the
    /// source image is smaller than the render area — the other two
    /// cap at source pixel size and leave a tiny cover drifting in the
    /// upper-left of a much larger box. Plex thumbs come back at
    /// 300–600 px while the now-playing panel can easily be 800+ px
    /// tall on a wide terminal, so without `Scale` the cover doesn't
    /// fill its square.
    pub fn render(&mut self, frame: &mut Frame, area: Rect) {
        if self.mode == ArtworkMode::Braille {
            if let Some(ref img) = self.braille_image {
                render_braille_image(frame, img, area, self.current_image_id.unwrap_or(0));
            }
            return;
        }
        if let Some(ref mut protocol) = self.protocol {
            let image = StatefulImage::new().resize(Resize::Scale(None));
            frame.render_stateful_widget(image, area, protocol);
        }
    }

    /// Check if there's an image loaded.
    pub fn has_image(&self) -> bool {
        if self.mode == ArtworkMode::Braille {
            return self.braille_image.is_some();
        }
        self.protocol.is_some()
    }

    /// Get the current thumb path.
    pub fn current_thumb(&self) -> Option<&str> {
        self.current_thumb.as_deref()
    }

    /// Change the graphics protocol and clear cached images.
    pub fn set_protocol_type(&mut self, protocol_type: ratatui_image::picker::ProtocolType) {
        if let Some(ref mut picker) = self.picker {
            picker.set_protocol_type(protocol_type);
            // Clear cached image so it's re-created with the new protocol
            self.protocol = None;
            self.current_thumb = None;
            self.current_image_id = None;
        }
    }

    /// Restore the native protocol detected at startup and clear cached images.
    pub fn restore_native_protocol(&mut self) {
        if let (Some(ref mut picker), Some(native)) = (&mut self.picker, self.native_protocol) {
            picker.set_protocol_type(native);
            self.protocol = None;
            self.current_thumb = None;
            self.current_image_id = None;
        }
    }

    /// Set the artwork rendering mode and clear all caches.
    pub fn set_mode(&mut self, mode: ArtworkMode) {
        self.mode = mode;
        self.protocol = None;
        self.braille_image = None;
        self.current_thumb = None;
        self.current_image_id = None;
    }
}

// ============================================================================
// Braille Image Rendering
// ============================================================================

/// Render an image as Braille characters in the given area.
///
/// Uses adaptive thresholding: computes the median luminance of the resized image
/// so that roughly half the dots are lit, producing dense output regardless of
/// whether the source image is dark or bright.
///
/// Each terminal cell maps to a 2x4 pixel block using Unicode Braille patterns (U+2800..U+28FF).
/// Dot bit mapping per cell:
///   Col 0: bits 0,1,2,6 (rows 0-3)
///   Col 1: bits 3,4,5,7 (rows 0-3)
#[derive(Clone, Copy)]
struct BrailleCell {
    symbol: char,
    foreground: Color,
    background: Color,
}

struct BrailleRender {
    width: u16,
    height: u16,
    cells: Vec<BrailleCell>,
}

#[derive(Clone, Copy, PartialEq, Eq, Hash)]
struct BrailleRenderKey {
    image_id: u64,
    max_width: u16,
    max_height: u16,
}

fn artwork_id(key: &str, data: &[u8]) -> u64 {
    let mut hasher = std::collections::hash_map::DefaultHasher::new();
    key.hash(&mut hasher);
    data.len().hash(&mut hasher);
    let prefix_len = data.len().min(64);
    data[..prefix_len].hash(&mut hasher);
    if data.len() > prefix_len {
        data[data.len().saturating_sub(64)..].hash(&mut hasher);
    }
    hasher.finish()
}

fn build_braille_render(
    img: &DynamicImage,
    max_width: u16,
    max_height: u16,
) -> Option<BrailleRender> {
    use image::GenericImageView;

    if max_width == 0 || max_height == 0 {
        return None;
    }

    // Match the other renderers (Resize::Scale, halfblocks): preserve the
    // source image's aspect ratio and center the result inside `area`. The
    // miller-column art slot is ≥ 2:1 in cells (≈ square or wider in
    // pixels, since braille is 2 dots wide × 4 dots tall per cell), so
    // resize_exact'ing the whole slot used to horizontally stretch any
    // square cover into a wide rectangle.
    let (src_w, src_h) = img.dimensions();
    if src_w == 0 || src_h == 0 {
        return None;
    }
    let area_px_w = max_width as u32 * 2;
    let area_px_h = max_height as u32 * 4;
    let (dest_px_w, dest_px_h) = if src_w * area_px_h <= src_h * area_px_w {
        // Height-limited.
        ((src_w * area_px_h / src_h).max(1), area_px_h)
    } else {
        // Width-limited.
        (area_px_w, (src_h * area_px_w / src_w).max(1))
    };
    let dest_w = ((dest_px_w / 2) as u16).clamp(1, max_width);
    let dest_h = ((dest_px_h / 4) as u16).clamp(1, max_height);
    let pixel_w = dest_w as u32 * 2;
    let pixel_h = dest_h as u32 * 4;

    let resized = img.resize_exact(pixel_w, pixel_h, image::imageops::FilterType::Triangle);

    // Build luminance histogram for adaptive thresholding
    let mut histogram = [0u32; 256];
    let total_pixels = pixel_w * pixel_h;
    for y in 0..pixel_h {
        for x in 0..pixel_w {
            let pixel = resized.get_pixel(x, y);
            let lum =
                (pixel[0] as u32 * 299 + pixel[1] as u32 * 587 + pixel[2] as u32 * 114) / 1000;
            histogram[lum.min(255) as usize] += 1;
        }
    }

    // Find the median luminance — threshold where ~50% of pixels are above
    let target = total_pixels / 2;
    let mut cumulative = 0u32;
    let mut threshold = 128u32;
    for (lum, &count) in histogram.iter().enumerate() {
        cumulative += count;
        if cumulative >= target {
            threshold = lum as u32;
            break;
        }
    }
    // Clamp threshold so we never go fully black or fully white
    threshold = threshold.clamp(15, 240);

    // Braille dot bit positions:
    // (0,0)→bit0  (1,0)→bit3
    // (0,1)→bit1  (1,1)→bit4
    // (0,2)→bit2  (1,2)→bit5
    // (0,3)→bit6  (1,3)→bit7
    let bit_map: [[u8; 4]; 2] = [
        [0, 1, 2, 6], // col 0, rows 0-3
        [3, 4, 5, 7], // col 1, rows 0-3
    ];

    let mut cells = Vec::with_capacity(dest_width_len(dest_w, dest_h));

    for row in 0..dest_h as u32 {
        for col in 0..dest_w as u32 {
            let px = col * 2;
            let py = row * 4;

            let mut pattern: u8 = 0;
            let mut fg_r: u32 = 0;
            let mut fg_g: u32 = 0;
            let mut fg_b: u32 = 0;
            let mut bright_count: u32 = 0;
            let mut bg_r: u32 = 0;
            let mut bg_g: u32 = 0;
            let mut bg_b: u32 = 0;
            let mut dark_count: u32 = 0;

            for dx in 0..2u32 {
                for dy in 0..4u32 {
                    let x = px + dx;
                    let y = py + dy;
                    if x < pixel_w && y < pixel_h {
                        let pixel = resized.get_pixel(x, y);
                        let r = pixel[0] as u32;
                        let g = pixel[1] as u32;
                        let b = pixel[2] as u32;
                        let lum = (r * 299 + g * 587 + b * 114) / 1000;
                        if lum >= threshold {
                            pattern |= 1 << bit_map[dx as usize][dy as usize];
                            fg_r += r;
                            fg_g += g;
                            fg_b += b;
                            bright_count += 1;
                        } else {
                            bg_r += r;
                            bg_g += g;
                            bg_b += b;
                            dark_count += 1;
                        }
                    }
                }
            }

            let ch = char::from_u32(0x2800 + pattern as u32).unwrap_or(' ');
            let fg_color = if let Some(count) = std::num::NonZeroU32::new(bright_count) {
                Color::Rgb(
                    (fg_r / count.get()) as u8,
                    (fg_g / count.get()) as u8,
                    (fg_b / count.get()) as u8,
                )
            } else {
                Color::Rgb(0, 0, 0)
            };
            let bg_color = if let Some(count) = std::num::NonZeroU32::new(dark_count) {
                Color::Rgb(
                    (bg_r / count.get()) as u8,
                    (bg_g / count.get()) as u8,
                    (bg_b / count.get()) as u8,
                )
            } else {
                fg_color
            };

            cells.push(BrailleCell {
                symbol: ch,
                foreground: fg_color,
                background: bg_color,
            });
        }
    }

    Some(BrailleRender {
        width: dest_w,
        height: dest_h,
        cells,
    })
}

fn dest_width_len(width: u16, height: u16) -> usize {
    usize::from(width).saturating_mul(usize::from(height))
}

fn paint_braille_render(frame: &mut Frame, area: Rect, rendered: &BrailleRender) {
    let origin_x = area.x + area.width.saturating_sub(rendered.width) / 2;
    let origin_y = area.y + area.height.saturating_sub(rendered.height) / 2;
    let buffer = frame.buffer_mut();
    for row in 0..rendered.height {
        for column in 0..rendered.width {
            let index = usize::from(row) * usize::from(rendered.width) + usize::from(column);
            let cell = rendered.cells[index];
            buffer[(origin_x + column, origin_y + row)]
                .set_char(cell.symbol)
                .set_fg(cell.foreground)
                .set_bg(cell.background);
        }
    }
}

fn render_braille_image(frame: &mut Frame, img: &DynamicImage, area: Rect, image_id: u64) {
    if area.width == 0 || area.height == 0 {
        return;
    }
    let key = BrailleRenderKey {
        image_id,
        max_width: area.width,
        max_height: area.height,
    };
    BRAILLE_RENDERS.with(|renders| {
        let mut renders = renders.borrow_mut();
        if !renders.contains_key(&key) {
            let Some(rendered) = build_braille_render(img, area.width, area.height) else {
                return;
            };
            renders.insert(key, rendered);
        }
        if let Some(rendered) = renders.get(&key) {
            paint_braille_render(frame, area, rendered);
        }
    });
}

// ============================================================================
// Album Art Grid — shared Picker and per-album protocol cache
// ============================================================================

const MAX_RENDERED_ARTWORK_ENTRIES: usize = 64;

struct BoundedCache<K, V> {
    values: HashMap<K, V>,
    order: VecDeque<K>,
    capacity: usize,
}

impl<K: Clone + Eq + Hash, V> BoundedCache<K, V> {
    fn new(capacity: usize) -> Self {
        Self {
            values: HashMap::new(),
            order: VecDeque::new(),
            capacity: capacity.max(1),
        }
    }

    fn contains_key(&self, key: &K) -> bool {
        self.values.contains_key(key)
    }

    fn touch(&mut self, key: &K) {
        if let Some(position) = self.order.iter().position(|candidate| candidate == key) {
            self.order.remove(position);
        }
        self.order.push_back(key.clone());
    }

    fn insert(&mut self, key: K, value: V) {
        if self.values.contains_key(&key) {
            self.values.insert(key.clone(), value);
            self.touch(&key);
            return;
        }
        while self.values.len() >= self.capacity {
            let Some(oldest) = self.order.pop_front() else {
                self.values.clear();
                break;
            };
            self.values.remove(&oldest);
        }
        self.values.insert(key.clone(), value);
        self.order.push_back(key);
    }

    fn get(&mut self, key: &K) -> Option<&V> {
        if !self.values.contains_key(key) {
            return None;
        }
        self.touch(key);
        self.values.get(key)
    }

    fn get_mut(&mut self, key: &K) -> Option<&mut V> {
        if !self.values.contains_key(key) {
            return None;
        }
        self.touch(key);
        self.values.get_mut(key)
    }

    fn clear(&mut self) {
        self.values.clear();
        self.order.clear();
    }
}

thread_local! {
    static GRID_PICKER: RefCell<Option<Picker>> = const { RefCell::new(None) };
    static GRID_PROTOCOLS: RefCell<BoundedCache<u64, StatefulProtocol>> = RefCell::new(BoundedCache::new(MAX_RENDERED_ARTWORK_ENTRIES));
    static GRID_BRAILLE_IMAGES: RefCell<BoundedCache<u64, DynamicImage>> = RefCell::new(BoundedCache::new(MAX_RENDERED_ARTWORK_ENTRIES));
    static BRAILLE_RENDERS: RefCell<BoundedCache<BrailleRenderKey, BrailleRender>> = RefCell::new(BoundedCache::new(MAX_RENDERED_ARTWORK_ENTRIES));
    static GRID_ARTWORK_MODE: RefCell<ArtworkMode> = const { RefCell::new(ArtworkMode::Auto) };
    static GRID_NATIVE_PROTOCOL: RefCell<Option<ratatui_image::picker::ProtocolType>> = const { RefCell::new(None) };
}

/// Initialize the grid renderer with a Picker clone.
/// Call once at startup alongside the main artwork renderer init.
pub fn init_grid_renderer(picker: Picker) {
    GRID_NATIVE_PROTOCOL.with(|p| *p.borrow_mut() = Some(picker.protocol_type()));
    GRID_PICKER.with(|p| *p.borrow_mut() = Some(picker));
}

/// Render an album cover image to the given area.
/// Uses a thread-local protocol cache keyed by album rating_key.
/// Returns true if an image was rendered.
pub fn render_grid_image(frame: &mut Frame, area: Rect, key: &str, data: &[u8]) -> bool {
    let mode = GRID_ARTWORK_MODE.with(|m| *m.borrow());

    if mode == ArtworkMode::Braille {
        return render_grid_braille(frame, area, key, data);
    }

    // Protocol-based rendering (Auto/Halfblocks)
    let image_id = artwork_id(key, data);
    let has_protocol = GRID_PROTOCOLS.with(|protos| protos.borrow().contains_key(&image_id));

    if !has_protocol {
        let created = GRID_PICKER.with(|picker_cell| {
            let mut picker_ref = picker_cell.borrow_mut();
            let Some(picker) = picker_ref.as_mut() else {
                return false;
            };
            let Ok(img) = image::load_from_memory(data) else {
                return false;
            };
            let protocol = picker.new_resize_protocol(img);
            GRID_PROTOCOLS.with(|protos| {
                protos.borrow_mut().insert(image_id, protocol);
            });
            true
        });
        if !created {
            return false;
        }
    }

    GRID_PROTOCOLS.with(|protos| {
        let mut map = protos.borrow_mut();
        if let Some(protocol) = map.get_mut(&image_id) {
            // `Resize::Scale` upscales when the source thumbnail is
            // smaller than the render area; `Resize::Crop`/`Resize::Fit`
            // both cap at the source image size in ratatui-image 9, which
            // is why the cached 300 px Plex thumbs used to render as a
            // tiny square in the upper-left of a much larger row.
            let image = StatefulImage::new().resize(Resize::Scale(None));
            frame.render_stateful_widget(image, area, protocol);
            true
        } else {
            false
        }
    })
}

/// Render a grid album cover using braille characters.
fn render_grid_braille(frame: &mut Frame, area: Rect, key: &str, data: &[u8]) -> bool {
    let image_id = artwork_id(key, data);
    let has_image = GRID_BRAILLE_IMAGES.with(|imgs| imgs.borrow().contains_key(&image_id));

    if !has_image {
        let Ok(img) = image::load_from_memory(data) else {
            return false;
        };
        GRID_BRAILLE_IMAGES.with(|imgs| {
            imgs.borrow_mut().insert(image_id, img);
        });
    }

    GRID_BRAILLE_IMAGES.with(|imgs| {
        let mut map = imgs.borrow_mut();
        if let Some(img) = map.get(&image_id) {
            render_braille_image(frame, img, area, image_id);
            true
        } else {
            false
        }
    })
}

/// Clear the grid protocol cache (e.g. on library switch).
pub fn clear_grid_cache() {
    GRID_PROTOCOLS.with(|protos| protos.borrow_mut().clear());
    GRID_BRAILLE_IMAGES.with(|imgs| imgs.borrow_mut().clear());
    BRAILLE_RENDERS.with(|renders| renders.borrow_mut().clear());
}

/// Change the grid renderer's graphics protocol and clear cached images.
pub fn set_grid_protocol_type(protocol_type: ratatui_image::picker::ProtocolType) {
    GRID_PICKER.with(|p| {
        if let Some(ref mut picker) = *p.borrow_mut() {
            picker.set_protocol_type(protocol_type);
        }
    });
    clear_grid_cache();
}

/// Restore the grid renderer's native protocol detected at startup.
pub fn restore_grid_native_protocol() {
    let native = GRID_NATIVE_PROTOCOL.with(|p| *p.borrow());
    if let Some(protocol_type) = native {
        set_grid_protocol_type(protocol_type);
    }
}

/// Set the grid renderer's artwork mode and clear caches.
pub fn set_grid_artwork_mode(mode: ArtworkMode) {
    GRID_ARTWORK_MODE.with(|m| *m.borrow_mut() = mode);
    clear_grid_cache();
}
