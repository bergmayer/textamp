//! Track audio pre-fetch cache.
//!
//! Downloads upcoming tracks in the background so playback starts instantly.
//! Uses an in-memory LRU cache bounded by entry count and total bytes.

use futures::StreamExt;
use std::collections::HashMap;
use std::sync::{Arc, Mutex};
use std::time::{Duration, Instant};

/// Maximum number of cached tracks (10 upcoming + 3 recently played).
const MAX_ENTRIES: usize = 13;

/// Maximum total cache size in bytes. This is deliberately conservative:
/// decoded playback already consumes a separate PCM ring, and an 800 MiB
/// compressed cache caused severe memory pressure on ordinary laptops.
const MAX_BYTES: usize = 128 * 1024 * 1024;

/// Per-track prefetch ceiling. With one active download this also caps memory
/// not yet admitted to the LRU at roughly 32 MiB; oversized tracks fall
/// back to the incremental streaming path.
const MAX_PREFETCH_TRACK_BYTES: usize = 32 * 1024 * 1024;

/// Keep prefetch subordinate to the active incremental playback stream. One
/// download still fills the immediate next-track cache without opening three
/// competing transfers on a slow Plex connection.
const MAX_CONCURRENT_DOWNLOADS: usize = 1;

/// Maximum retry attempts per URL.
const MAX_RETRIES: u32 = 3;

/// A cached audio track with access timestamp for LRU eviction.
struct CachedTrack {
    data: Arc<Vec<u8>>,
    accessed: Instant,
}

/// Thread-safe cache for pre-fetched track audio data.
pub struct TrackAudioCache {
    entries: Mutex<HashMap<String, CachedTrack>>,
    in_flight: Mutex<HashMap<String, u64>>,
    generation: tokio::sync::watch::Sender<u64>,
    pub(crate) semaphore: Arc<tokio::sync::Semaphore>,
}

impl Default for TrackAudioCache {
    fn default() -> Self {
        Self::new()
    }
}

impl TrackAudioCache {
    /// Create a new empty cache.
    pub fn new() -> Self {
        Self {
            entries: Mutex::new(HashMap::new()),
            in_flight: Mutex::new(HashMap::new()),
            generation: tokio::sync::watch::channel(0).0,
            semaphore: Arc::new(tokio::sync::Semaphore::new(MAX_CONCURRENT_DOWNLOADS)),
        }
    }

    /// Get cached audio data, updating the access timestamp.
    /// Returns an Arc clone (cheap pointer copy, not a full data copy).
    pub fn get(&self, key: &str) -> Option<Arc<Vec<u8>>> {
        let mut entries = super::lock_or_recover(&self.entries);
        if let Some(entry) = entries.get_mut(key) {
            entry.accessed = Instant::now();
            Some(entry.data.clone())
        } else {
            None
        }
    }

    /// Insert audio data into the cache, evicting LRU entries if limits exceeded.
    pub fn insert(&self, key: String, data: Vec<u8>) {
        if data.len() > MAX_BYTES {
            tracing::debug!(
                "Track cache: skipped {}-byte item larger than cache budget",
                data.len()
            );
            return;
        }
        let mut entries = super::lock_or_recover(&self.entries);

        let data_size = data.len();
        entries.insert(
            key,
            CachedTrack {
                data: Arc::new(data),
                accessed: Instant::now(),
            },
        );

        // Evict by count
        while entries.len() > MAX_ENTRIES {
            if let Some(oldest_key) = Self::find_oldest(&entries) {
                entries.remove(&oldest_key);
            } else {
                break;
            }
        }

        // Evict by total size
        let mut total: usize = entries.values().map(|e| e.data.len()).sum();
        while total > MAX_BYTES {
            if let Some(oldest_key) = Self::find_oldest(&entries) {
                if let Some(removed) = entries.remove(&oldest_key) {
                    total -= removed.data.len();
                }
            } else {
                break;
            }
        }

        if data_size > 0 {
            tracing::debug!(
                "Track cache: inserted ({} bytes), {} entries, {:.1} MB total",
                data_size,
                entries.len(),
                total as f64 / (1024.0 * 1024.0),
            );
        }
    }

    /// Atomically reject a result from a flushed playback context. Holding the
    /// generation read guard through insertion orders this against flush.
    pub(crate) fn insert_if_current(&self, key: String, data: Vec<u8>, generation: u64) -> bool {
        let current = self.generation.borrow();
        if *current != generation {
            return false;
        }
        self.insert(key, data);
        true
    }

    /// Check if a key is cached (without cloning data).
    pub fn contains(&self, key: &str) -> bool {
        super::lock_or_recover(&self.entries).contains_key(key)
    }

    /// Mark a key as currently being downloaded.
    /// Returns the cache generation if the fetch was admitted.
    pub fn start_fetch(&self, key: &str) -> Option<u64> {
        if self.contains(key) {
            return None;
        }
        let generation = *self.generation.borrow();
        let mut in_flight = super::lock_or_recover(&self.in_flight);
        if in_flight.contains_key(key) {
            None
        } else {
            in_flight.insert(key.to_string(), generation);
            Some(generation)
        }
    }

    /// Remove a key from the in-flight set (download finished or failed).
    pub fn finish_fetch(&self, key: &str, generation: u64) {
        let mut in_flight = super::lock_or_recover(&self.in_flight);
        if in_flight.get(key) == Some(&generation) {
            in_flight.remove(key);
        }
    }

    pub(crate) fn generation_is_current(&self, generation: u64) -> bool {
        *self.generation.borrow() == generation
    }

    pub(crate) async fn cancelled(&self, generation: u64) {
        let mut receiver = self.generation.subscribe();
        let _ = receiver.wait_for(|current| *current != generation).await;
    }

    /// Remove a specific entry (e.g., corrupt data fallback).
    pub fn remove(&self, key: &str) {
        let removed = super::lock_or_recover(&self.entries).remove(key);
        if let Some(removed) = removed {
            let _ = std::thread::Builder::new()
                .name("textamp-audio-cache-drop".to_string())
                .spawn(move || drop(removed));
        }
    }

    /// Clear all entries and in-flight state.
    pub fn flush(&self) {
        self.generation
            .send_modify(|generation| *generation = generation.wrapping_add(1));
        let previous = {
            let mut entries = super::lock_or_recover(&self.entries);
            std::mem::take(&mut *entries)
        };
        super::lock_or_recover(&self.in_flight).clear();
        if !previous.is_empty() {
            let _ = std::thread::Builder::new()
                .name("textamp-audio-cache-drop".to_string())
                .spawn(move || drop(previous));
        }
        tracing::debug!("Track cache flushed");
    }

    /// Find the key with the oldest access timestamp.
    fn find_oldest(entries: &HashMap<String, CachedTrack>) -> Option<String> {
        entries
            .iter()
            .min_by_key(|(_, v)| v.accessed)
            .map(|(k, _)| k.clone())
    }
}

impl std::fmt::Debug for TrackAudioCache {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        let entries = super::lock_or_recover(&self.entries);
        let in_flight = super::lock_or_recover(&self.in_flight);
        f.debug_struct("TrackAudioCache")
            .field("entries", &entries.len())
            .field("in_flight", &in_flight.len())
            .finish()
    }
}

type PrefetchGeneration<'a> = Option<(&'a TrackAudioCache, u64)>;

fn prefetch_cancelled(cancellation: PrefetchGeneration<'_>) -> bool {
    cancellation.is_some_and(|(cache, generation)| !cache.generation_is_current(generation))
}

pub(crate) async fn download_track_audio_inner(
    url: &str,
    fallback_url: Option<&str>,
    headers: reqwest::header::HeaderMap,
    http_client: reqwest::Client,
    cancellation: PrefetchGeneration<'_>,
) -> Result<Vec<u8>, String> {
    // Try primary URL
    match download_with_retry(url, &headers, &http_client, cancellation).await {
        Ok(data) => Ok(data),
        Err(primary_err) => {
            if prefetch_cancelled(cancellation) {
                return Err("Prefetch cancelled".to_string());
            }
            tracing::warn!("Pre-fetch primary download failed: {}", primary_err);
            // Try fallback if available
            if let Some(fb_url) = fallback_url {
                match download_with_retry(fb_url, &headers, &http_client, cancellation).await {
                    Ok(data) => return Ok(data),
                    Err(fb_err) => {
                        return Err(format!(
                            "Both URLs failed: primary={}, fallback={}",
                            primary_err, fb_err
                        ));
                    }
                }
            }
            Err(primary_err)
        }
    }
}

/// Download from a single URL with exponential backoff retry.
async fn download_with_retry(
    url: &str,
    headers: &reqwest::header::HeaderMap,
    client: &reqwest::Client,
    cancellation: PrefetchGeneration<'_>,
) -> Result<Vec<u8>, String> {
    let backoff_secs = [1, 2, 4];

    for attempt in 0..MAX_RETRIES {
        if prefetch_cancelled(cancellation) {
            return Err("Prefetch cancelled".to_string());
        }
        match client.get(url).headers(headers.clone()).send().await {
            Ok(response) => {
                let status = response.status();
                if status.is_success() {
                    if response
                        .content_length()
                        .is_some_and(|length| length > MAX_PREFETCH_TRACK_BYTES as u64)
                    {
                        return Err(format!(
                            "Track exceeds prefetch limit of {} MiB",
                            MAX_PREFETCH_TRACK_BYTES / (1024 * 1024)
                        ));
                    }
                    // Check for HTML content-type (Plex can return HTML errors with 200)
                    let is_html = response
                        .headers()
                        .get(reqwest::header::CONTENT_TYPE)
                        .and_then(|v| v.to_str().ok())
                        .map(|ct| ct.contains("text/html"))
                        .unwrap_or(false);
                    if is_html {
                        if attempt + 1 < MAX_RETRIES {
                            let delay = backoff_secs[attempt as usize];
                            tracing::debug!(
                                "Pre-fetch got HTML content-type (attempt {}), retrying in {}s",
                                attempt + 1,
                                delay
                            );
                            tokio::time::sleep(Duration::from_secs(delay)).await;
                            continue;
                        }
                        return Err("Server returned HTML instead of audio".to_string());
                    }

                    let initial_capacity = response
                        .content_length()
                        .and_then(|length| usize::try_from(length).ok())
                        .unwrap_or(256 * 1024)
                        .min(MAX_PREFETCH_TRACK_BYTES);
                    let mut data = Vec::with_capacity(initial_capacity);
                    let mut body = response.bytes_stream();
                    let mut body_error = None;
                    while let Some(chunk) = body.next().await {
                        if prefetch_cancelled(cancellation) {
                            return Err("Prefetch cancelled".to_string());
                        }
                        match chunk {
                            Ok(chunk) => {
                                if data.len().saturating_add(chunk.len()) > MAX_PREFETCH_TRACK_BYTES
                                {
                                    return Err(format!(
                                        "Track exceeds prefetch limit of {} MiB",
                                        MAX_PREFETCH_TRACK_BYTES / (1024 * 1024)
                                    ));
                                }
                                data.extend_from_slice(&chunk);
                            }
                            Err(error) => {
                                body_error = Some(error);
                                break;
                            }
                        }
                    }
                    match body_error {
                        None => {
                            // Check downloaded bytes for HTML markers (small responses only)
                            if data.len() < 1024 * 1024 {
                                let prefix = &data[..data.len().min(256)];
                                let text = String::from_utf8_lossy(prefix).to_lowercase();
                                if text.contains("<!doctype html")
                                    || text.contains("<html")
                                    || text.contains("<head")
                                {
                                    if attempt + 1 < MAX_RETRIES {
                                        let delay = backoff_secs[attempt as usize];
                                        tracing::debug!(
                                            "Pre-fetch got HTML body (attempt {}), retrying in {}s",
                                            attempt + 1,
                                            delay
                                        );
                                        tokio::time::sleep(Duration::from_secs(delay)).await;
                                        continue;
                                    }
                                    return Err("Server returned HTML instead of audio".to_string());
                                }
                            }
                            return Ok(data);
                        }
                        Some(_error) => {
                            if attempt + 1 < MAX_RETRIES {
                                let delay = backoff_secs[attempt as usize];
                                tracing::debug!(
                                    "Download body error (attempt {}), retrying in {}s",
                                    attempt + 1,
                                    delay
                                );
                                tokio::time::sleep(Duration::from_secs(delay)).await;
                                continue;
                            }
                            return Err("Audio transfer was interrupted".to_string());
                        }
                    }
                }

                // Retry on 5xx and 429
                if (status.is_server_error() || status == reqwest::StatusCode::TOO_MANY_REQUESTS)
                    && attempt + 1 < MAX_RETRIES
                {
                    let delay = response
                        .headers()
                        .get(reqwest::header::RETRY_AFTER)
                        .and_then(|value| value.to_str().ok())
                        .and_then(|value| value.parse::<u64>().ok())
                        .unwrap_or(backoff_secs[attempt as usize])
                        .min(30);
                    tracing::debug!(
                        "HTTP {} (attempt {}), retrying in {}s",
                        status,
                        attempt + 1,
                        delay
                    );
                    tokio::time::sleep(Duration::from_secs(delay)).await;
                    continue;
                }

                // 4xx (except 429) - don't retry
                return Err(format!("HTTP {}", status));
            }
            Err(error) => {
                // A reqwest transport error may embed the request URL. Plex
                // transcode URLs contain the token in their query string, so
                // never copy that error verbatim into logs or UI state.
                let reason = if error.is_timeout() {
                    "request timed out"
                } else if error.is_connect() {
                    "connection failed"
                } else {
                    "request failed"
                };
                // Retry on timeout and connection errors
                if attempt + 1 < MAX_RETRIES {
                    let delay = backoff_secs[attempt as usize];
                    tracing::debug!(
                        "Request error (attempt {}), retrying in {}s",
                        attempt + 1,
                        delay
                    );
                    tokio::time::sleep(Duration::from_secs(delay)).await;
                    continue;
                }
                return Err(reason.to_string());
            }
        }
    }

    Err("Max retries exceeded".to_string())
}

#[cfg(test)]
mod tests {
    #[tokio::test]
    async fn flush_wakes_prefetch_and_rejects_old_bytes() {
        let cache = std::sync::Arc::new(super::TrackAudioCache::new());
        let generation = cache.start_fetch("track").unwrap();
        let observer = cache.clone();
        let waiting = tokio::spawn(async move { observer.cancelled(generation).await });
        cache.flush();
        tokio::time::timeout(std::time::Duration::from_secs(1), waiting)
            .await
            .unwrap()
            .unwrap();
        assert!(!cache.insert_if_current("track".into(), vec![1], generation));
        assert!(!cache.contains("track"));
    }
    use super::*;

    #[test]
    fn flush_invalidates_in_flight_download_without_removing_new_generation() {
        let cache = Arc::new(TrackAudioCache::new());
        let old_generation = cache.start_fetch("same-key").unwrap();
        cache.flush();
        let new_generation = cache.start_fetch("same-key").unwrap();
        assert_ne!(old_generation, new_generation);

        cache.finish_fetch("same-key", old_generation);
        assert!(cache.start_fetch("same-key").is_none());

        cache.finish_fetch("same-key", new_generation);
        assert!(cache.start_fetch("same-key").is_some());
    }

    #[tokio::test]
    async fn stale_prefetch_is_cancelled_before_opening_network_request() {
        let cache = TrackAudioCache::new();
        let generation = cache.start_fetch("track").unwrap();
        cache.flush();

        let error = download_with_retry(
            "http://127.0.0.1:9/should-not-be-opened",
            &reqwest::header::HeaderMap::new(),
            &reqwest::Client::new(),
            Some((&cache, generation)),
        )
        .await
        .unwrap_err();

        assert_eq!(error, "Prefetch cancelled");
    }
}
