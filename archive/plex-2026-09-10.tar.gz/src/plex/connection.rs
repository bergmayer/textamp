//! Plex server connection discovery, classification, measurement, and ranking.

use super::models::{PlexServer, ServerConnection};
use super::{test_connection_for_server, ApiError};
use futures::future::join_all;
use std::collections::HashSet;
use std::net::{IpAddr, Ipv4Addr};
use std::time::Instant;

/// The network path used to reach Plex.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ConnectionKind {
    Loopback,
    Lan,
    Configured,
    Remote,
    Relay,
}

impl ConnectionKind {
    pub fn label(self) -> &'static str {
        match self {
            Self::Loopback => "this Mac",
            Self::Lan => "LAN",
            Self::Configured => "configured route",
            Self::Remote => "Plex Remote Access",
            Self::Relay => "Plex Relay",
        }
    }

    /// Small stability bias applied after measuring latency. Relay remains a
    /// last resort; a marginally faster public route should not displace a LAN
    /// or explicitly configured direct route.
    fn stability_penalty_ms(self) -> u64 {
        match self {
            Self::Loopback | Self::Lan => 0,
            Self::Configured => 5,
            Self::Remote => 20,
            Self::Relay => 10_000,
        }
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct MeasuredConnection {
    pub url: String,
    pub kind: ConnectionKind,
    pub latency_ms: u64,
}

#[derive(Debug, Clone)]
pub struct ConnectionSelection {
    pub selected: MeasuredConnection,
    /// Other healthy routes, already ordered for failover.
    pub fallbacks: Vec<MeasuredConnection>,
    pub failed_count: usize,
}

#[derive(Debug, Clone)]
struct Candidate {
    url: String,
    kind: ConnectionKind,
}

fn is_private_ipv4(ip: Ipv4Addr) -> bool {
    ip.is_private() || ip.is_link_local()
}

pub fn classify_connection(url: &str, advertised: Option<&ServerConnection>) -> ConnectionKind {
    if advertised.is_some_and(|connection| connection.relay) {
        return ConnectionKind::Relay;
    }

    let Ok(parsed) = reqwest::Url::parse(url) else {
        return ConnectionKind::Remote;
    };
    let host = parsed
        .host_str()
        .unwrap_or_default()
        .trim_matches(['[', ']']);
    if host.eq_ignore_ascii_case("localhost") || host == "127.0.0.1" || host == "::1" {
        return ConnectionKind::Loopback;
    }
    if let Ok(ip) = host.parse::<IpAddr>() {
        return match ip {
            IpAddr::V4(ip) if is_private_ipv4(ip) => ConnectionKind::Lan,
            IpAddr::V6(ip) if ip.is_unique_local() || ip.is_unicast_link_local() => {
                ConnectionKind::Lan
            }
            _ => ConnectionKind::Remote,
        };
    }
    if advertised.is_some_and(|connection| connection.local) {
        ConnectionKind::Lan
    } else {
        ConnectionKind::Remote
    }
}

fn dashed_plex_direct_ip(url: &str) -> Option<Ipv4Addr> {
    let parsed = reqwest::Url::parse(url).ok()?;
    let host = parsed.host_str()?;
    if !host.ends_with(".plex.direct") {
        return None;
    }
    host.split('.').next()?.replace('-', ".").parse().ok()
}

fn insert_candidate(
    candidates: &mut Vec<Candidate>,
    seen: &mut HashSet<String>,
    url: &str,
    advertised: Option<&ServerConnection>,
    configured: bool,
) {
    let url = url.trim().trim_end_matches('/');
    if url.is_empty() || reqwest::Url::parse(url).is_err() || !seen.insert(url.to_string()) {
        return;
    }
    let classified = classify_connection(url, advertised);
    let kind = if configured && matches!(classified, ConnectionKind::Remote) {
        ConnectionKind::Configured
    } else {
        classified
    };
    candidates.push(Candidate {
        url: url.to_string(),
        kind,
    });
}

fn connection_candidates(server: &PlexServer, extra_urls: &[String]) -> Vec<Candidate> {
    let mut candidates = Vec::new();
    let mut seen = HashSet::new();
    let mut ports = HashSet::from([32400]);

    for connection in &server.connections {
        if let Ok(parsed) = reqwest::Url::parse(&connection.uri) {
            if let Some(port) = parsed.port_or_known_default() {
                ports.insert(port);
            }
        }
    }
    for url in extra_urls {
        if let Ok(parsed) = reqwest::Url::parse(url) {
            if let Some(port) = parsed.port_or_known_default() {
                ports.insert(port);
            }
        }
        insert_candidate(&mut candidates, &mut seen, url, None, true);
    }
    for connection in &server.connections {
        insert_candidate(
            &mut candidates,
            &mut seen,
            &connection.uri,
            Some(connection),
            false,
        );
    }

    // Same-host installations and manually forwarded nonstandard ports.
    for port in &ports {
        insert_candidate(
            &mut candidates,
            &mut seen,
            &format!("http://127.0.0.1:{port}"),
            None,
            false,
        );
        insert_candidate(
            &mut candidates,
            &mut seen,
            &format!("http://localhost:{port}"),
            None,
            false,
        );
    }

    // plex.direct encodes the actual IP in its first hostname label. A direct
    // LAN HTTP route avoids DNS rebinding and TLS/NAT-loopback trouble while
    // retaining the advertised secure URL as a measured fallback.
    for connection in &server.connections {
        if connection.local {
            if let Some(ip) = dashed_plex_direct_ip(&connection.uri) {
                for port in &ports {
                    insert_candidate(
                        &mut candidates,
                        &mut seen,
                        &format!("http://{ip}:{port}"),
                        None,
                        false,
                    );
                }
            }
        }
    }

    candidates
}

fn connection_score(connection: &MeasuredConnection) -> u64 {
    connection
        .latency_ms
        .saturating_add(connection.kind.stability_penalty_ms())
}

/// Probe every candidate concurrently and return healthy routes in preferred
/// order. Selection combines measured response time with a small stability
/// bias; a relay can win only when no direct route works.
pub async fn select_connection(
    server: &PlexServer,
    token: &str,
    client_identifier: &str,
    extra_urls: &[String],
) -> Result<ConnectionSelection, ApiError> {
    let candidates = connection_candidates(server, extra_urls);
    if candidates.is_empty() {
        return Err(ApiError::Connection(
            "no server addresses were available".to_string(),
        ));
    }

    let probes = candidates.into_iter().map(|candidate| {
        let token = token.to_string();
        let client_identifier = client_identifier.to_string();
        async move {
            let started = Instant::now();
            let result = test_connection_for_server(
                &candidate.url,
                &token,
                &client_identifier,
                Some(&server.client_identifier),
            )
            .await;
            (candidate, started.elapsed(), result)
        }
    });

    let results = join_all(probes).await;
    let failed_count = results
        .iter()
        .filter(|(_, _, result)| result.is_err())
        .count();
    let mut healthy: Vec<_> = results
        .into_iter()
        .filter_map(|(candidate, elapsed, result)| match result {
            Ok(()) => {
                let measured = MeasuredConnection {
                    url: candidate.url,
                    kind: candidate.kind,
                    latency_ms: elapsed.as_millis().min(u64::MAX as u128) as u64,
                };
                tracing::info!(
                    "Connection probe succeeded via {} in {} ms: {}",
                    measured.kind.label(),
                    measured.latency_ms,
                    measured.url
                );
                Some(measured)
            }
            Err(error) => {
                tracing::debug!(
                    "Connection probe failed via {} at {}: {}",
                    candidate.kind.label(),
                    candidate.url,
                    error
                );
                None
            }
        })
        .collect();
    healthy.sort_by_key(connection_score);

    if healthy.is_empty() {
        return Err(ApiError::Connection(format!(
            "none of the {failed_count} discovered routes responded"
        )));
    }
    let selected = healthy.remove(0);
    Ok(ConnectionSelection {
        selected,
        fallbacks: healthy,
        failed_count,
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn classifies_lan_remote_and_relay_without_vendor_rules() {
        assert_eq!(
            classify_connection("http://192.168.4.47:32400", None),
            ConnectionKind::Lan
        );
        assert_eq!(
            classify_connection("http://100.101.102.103:32400", None),
            ConnectionKind::Remote
        );
        assert_eq!(
            classify_connection("https://203.0.113.5:32400", None),
            ConnectionKind::Remote
        );
        let relay = ServerConnection {
            uri: "https://relay.plex.direct".to_string(),
            local: false,
            relay: true,
        };
        assert_eq!(
            classify_connection(&relay.uri, Some(&relay)),
            ConnectionKind::Relay
        );
    }

    #[test]
    fn stable_direct_route_beats_marginally_faster_public_route() {
        let lan = MeasuredConnection {
            url: "http://192.168.1.2:32400".to_string(),
            kind: ConnectionKind::Lan,
            latency_ms: 15,
        };
        let remote = MeasuredConnection {
            url: "https://example.com:32400".to_string(),
            kind: ConnectionKind::Remote,
            latency_ms: 4,
        };
        assert!(connection_score(&lan) < connection_score(&remote));
    }

    #[test]
    fn relay_is_a_last_resort_even_when_its_probe_is_faster() {
        let configured = MeasuredConnection {
            url: "http://100.101.102.103:32400".to_string(),
            kind: ConnectionKind::Configured,
            latency_ms: 80,
        };
        let relay = MeasuredConnection {
            url: "https://relay.plex.direct".to_string(),
            kind: ConnectionKind::Relay,
            latency_ms: 5,
        };
        assert!(connection_score(&configured) < connection_score(&relay));
    }

    #[test]
    fn candidate_set_marks_an_extra_url_as_configured() {
        let server = PlexServer {
            name: "test".to_string(),
            client_identifier: "server-id".to_string(),
            connections: Vec::new(),
            owned: true,
        };
        let candidates =
            connection_candidates(&server, &["https://plex.private.example:32400".to_string()]);
        assert!(candidates.iter().any(|candidate| {
            candidate.url == "https://plex.private.example:32400"
                && candidate.kind == ConnectionKind::Configured
        }));
    }
}
