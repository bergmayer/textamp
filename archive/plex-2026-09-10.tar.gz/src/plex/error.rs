//! API error types.

use thiserror::Error;

#[derive(Error, Debug)]
pub enum ApiError {
    #[error("HTTP client initialization failed: {0}")]
    ClientInitialization(String),

    #[error("HTTP request failed: {0}")]
    Http(#[from] reqwest::Error),

    /// Transport failure whose source URL may contain credentials. The
    /// sanitized message deliberately omits the underlying reqwest error.
    #[error("Connection failed: {0}")]
    Connection(String),

    #[error("Request timed out")]
    Timeout,

    #[error("JSON parsing failed: {0}")]
    Json(#[from] serde_json::Error),

    #[error("No server selected")]
    NoServerSelected,

    #[error("Not authenticated")]
    NotAuthenticated,

    #[error("Invalid token")]
    InvalidToken,

    #[error("Authentication failed: {0}")]
    AuthFailed(String),

    #[error("No media available for track")]
    NoMediaAvailable,

    #[error("Server error: {status} - {message}")]
    ServerError { status: u16, message: String },

    #[error("Library not found: {0}")]
    LibraryNotFound(String),

    #[error("Item not found: {0}")]
    ItemNotFound(String),

    #[error("Parse error: {0}")]
    ParseError(String),

    #[error("Invalid header value: {0}")]
    InvalidHeader(String),

    #[error("HTTP response exceeded the {limit_bytes} byte safety limit")]
    ResponseTooLarge { limit_bytes: usize },
}

impl ApiError {
    /// Transport failures warrant a connectivity check. A timeout alone does
    /// not prove the route is down; background refreshes probe before recovery.
    pub fn is_connection_error(&self) -> bool {
        match self {
            ApiError::Http(e) => e.is_connect() || e.is_timeout() || e.is_body(),
            ApiError::Connection(_) => true,
            ApiError::NoServerSelected => true,
            _ => false,
        }
    }

    pub fn is_timeout(&self) -> bool {
        matches!(self, Self::Timeout) || matches!(self, Self::Http(e) if e.is_timeout())
    }

    pub fn is_retryable(&self) -> bool {
        self.is_timeout()
            || self.is_connection_error()
            || matches!(
                self,
                Self::ServerError {
                    status: 429 | 500..=599,
                    ..
                }
            )
    }

    /// User-facing text omits low-level reqwest URLs and explains the recovery
    /// that Textamp will perform automatically.
    pub fn user_message(&self, context: &str) -> String {
        if self.is_timeout() {
            return format!("{context}: Plex did not respond in time. Try again shortly.");
        }
        if self.is_connection_error() {
            return format!("{context}: could not reach Plex. Cached data remains usable.");
        }
        let detail = match self {
            Self::NotAuthenticated | Self::InvalidToken | Self::AuthFailed(_)
            | Self::ServerError { status: 401, .. } =>
                "Plex authentication expired or was rejected. Sign in again in Settings (F2).",
            Self::ServerError { status: 403, .. } =>
                "Plex denied access. Check your account's access to this server, library, or feature.",
            Self::ServerError { status: 404, .. } | Self::ItemNotFound(_) =>
                "Plex could not find the requested item or endpoint. Refresh the list and try again; this feature may be unavailable on the server.",
            Self::ServerError { status: 429, .. } =>
                "Plex is rate limiting requests. Wait a moment and try again.",
            Self::ServerError { status: 500..=599, .. } =>
                "Plex could not complete the request. Try again shortly; check the server if it persists.",
            Self::ServerError { .. } =>
                "Plex rejected the request. Refresh the list and try again.",
            Self::NoMediaAvailable =>
                "No playable media is available. Check that Plex can access the original file.",
            Self::Json(_) | Self::ParseError(_) =>
                "Plex data or the selected station address was invalid. Refresh the list and try again.",
            Self::LibraryNotFound(_) =>
                "The music library is unavailable. Select an accessible library in Settings (F2).",
            Self::ResponseTooLarge { .. } =>
                "Plex returned more data than Textamp can safely accept.",
            _ => return format!("{context}: {self}"),
        };
        format!("{context}: {detail}")
    }
}
