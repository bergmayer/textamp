//! Plex API client.
//!
//! Handles all communication with the Plex Media Server.

use super::auth::PlexClientInfo;
use super::constants::*;
use super::error::ApiError;
use super::models::*;
use crate::util::truncate_to_boundary;
use crate::util::SecretString;
use futures::StreamExt;
use reqwest::header::{HeaderMap, RETRY_AFTER};
use reqwest::{Client, Response};
use std::sync::{Arc, OnceLock};
use std::time::Duration;

const HTTP_CONNECT_TIMEOUT: Duration = Duration::from_secs(10);
const HTTP_READ_STALL_TIMEOUT: Duration = Duration::from_secs(30);
const PLAY_QUEUE_TIMEOUT: Duration = Duration::from_secs(8);
const MAX_GET_ATTEMPTS: usize = 3;
const MAX_RETRY_DELAY: Duration = Duration::from_secs(30);
const MAX_ARTWORK_BYTES: usize = 20 * 1024 * 1024;
pub(crate) const MAX_METADATA_RESPONSE_BYTES: usize = 512 * 1024 * 1024;
pub(crate) const MAX_SMALL_RESPONSE_BYTES: usize = 8 * 1024 * 1024;
pub(crate) const MAX_ERROR_RESPONSE_BYTES: usize = 64 * 1024;
const MIN_PLAUSIBLE_MUSIC_YEAR: i32 = 1870;
const MAX_PLAUSIBLE_MUSIC_YEAR: i32 = 2100;

/// Validate the library component instead of silently selecting library 5.
/// Station/category paths come from Plex or user-selected cached metadata.
pub(crate) fn station_library_key(key: &str) -> Result<&str, ApiError> {
    key.strip_prefix("/library/sections/")
        .and_then(|rest| rest.split_once('/'))
        .map(|(library, _)| library)
        .filter(|library| !library.is_empty() && library.bytes().all(|b| b.is_ascii_digit()))
        .ok_or_else(|| {
            ApiError::ParseError("Invalid station library path; refresh the station list".into())
        })
}

fn station_parts(key: &str) -> Result<(&str, &str, Option<&str>), ApiError> {
    let library = station_library_key(key)?;
    let (path, query) = key
        .split_once('?')
        .map_or((key, None), |(p, q)| (p, Some(q)));
    let prefix = format!("/library/sections/{library}/stations/");
    let kind = path
        .strip_prefix(&prefix)
        .filter(|kind| {
            !kind.is_empty()
                && kind
                    .bytes()
                    .all(|b| b.is_ascii_alphanumeric() || b == b'_' || b == b'-')
        })
        .ok_or_else(|| {
            ApiError::ParseError("Invalid station path; select a playable station".into())
        })?;
    Ok((library, kind, query))
}

fn parse_plausible_music_year(label: &str) -> Option<i32> {
    let digits: String = label.chars().filter(char::is_ascii_digit).collect();
    if digits.len() != 4 {
        return None;
    }
    let year = digits.parse().ok()?;
    (MIN_PLAUSIBLE_MUSIC_YEAR..=MAX_PLAUSIBLE_MUSIC_YEAR)
        .contains(&year)
        .then_some(year)
}

fn is_plausible_decade(label: &str) -> bool {
    parse_plausible_music_year(label).is_some_and(|year| year % 10 == 0)
}

fn decode_response_text(body: Vec<u8>) -> String {
    match String::from_utf8(body) {
        Ok(text) => text,
        Err(error) => {
            let invalid_at = error.utf8_error().valid_up_to();
            tracing::warn!(
                invalid_at,
                "Plex returned non-UTF-8 metadata; replacing invalid bytes"
            );
            String::from_utf8_lossy(&error.into_bytes()).into_owned()
        }
    }
}

/// Read a response body incrementally with a hard upper bound. `reqwest`'s
/// convenience `text()`/`json()` methods buffer without a limit, allowing a
/// broken or hostile server to exhaust the process.
pub(crate) async fn read_response_text_limited(
    response: Response,
    limit_bytes: usize,
) -> Result<String, ApiError> {
    if response
        .content_length()
        .is_some_and(|length| length > limit_bytes as u64)
    {
        return Err(ApiError::ResponseTooLarge { limit_bytes });
    }

    let capacity = response
        .content_length()
        .unwrap_or(0)
        .min(limit_bytes as u64) as usize;
    let mut body = Vec::with_capacity(capacity);
    let mut stream = response.bytes_stream();
    while let Some(chunk) = stream.next().await {
        let chunk = chunk?;
        if body.len().saturating_add(chunk.len()) > limit_bytes {
            return Err(ApiError::ResponseTooLarge { limit_bytes });
        }
        body.extend_from_slice(&chunk);
    }

    Ok(decode_response_text(body))
}

pub(crate) async fn read_error_body(response: Response) -> String {
    match read_response_text_limited(response, MAX_ERROR_RESPONSE_BYTES).await {
        Ok(body) => body,
        Err(ApiError::ResponseTooLarge { .. }) => "response body was too large".to_string(),
        Err(error) => format!("unable to read response body: {error}"),
    }
}

/// Downloads and control/probe requests share this pool. Its read-stall
/// deadline bounds stalled audio transfers without limiting their total length.
/// Metadata GETs use their own pool and whole-request deadlines below.
pub(crate) fn shared_http_client() -> Result<Client, ApiError> {
    static CLIENT: OnceLock<Result<Client, String>> = OnceLock::new();
    match CLIENT.get_or_init(|| {
        Client::builder()
            .connect_timeout(HTTP_CONNECT_TIMEOUT)
            .read_timeout(HTTP_READ_STALL_TIMEOUT)
            .pool_idle_timeout(Duration::from_secs(90))
            .build()
            .map_err(|error| error.to_string())
    }) {
        Ok(client) => Ok(client.clone()),
        Err(error) => Err(ApiError::ClientInitialization(error.clone())),
    }
}

/// Metadata requests have operation-specific whole-request deadlines. Keep
/// audio's read-stall limit separate so a slow database query cannot override
/// playback download safeguards (or vice versa).
fn metadata_http_client() -> Result<Client, ApiError> {
    static CLIENT: OnceLock<Result<Client, String>> = OnceLock::new();
    match CLIENT.get_or_init(|| {
        Client::builder()
            .connect_timeout(HTTP_CONNECT_TIMEOUT)
            .pool_idle_timeout(Duration::from_secs(90))
            .build()
            .map_err(|error| error.to_string())
    }) {
        Ok(client) => Ok(client.clone()),
        Err(error) => Err(ApiError::ClientInitialization(error.clone())),
    }
}

fn retry_delay(response: &Response, attempt: usize) -> Duration {
    response
        .headers()
        .get(RETRY_AFTER)
        .and_then(|value| value.to_str().ok())
        .and_then(|value| value.parse::<u64>().ok())
        .map(Duration::from_secs)
        .unwrap_or_else(|| Duration::from_secs(1_u64 << attempt.min(4)))
        .min(MAX_RETRY_DELAY)
}

fn redact_url(url: &str) -> String {
    let Ok(mut parsed) = reqwest::Url::parse(url) else {
        return "<invalid URL>".to_string();
    };
    let query: Vec<(String, String)> = parsed
        .query_pairs()
        .filter(|(key, _)| !key.eq_ignore_ascii_case(HEADER_PLEX_TOKEN))
        .map(|(key, value)| (key.into_owned(), value.into_owned()))
        .collect();
    parsed.set_query(None);
    if !query.is_empty() {
        parsed.query_pairs_mut().extend_pairs(query);
    }
    parsed.to_string()
}

/// Plex API client.
#[derive(Clone)]
pub struct PlexClient {
    http: Client,
    metadata_http: Client,
    request_timeout: Duration,
    client_info: PlexClientInfo,
    /// Shared rather than copied when `PlexClient` is cloned for a task.
    auth_token: Option<Arc<SecretString>>,
    server_url: Option<String>,
    cached_machine_id: Option<String>,
}

impl PlexClient {
    /// Create a new PlexClient.
    pub fn new(client_info: PlexClientInfo) -> Result<Self, ApiError> {
        Ok(Self {
            http: shared_http_client()?,
            metadata_http: metadata_http_client()?,
            request_timeout: Duration::from_secs(DEFAULT_TIMEOUT_SECS),
            client_info,
            auth_token: None,
            server_url: None,
            cached_machine_id: None,
        })
    }

    /// Create a new PlexClient with server URL, optional token, and client_identifier.
    /// Used for background tasks that need their own client instance.
    ///
    /// IMPORTANT: The client_identifier MUST match the one the token was issued for,
    /// otherwise Plex will reject requests with 400 errors. Always pass the
    /// client_identifier from auth.toml, not a new random one.
    pub fn new_with_url(
        server_url: &str,
        token: Option<&str>,
        client_identifier: &str,
    ) -> Result<Self, ApiError> {
        let client_info = PlexClientInfo {
            client_identifier: client_identifier.to_string(),
            ..PlexClientInfo::default()
        };

        Ok(Self {
            http: shared_http_client()?,
            metadata_http: metadata_http_client()?,
            request_timeout: Duration::from_secs(DEFAULT_TIMEOUT_SECS),
            client_info,
            auth_token: token.map(|token| Arc::new(SecretString::from(token))),
            server_url: Some(server_url.trim_end_matches('/').to_string()),
            cached_machine_id: None,
        })
    }

    /// Create a new PlexClient with a specific timeout (for large responses like AllTracks).
    pub fn new_with_url_and_timeout(
        server_url: &str,
        token: Option<&str>,
        client_identifier: &str,
        timeout_secs: u64,
    ) -> Result<Self, ApiError> {
        let client_info = PlexClientInfo {
            client_identifier: client_identifier.to_string(),
            ..PlexClientInfo::default()
        };

        Ok(Self {
            http: shared_http_client()?,
            metadata_http: metadata_http_client()?,
            request_timeout: Duration::from_secs(timeout_secs),
            client_info,
            auth_token: token.map(|token| Arc::new(SecretString::from(token))),
            server_url: Some(server_url.trim_end_matches('/').to_string()),
            cached_machine_id: None,
        })
    }

    /// Set the authentication token.
    pub fn set_auth_token(&mut self, token: impl Into<SecretString>) {
        self.auth_token = Some(Arc::new(token.into()));
    }

    /// Drop the authenticated server context. The final shared credential
    /// owner zeroizes its allocation automatically.
    pub fn clear_session(&mut self) {
        self.auth_token = None;
        self.server_url = None;
        self.cached_machine_id = None;
    }

    /// Get the authentication token.
    pub fn token(&self) -> Option<&str> {
        self.auth_token.as_ref().map(|token| token.as_str())
    }

    /// Clone the shared credential handle for a background task without
    /// copying the token bytes into another heap allocation.
    pub(crate) fn shared_token(&self) -> Option<Arc<SecretString>> {
        self.auth_token.clone()
    }

    pub(crate) fn shared_token_or_empty(&self) -> Arc<SecretString> {
        self.shared_token()
            .unwrap_or_else(|| Arc::new(SecretString::default()))
    }

    /// Clone this logical client while changing only its whole-request
    /// deadline. The HTTP pool and credential allocation remain shared.
    pub(crate) fn clone_with_timeout(&self, timeout: Duration) -> Self {
        let mut client = self.clone();
        client.request_timeout = timeout;
        client
    }

    /// Set the server URL.
    pub fn set_server(&mut self, url: String) {
        self.server_url = Some(url.trim_end_matches('/').to_string());
        self.cached_machine_id = None;
    }

    /// Get the current server URL.
    pub fn server_url(&self) -> Option<&str> {
        self.server_url.as_deref()
    }

    /// Set the client identifier.
    /// IMPORTANT: Must match the identifier the auth token was issued for.
    pub fn set_client_identifier(&mut self, identifier: String) {
        self.client_info.client_identifier = identifier;
    }

    /// Check if authenticated.
    pub fn is_authenticated(&self) -> bool {
        self.auth_token.is_some()
    }

    /// Check if server is set.
    pub fn has_server(&self) -> bool {
        self.server_url.is_some()
    }

    fn require_server(&self) -> Result<&str, ApiError> {
        self.server_url.as_deref().ok_or(ApiError::NoServerSelected)
    }

    fn require_token(&self) -> Result<&str, ApiError> {
        self.token().ok_or(ApiError::NotAuthenticated)
    }

    /// Build Plex identification headers (shared between API and streaming requests).
    /// Silently skips any header whose value contains invalid characters.
    fn plex_headers(&self) -> reqwest::header::HeaderMap {
        use reqwest::header::HeaderValue;

        let mut headers = reqwest::header::HeaderMap::new();

        if let Ok(v) = HeaderValue::from_str(&self.client_info.product) {
            headers.insert(HEADER_PLEX_PRODUCT, v);
        }
        if let Ok(v) = HeaderValue::from_str(&self.client_info.version) {
            headers.insert(HEADER_PLEX_VERSION, v);
        }
        if let Ok(v) = HeaderValue::from_str(&self.client_info.client_identifier) {
            headers.insert(HEADER_PLEX_CLIENT_ID, v);
        }
        if let Ok(v) = HeaderValue::from_str(&self.client_info.device_name) {
            headers.insert(HEADER_PLEX_DEVICE_NAME, v);
        }
        if let Ok(v) = HeaderValue::from_str(&self.client_info.platform) {
            headers.insert(HEADER_PLEX_PLATFORM, v);
        }
        if let Some(ref token) = self.auth_token {
            if let Ok(v) = HeaderValue::from_str(token.as_str()) {
                headers.insert(HEADER_PLEX_TOKEN, v);
            }
        }

        headers
    }

    /// Build headers for Plex API requests (JSON).
    ///
    /// Adds `Accept: application/json` on top of the shared Plex headers.
    fn build_headers(&self) -> Result<reqwest::header::HeaderMap, ApiError> {
        use reqwest::header::HeaderValue;

        let mut headers = self.plex_headers();
        headers.insert("Accept", HeaderValue::from_static("application/json"));
        Ok(headers)
    }

    /// Get a reference to the internal HTTP client.
    ///
    /// Audio downloads share the control/probe transport and its read-stall
    /// safeguards. Metadata GET deadlines are independent of this pool.
    pub fn http_client(&self) -> &reqwest::Client {
        &self.http
    }

    /// Build headers for audio streaming requests.
    ///
    /// Same Plex identification headers as API requests, but without
    /// `Accept: application/json` since the response is binary audio.
    pub fn stream_headers(&self) -> reqwest::header::HeaderMap {
        self.plex_headers()
    }

    /// Build URL from server base and path.
    fn build_url(&self, path: &str) -> Result<String, ApiError> {
        Ok(format!("{}{}", self.require_server()?, path))
    }

    /// Send an idempotent GET with a bounded retry policy. Plex occasionally
    /// responds with 429 while refreshing a library and can transiently return
    /// 5xx during server wake-up. Mutating POST/DELETE calls are deliberately
    /// excluded because replaying them may duplicate an operation.
    async fn send_get(&self, url: &str, headers: HeaderMap) -> Result<Response, ApiError> {
        for attempt in 0..MAX_GET_ATTEMPTS {
            match self
                .metadata_http
                .get(url)
                .headers(headers.clone())
                .timeout(self.request_timeout)
                .send()
                .await
            {
                Ok(response)
                    if (response.status() == reqwest::StatusCode::TOO_MANY_REQUESTS
                        || response.status().is_server_error())
                        && attempt + 1 < MAX_GET_ATTEMPTS =>
                {
                    let status = response.status();
                    let delay = retry_delay(&response, attempt);
                    tracing::warn!(
                        "Plex GET {} returned {}; retrying in {:?}",
                        redact_url(url),
                        status,
                        delay
                    );
                    tokio::time::sleep(delay).await;
                }
                Ok(response) => return Ok(response),
                // Retrying the same dead endpoint delays route failover. Return
                // transport failures immediately; the app-level recovery path
                // measures local, configured, public, and relay alternatives.
                Err(error) if error.is_connect() || error.is_timeout() => {
                    tracing::warn!(
                        "Plex GET {} failed (timeout={}, connect={}): {:?}",
                        redact_url(url),
                        error.is_timeout(),
                        error.is_connect(),
                        error
                    );
                    return Err(ApiError::Http(error));
                }
                Err(error) => return Err(ApiError::Http(error)),
            }
        }
        Err(ApiError::ServerError {
            status: 503,
            message: "GET retry policy exhausted".to_string(),
        })
    }

    /// GET variant for the one Plex endpoint that requires the token in its
    /// query string. `reqwest::Error` includes the request URL in its Display
    /// output, so this path converts transport errors before they can reach
    /// logs, UI state, or crash reports.
    async fn send_sensitive_get(
        &self,
        url: &str,
        headers: HeaderMap,
    ) -> Result<Response, ApiError> {
        for attempt in 0..MAX_GET_ATTEMPTS {
            match self
                .http
                .get(url)
                .headers(headers.clone())
                .timeout(self.request_timeout)
                .send()
                .await
            {
                Ok(response)
                    if (response.status() == reqwest::StatusCode::TOO_MANY_REQUESTS
                        || response.status().is_server_error())
                        && attempt + 1 < MAX_GET_ATTEMPTS =>
                {
                    let status = response.status();
                    let delay = retry_delay(&response, attempt);
                    tracing::warn!(
                        "Sensitive Plex GET {} returned {}; retrying in {:?}",
                        redact_url(url),
                        status,
                        delay
                    );
                    tokio::time::sleep(delay).await;
                }
                Ok(response) => return Ok(response),
                Err(error) if error.is_connect() || error.is_timeout() => {
                    let reason = if error.is_timeout() {
                        "request timed out"
                    } else {
                        "connection failed"
                    };
                    tracing::warn!("Sensitive Plex GET {} {}", redact_url(url), reason);
                    return Err(ApiError::Connection(reason.to_string()));
                }
                Err(_error) if attempt + 1 < MAX_GET_ATTEMPTS => {
                    let delay = Duration::from_secs(1_u64 << attempt);
                    tracing::warn!(
                        "Sensitive Plex GET {} request failed; retrying in {:?}",
                        redact_url(url),
                        delay
                    );
                    tokio::time::sleep(delay).await;
                }
                Err(error) => {
                    let reason = if error.is_timeout() {
                        "request timed out"
                    } else if error.is_connect() {
                        "connection failed"
                    } else {
                        "request failed"
                    };
                    return Err(ApiError::Connection(reason.to_string()));
                }
            }
        }
        Err(ApiError::Connection(
            "request retry policy exhausted".to_string(),
        ))
    }

    /// Make a GET request and return raw text (for debugging).
    pub async fn get_raw(&self, path: &str) -> Result<String, ApiError> {
        let url = self.build_url(path)?;
        let response = self.send_get(&url, self.build_headers()?).await?;

        if !response.status().is_success() {
            return Err(ApiError::ServerError {
                status: response.status().as_u16(),
                message: read_error_body(response).await,
            });
        }

        read_response_text_limited(response, MAX_METADATA_RESPONSE_BYTES).await
    }

    /// Make a GET request to the server.
    async fn get<T: serde::de::DeserializeOwned>(&self, path: &str) -> Result<T, ApiError> {
        let url = self.build_url(path)?;

        tracing::debug!("GET {}", redact_url(&url));

        let response = self
            .send_get(&url, self.build_headers()?)
            .await
            .map_err(|e| {
                tracing::error!(
                    "HTTP request failed for URL '{}' (timeout={}): {:?}",
                    redact_url(&url),
                    e.is_timeout(),
                    e
                );
                e
            })?;

        if !response.status().is_success() {
            return Err(ApiError::ServerError {
                status: response.status().as_u16(),
                message: read_error_body(response).await,
            });
        }

        let text = read_response_text_limited(response, MAX_METADATA_RESPONSE_BYTES).await?;
        tracing::trace!("Response: {}", truncate_to_boundary(&text, 1000));

        let data: T = serde_json::from_str(&text).map_err(|e| {
            tracing::error!(
                "JSON parse error: {} - Response: {}",
                e,
                truncate_to_boundary(&text, 500)
            );
            ApiError::ParseError(format!("JSON parse error: {}", e))
        })?;
        Ok(data)
    }

    // ========================================================================
    // Library Methods
    // ========================================================================

    /// Get all library sections.
    pub async fn get_libraries(&self) -> Result<Vec<Library>, ApiError> {
        let response: LibrarySectionsResponse = self.get(EP_LIBRARY_SECTIONS).await?;
        Ok(response.media_container.directory)
    }

    /// Get music libraries only.
    pub async fn get_music_libraries(&self) -> Result<Vec<Library>, ApiError> {
        let libraries = self.get_libraries().await?;
        Ok(libraries.into_iter().filter(|l| l.is_music()).collect())
    }

    // ========================================================================
    // Artist Methods
    // ========================================================================

    /// Get artists in a library section with pagination.
    pub async fn get_artists_page(
        &self,
        library_key: &str,
        offset: u32,
        limit: u32,
    ) -> Result<(Vec<Artist>, u32), ApiError> {
        let path = if limit > 0 {
            format!(
                "{}/{}/all?type={}&{}={}&{}={}",
                EP_LIBRARY_SECTIONS,
                library_key,
                TYPE_ARTIST,
                PARAM_CONTAINER_START,
                offset,
                PARAM_CONTAINER_SIZE,
                limit
            )
        } else {
            format!(
                "{}/{}/all?type={}",
                EP_LIBRARY_SECTIONS, library_key, TYPE_ARTIST
            )
        };
        let response: ArtistsResponse = self.get(&path).await?;
        let total = response
            .media_container
            .total_size
            .unwrap_or(response.media_container.size);
        Ok((response.media_container.metadata, total))
    }

    /// Get all artists in a library section (loads everything - can be slow).
    pub async fn get_artists(&self, library_key: &str) -> Result<Vec<Artist>, ApiError> {
        let (artists, _) = self.get_artists_page(library_key, 0, 0).await?;
        Ok(artists)
    }

    /// Get a specific artist by rating key.
    pub async fn get_artist(&self, rating_key: &str) -> Result<Artist, ApiError> {
        let path = format!("{}/{}", EP_LIBRARY_METADATA, rating_key);
        let response: ArtistsResponse = self.get(&path).await?;
        response
            .media_container
            .metadata
            .into_iter()
            .next()
            .ok_or_else(|| ApiError::ItemNotFound(rating_key.to_string()))
    }

    /// Get albums by an artist.
    pub async fn get_artist_albums(&self, artist_key: &str) -> Result<Vec<Album>, ApiError> {
        let path = format!("{}/{}/children", EP_LIBRARY_METADATA, artist_key);
        let response: AlbumsResponse = self.get(&path).await?;
        Ok(response.media_container.metadata)
    }

    /// Get all tracks by an artist (across all their albums).
    pub async fn get_artist_all_tracks(&self, artist_key: &str) -> Result<Vec<Track>, ApiError> {
        let path = format!("{}/{}/allLeaves", EP_LIBRARY_METADATA, artist_key);
        let response: TracksResponse = self.get(&path).await?;
        Ok(response.media_container.metadata)
    }

    /// Get related artists for an artist (via Plex's related hub).
    /// Uses the /library/metadata/{id}/related endpoint and extracts artist items.
    pub async fn get_related_artists(&self, artist_id: &str) -> Result<Vec<Artist>, ApiError> {
        let path = format!("{}/{}/related", EP_LIBRARY_METADATA, artist_id);

        let raw = self.get_raw(&path).await?;
        let response: serde_json::Value = serde_json::from_str(&raw)
            .map_err(|e| ApiError::ParseError(format!("Related artists parse error: {}", e)))?;

        let mut artists = Vec::new();

        if let Some(hubs) = response
            .get("MediaContainer")
            .and_then(|mc| mc.get("Hub"))
            .and_then(|h| h.as_array())
        {
            for hub in hubs {
                let hub_type = hub.get("type").and_then(|t| t.as_str()).unwrap_or("");
                if hub_type != "artist" {
                    continue;
                }
                if let Some(metadata) = hub.get("Metadata").and_then(|m| m.as_array()) {
                    for item in metadata {
                        if let (Some(key), Some(title)) = (
                            item.get("ratingKey").and_then(|k| k.as_str()),
                            item.get("title").and_then(|t| t.as_str()),
                        ) {
                            artists.push(Artist {
                                rating_key: key.to_string(),
                                title: title.to_string(),
                                thumb: item
                                    .get("thumb")
                                    .and_then(|t| t.as_str())
                                    .map(|s| s.to_string()),
                                ..Artist::default()
                            });
                        }
                    }
                }
            }
        }

        tracing::info!(
            "get_related_artists for {} found {} artists",
            artist_id,
            artists.len()
        );
        Ok(artists)
    }

    // ========================================================================
    // Album Methods
    // ========================================================================

    /// Get albums in a library section with pagination.
    pub async fn get_albums_page(
        &self,
        library_key: &str,
        offset: u32,
        limit: u32,
    ) -> Result<(Vec<Album>, u32), ApiError> {
        let path = if limit > 0 {
            format!(
                "{}/{}/all?type={}&{}={}&{}={}",
                EP_LIBRARY_SECTIONS,
                library_key,
                TYPE_ALBUM,
                PARAM_CONTAINER_START,
                offset,
                PARAM_CONTAINER_SIZE,
                limit
            )
        } else {
            format!(
                "{}/{}/all?type={}",
                EP_LIBRARY_SECTIONS, library_key, TYPE_ALBUM
            )
        };
        let response: AlbumsResponse = self.get(&path).await?;
        let total = response
            .media_container
            .total_size
            .unwrap_or(response.media_container.size);
        Ok((response.media_container.metadata, total))
    }

    /// Get all albums in a library section (loads everything - can be slow).
    pub async fn get_albums(&self, library_key: &str) -> Result<Vec<Album>, ApiError> {
        self.get_library_items(library_key, TYPE_ALBUM).await
    }

    /// Get recently added albums.
    pub async fn get_recently_added_albums(
        &self,
        library_key: &str,
        limit: u32,
    ) -> Result<Vec<Album>, ApiError> {
        let path = format!(
            "{}/{}/recentlyAdded?type={}&{}={}",
            EP_LIBRARY_SECTIONS, library_key, TYPE_ALBUM, PARAM_CONTAINER_SIZE, limit
        );
        let response: AlbumsResponse = self.get(&path).await?;
        Ok(response.media_container.metadata)
    }

    /// Get a specific album by rating key.
    pub async fn get_album(&self, rating_key: &str) -> Result<Album, ApiError> {
        let path = format!("{}/{}", EP_LIBRARY_METADATA, rating_key);
        let response: AlbumsResponse = self.get(&path).await?;
        response
            .media_container
            .metadata
            .into_iter()
            .next()
            .ok_or_else(|| ApiError::ItemNotFound(rating_key.to_string()))
    }

    /// Get tracks on an album.
    pub async fn get_album_tracks(&self, album_key: &str) -> Result<Vec<Track>, ApiError> {
        let path = format!("{}/{}/children", EP_LIBRARY_METADATA, album_key);
        let response: TracksResponse = self.get(&path).await?;
        // Log media parts info for debugging
        if let Some(track) = response.media_container.metadata.first() {
            tracing::debug!(
                "Album track '{}' media info: {} media items, has stream_part: {}",
                track.title,
                track.media.len(),
                track.stream_part().is_some()
            );
        }
        Ok(response.media_container.metadata)
    }

    // ========================================================================
    // Track Methods
    // ========================================================================

    /// Get all tracks in a library section.
    pub async fn get_tracks(&self, library_key: &str) -> Result<Vec<Track>, ApiError> {
        self.get_library_items(library_key, TYPE_TRACK).await
    }

    /// Aggregate bounded pages transactionally: a failed/truncated/repeated
    /// page must never replace a complete cached library with partial success.
    async fn get_library_items<T: serde::de::DeserializeOwned>(
        &self,
        library_key: &str,
        media_type: u8,
    ) -> Result<Vec<T>, ApiError> {
        #[derive(serde::Deserialize)]
        struct Page {
            #[serde(rename = "MediaContainer")]
            container: Items,
        }
        #[derive(serde::Deserialize)]
        struct Items {
            #[serde(rename = "totalSize")]
            total: Option<usize>,
            offset: Option<usize>,
            #[serde(rename = "Metadata", default)]
            items: Vec<serde_json::Value>,
        }
        const PAGE_SIZE: usize = 200;
        const MAX_ITEMS: usize = 1_000_000;
        let mut result = Vec::new();
        let mut seen = std::collections::HashSet::new();
        let mut bytes_read = 0usize;
        loop {
            let start = result.len();
            let path = format!("{EP_LIBRARY_SECTIONS}/{library_key}/all?type={media_type}&{PARAM_CONTAINER_START}={start}&{PARAM_CONTAINER_SIZE}={PAGE_SIZE}");
            let raw = self.get_raw(&path).await?;
            bytes_read = bytes_read.saturating_add(raw.len());
            if bytes_read > MAX_METADATA_RESPONSE_BYTES {
                return Err(ApiError::ResponseTooLarge {
                    limit_bytes: MAX_METADATA_RESPONSE_BYTES,
                });
            }
            let page: Page = serde_json::from_str(&raw)?;
            let page = page.container;
            if page.offset.is_some_and(|offset| offset != start)
                || page.total.is_some_and(|total| total > MAX_ITEMS)
                || start + page.items.len() > MAX_ITEMS
            {
                return Err(ApiError::ParseError(
                    "Invalid library pagination bounds".into(),
                ));
            }
            let count = page.items.len();
            for item in page.items {
                let key = item
                    .get("ratingKey")
                    .and_then(|value| value.as_str())
                    .ok_or_else(|| ApiError::ParseError("Library item has no ratingKey".into()))?;
                if !seen.insert(key.to_string()) {
                    return Err(ApiError::ParseError("Plex repeated a library item across pages; retry after the library scan finishes".into()));
                }
                result.push(serde_json::from_value(item)?);
            }
            if let Some(total) = page.total {
                if result.len() >= total {
                    return Ok(result);
                }
                if count == 0 {
                    return Err(ApiError::ParseError(
                        "Plex returned an incomplete library listing".into(),
                    ));
                }
            } else if count < PAGE_SIZE {
                return Ok(result);
            }
        }
    }

    /// Get a specific track by rating key.
    pub async fn get_track(&self, rating_key: &str) -> Result<Track, ApiError> {
        let path = format!("{}/{}", EP_LIBRARY_METADATA, rating_key);
        let response: TracksResponse = self.get(&path).await?;
        response
            .media_container
            .metadata
            .into_iter()
            .next()
            .ok_or_else(|| ApiError::ItemNotFound(rating_key.to_string()))
    }

    // ========================================================================
    // Playlist Methods
    // ========================================================================

    /// Get playlists, optionally filtered by library section.
    ///
    /// When `section_id` is provided, only playlists belonging to that library
    /// are returned (uses Plex `sectionID` filter). Without it, returns all
    /// audio playlists server-wide.
    ///
    /// Deduplicates smart playlists (like "❤️ Tracks", "Recently Added") which
    /// Plex creates once per music library with identical titles.
    pub async fn get_playlists(&self, section_id: Option<&str>) -> Result<Vec<Playlist>, ApiError> {
        let endpoint = match section_id {
            Some(id) => format!("{}&sectionID={}", EP_PLAYLISTS_AUDIO, id),
            None => EP_PLAYLISTS_AUDIO.to_string(),
        };
        let response: PlaylistsResponse = self.get(&endpoint).await?;
        let mut playlists = response.media_container.metadata;

        // Deduplicate smart playlists by title (Plex creates one per library)
        let mut seen_smart_titles = std::collections::HashSet::new();
        playlists.retain(|p| {
            if p.smart {
                // Keep only the first smart playlist with each title
                seen_smart_titles.insert(p.title.clone())
            } else {
                // Keep all user-created playlists
                true
            }
        });

        Ok(playlists)
    }

    /// Get tracks in a playlist.
    /// Fetch a single page of a playlist's items. Returns `(tracks,
    /// total_size)` where `total_size` is the server-reported total
    /// (independent of `limit`); the GUI uses this to drive
    /// scroll-triggered "load more" without needing to enumerate
    /// the entire playlist up front.
    pub async fn get_playlist_tracks_page(
        &self,
        playlist_key: &str,
        offset: u32,
        limit: u32,
    ) -> Result<(Vec<Track>, Option<u32>), ApiError> {
        let path = format!(
            "{}/{}/items?{}={}&{}={}",
            EP_PLAYLISTS, playlist_key, PARAM_CONTAINER_START, offset, PARAM_CONTAINER_SIZE, limit,
        );
        let response: TracksResponse = self.get(&path).await?;
        let total = response.media_container.total_size;
        Ok((response.media_container.metadata, total))
    }

    /// Fetch *every* track of a playlist by looping over
    /// `get_playlist_tracks_page` until a short page is returned.
    /// Used by background preload / cache paths and by the test TUI.
    /// The GUI's interactive path uses `get_playlist_tracks_page`
    /// directly so it can lazy-load on scroll.
    ///
    /// Smart playlists (e.g. "Recently Added") can resolve to many
    /// thousands of tracks server-side; if a later page fails after
    /// at least one succeeded we return what we have so callers
    /// still get a partial list.
    pub async fn get_playlist_tracks(&self, playlist_key: &str) -> Result<Vec<Track>, ApiError> {
        const PAGE_SIZE: u32 = 500;
        let mut all_tracks: Vec<Track> = Vec::new();
        let mut offset: u32 = 0;
        loop {
            match self
                .get_playlist_tracks_page(playlist_key, offset, PAGE_SIZE)
                .await
            {
                Ok((page, total)) => {
                    let page_len = page.len() as u32;
                    all_tracks.extend(page);
                    let done_by_total = total.is_some_and(|t| all_tracks.len() as u32 >= t);
                    let done_by_short = page_len < PAGE_SIZE;
                    if done_by_total || done_by_short {
                        break;
                    }
                    offset += page_len;
                }
                Err(e) if !all_tracks.is_empty() => {
                    tracing::warn!(
                        "get_playlist_tracks {}: page offset={} failed ({}); returning {} tracks collected so far",
                        playlist_key, offset, e, all_tracks.len(),
                    );
                    break;
                }
                Err(e) => return Err(e),
            }
        }
        Ok(all_tracks)
    }

    /// Create a new playlist from track keys.
    pub async fn create_playlist(
        &mut self,
        title: &str,
        track_keys: &[String],
        _library_key: &str,
    ) -> Result<(), ApiError> {
        let server = self.require_server()?.to_string();
        let machine_id = self.get_server_machine_id().await?;

        // Plex playlist URI: single server:// URI with comma-separated ratingKeys
        // Format: server://{machine_id}/com.plexapp.plugins.library/library/metadata/{key1},{key2},...
        let rating_keys = track_keys.join(",");
        let uri = format!(
            "server://{}/com.plexapp.plugins.library/library/metadata/{}",
            machine_id, rating_keys
        );

        // Auth travels in the X-Plex-Token header (build_headers below);
        // keeping it out of the URL keeps it out of the debug logs.
        let path = format!(
            "{}?type=audio&title={}&smart=0&uri={}",
            EP_PLAYLISTS,
            urlencoding::encode(title),
            urlencoding::encode(&uri)
        );

        let url = format!("{}{}", server, path);
        tracing::debug!("Creating playlist: POST {}", url);
        tracing::debug!("Playlist URI: {}", uri);

        let response = self
            .http
            .post(&url)
            .headers(self.build_headers()?)
            .timeout(self.request_timeout)
            .send()
            .await?;

        if !response.status().is_success() {
            let status = response.status().as_u16();
            let message = read_error_body(response).await;
            tracing::error!("Failed to create playlist: {} - {}", status, message);
            return Err(ApiError::ServerError { status, message });
        }

        Ok(())
    }

    /// Delete a playlist by its rating key.
    pub async fn delete_playlist(&self, rating_key: &str) -> Result<(), ApiError> {
        let url = self.build_url(&format!("{}/{}", EP_PLAYLISTS, rating_key))?;

        let response = self
            .http
            .delete(&url)
            .headers(self.build_headers()?)
            .timeout(self.request_timeout)
            .send()
            .await?;

        if !response.status().is_success() {
            let status = response.status().as_u16();
            let message = read_error_body(response).await;
            return Err(ApiError::ServerError { status, message });
        }

        Ok(())
    }

    // ========================================================================
    // Genre Methods
    // ========================================================================

    /// Get all genres for a music library.
    pub async fn get_genres(&self, library_key: &str) -> Result<Vec<Genre>, ApiError> {
        use super::models::GenresResponse;
        let path = format!(
            "{}/{}/genre?type={}",
            EP_LIBRARY_SECTIONS, library_key, TYPE_ALBUM
        );
        tracing::info!("get_genres: fetching from {}", path);
        let response: GenresResponse = self.get(&path).await?;
        tracing::info!(
            "get_genres: found {} genres",
            response.media_container.directory.len()
        );
        if let Some(first) = response.media_container.directory.first() {
            tracing::info!(
                "get_genres: first genre key='{}', title='{}'",
                first.key,
                first.title
            );
        }
        Ok(response.media_container.directory)
    }

    /// Get tracks in a specific genre.
    pub async fn get_genre_tracks(
        &self,
        library_key: &str,
        genre_filter: &str,
    ) -> Result<Vec<Track>, ApiError> {
        tracing::info!(
            "get_genre_tracks: library_key={}, genre_filter={}",
            library_key,
            genre_filter
        );

        if genre_filter.is_empty() {
            return Err(ApiError::ParseError("Empty genre filter".to_string()));
        }

        let path = if genre_filter.contains("genre=") {
            let genre_id = genre_filter
                .split("genre=")
                .nth(1)
                .and_then(|s| s.split('&').next())
                .unwrap_or(genre_filter);
            tracing::info!("get_genre_tracks: extracted genre_id={}", genre_id);
            format!(
                "{}/{}/all?type={}&genre={}",
                EP_LIBRARY_SECTIONS, library_key, TYPE_TRACK, genre_id
            )
        } else if genre_filter.starts_with('/') {
            if genre_filter.contains("type=") {
                genre_filter.to_string()
            } else if genre_filter.contains('?') {
                format!("{}&type={}", genre_filter, TYPE_TRACK)
            } else {
                format!("{}?type={}", genre_filter, TYPE_TRACK)
            }
        } else {
            let encoded = urlencoding::encode(genre_filter);
            tracing::info!(
                "get_genre_tracks: using genre_id={} (encoded={})",
                genre_filter,
                encoded
            );
            format!(
                "{}/{}/all?type={}&genre={}",
                EP_LIBRARY_SECTIONS, library_key, TYPE_TRACK, encoded
            )
        };

        tracing::info!("get_genre_tracks: constructed path={}", path);
        let response: TracksResponse = self.get(&path).await?;
        Ok(response.media_container.metadata)
    }

    /// Get albums in a specific genre.
    pub async fn get_genre_albums(
        &self,
        library_key: &str,
        genre_filter: &str,
    ) -> Result<Vec<Album>, ApiError> {
        tracing::info!(
            "get_genre_albums: library_key={}, genre_filter={}",
            library_key,
            genre_filter
        );

        if genre_filter.is_empty() {
            return Err(ApiError::ParseError("Empty genre filter".to_string()));
        }

        let genre_id = Self::extract_filter_id(genre_filter, "genre=");
        let encoded = urlencoding::encode(genre_id);
        let path = format!(
            "{}/{}/all?type={}&genre={}",
            EP_LIBRARY_SECTIONS, library_key, TYPE_ALBUM, encoded
        );
        tracing::info!("get_genre_albums: fetching from {}", path);
        let response: AlbumsResponse = self.get(&path).await?;
        Ok(response.media_container.metadata)
    }

    // ========================================================================
    // Artist Genre Methods
    // ========================================================================

    /// Get Plex genres at artist level.
    pub async fn get_artist_genres(&self, library_key: &str) -> Result<Vec<Genre>, ApiError> {
        use super::models::GenresResponse;
        let path = format!(
            "{}/{}/genre?type={}",
            EP_LIBRARY_SECTIONS, library_key, TYPE_ARTIST
        );
        tracing::info!("get_artist_genres: fetching from {}", path);
        let response: GenresResponse = self.get(&path).await?;
        tracing::info!(
            "get_artist_genres: found {} genres",
            response.media_container.directory.len()
        );
        Ok(response.media_container.directory)
    }

    /// Get albums in a specific artist genre (delegates to get_genre_albums).
    pub async fn get_artist_genre_albums(
        &self,
        library_key: &str,
        genre_filter: &str,
    ) -> Result<Vec<Album>, ApiError> {
        self.get_genre_albums(library_key, genre_filter).await
    }

    // ========================================================================
    // Album Genre Methods
    // ========================================================================

    /// Get Plex genres at album level.
    pub async fn get_album_genres(&self, library_key: &str) -> Result<Vec<Genre>, ApiError> {
        use super::models::GenresResponse;
        let path = format!(
            "{}/{}/genre?type={}",
            EP_LIBRARY_SECTIONS, library_key, TYPE_ALBUM
        );
        tracing::info!("get_album_genres: fetching from {}", path);
        let response: GenresResponse = self.get(&path).await?;
        tracing::info!(
            "get_album_genres: found {} genres",
            response.media_container.directory.len()
        );
        Ok(response.media_container.directory)
    }

    /// Get albums in a specific album genre (delegates to get_genre_albums).
    pub async fn get_album_genre_albums(
        &self,
        library_key: &str,
        genre_filter: &str,
    ) -> Result<Vec<Album>, ApiError> {
        self.get_genre_albums(library_key, genre_filter).await
    }

    // ========================================================================
    // Mood Methods
    // ========================================================================

    /// Get all moods for a music library.
    pub async fn get_moods(&self, library_key: &str) -> Result<Vec<Genre>, ApiError> {
        use super::models::GenresResponse;
        let path = format!(
            "{}/{}/mood?type={}",
            EP_LIBRARY_SECTIONS, library_key, TYPE_ALBUM
        );
        tracing::info!("get_moods: fetching from {}", path);
        let response: GenresResponse = self.get(&path).await?;
        tracing::info!(
            "get_moods: found {} moods",
            response.media_container.directory.len()
        );
        Ok(response.media_container.directory)
    }

    /// Get albums in a specific mood.
    pub async fn get_mood_albums(
        &self,
        library_key: &str,
        mood_filter: &str,
    ) -> Result<Vec<Album>, ApiError> {
        tracing::info!(
            "get_mood_albums: library_key={}, mood_filter={}",
            library_key,
            mood_filter
        );

        if mood_filter.is_empty() {
            return Err(ApiError::ParseError("Empty mood filter".to_string()));
        }

        let mood_id = Self::extract_filter_id(mood_filter, "mood=");
        let encoded = urlencoding::encode(mood_id);
        let path = format!(
            "{}/{}/all?type={}&mood={}",
            EP_LIBRARY_SECTIONS, library_key, TYPE_ALBUM, encoded
        );
        tracing::info!("get_mood_albums: fetching from {}", path);
        let response: AlbumsResponse = self.get(&path).await?;
        Ok(response.media_container.metadata)
    }

    // ========================================================================
    // Style Methods
    // ========================================================================

    /// Get all styles for a music library.
    pub async fn get_styles(&self, library_key: &str) -> Result<Vec<Genre>, ApiError> {
        use super::models::GenresResponse;
        let path = format!(
            "{}/{}/style?type={}",
            EP_LIBRARY_SECTIONS, library_key, TYPE_ALBUM
        );
        tracing::info!("get_styles: fetching from {}", path);
        let response: GenresResponse = self.get(&path).await?;
        tracing::info!(
            "get_styles: found {} styles",
            response.media_container.directory.len()
        );
        Ok(response.media_container.directory)
    }

    /// Get albums in a specific style.
    pub async fn get_style_albums(
        &self,
        library_key: &str,
        style_filter: &str,
    ) -> Result<Vec<Album>, ApiError> {
        tracing::info!(
            "get_style_albums: library_key={}, style_filter={}",
            library_key,
            style_filter
        );

        if style_filter.is_empty() {
            return Err(ApiError::ParseError("Empty style filter".to_string()));
        }

        let style_id = Self::extract_filter_id(style_filter, "style=");
        let encoded = urlencoding::encode(style_id);
        let path = format!(
            "{}/{}/all?type={}&style={}",
            EP_LIBRARY_SECTIONS, library_key, TYPE_ALBUM, encoded
        );
        tracing::info!("get_style_albums: fetching from {}", path);
        let response: AlbumsResponse = self.get(&path).await?;
        Ok(response.media_container.metadata)
    }

    // ========================================================================
    // Decade / Year / Collection / Country / Label / Format / Studio Methods
    //
    // All follow the same shape as get_moods / get_mood_albums:
    // tag list at /library/sections/{lib}/{tag}?type=9, drill-in at
    // /library/sections/{lib}/all?type=9&{tag}={id}. Plex returns the same
    // Directory shape for all of them, so we reuse the Genre model.
    // ========================================================================

    pub async fn get_decades(&self, library_key: &str) -> Result<Vec<Genre>, ApiError> {
        use super::models::GenresResponse;
        let path = format!(
            "{}/{}/decade?type={}",
            EP_LIBRARY_SECTIONS, library_key, TYPE_ALBUM
        );
        let response: GenresResponse = self.get(&path).await?;
        Ok(response
            .media_container
            .directory
            .into_iter()
            .filter(|item| is_plausible_decade(item.display_title()))
            .collect())
    }

    pub async fn get_decade_albums(
        &self,
        library_key: &str,
        decade_filter: &str,
    ) -> Result<Vec<Album>, ApiError> {
        if decade_filter.is_empty() {
            return Err(ApiError::ParseError("Empty decade filter".to_string()));
        }
        let decade_id = Self::extract_filter_id(decade_filter, "decade=");
        let encoded = urlencoding::encode(decade_id);
        let path = format!(
            "{}/{}/all?type={}&decade={}",
            EP_LIBRARY_SECTIONS, library_key, TYPE_ALBUM, encoded
        );
        let response: AlbumsResponse = self.get(&path).await?;
        Ok(response.media_container.metadata)
    }

    pub async fn get_years(&self, library_key: &str) -> Result<Vec<Genre>, ApiError> {
        use super::models::GenresResponse;
        let path = format!(
            "{}/{}/year?type={}",
            EP_LIBRARY_SECTIONS, library_key, TYPE_ALBUM
        );
        let response: GenresResponse = self.get(&path).await?;
        Ok(response
            .media_container
            .directory
            .into_iter()
            .filter(|item| parse_plausible_music_year(item.display_title()).is_some())
            .collect())
    }

    pub async fn get_year_albums(
        &self,
        library_key: &str,
        year_filter: &str,
    ) -> Result<Vec<Album>, ApiError> {
        if year_filter.is_empty() {
            return Err(ApiError::ParseError("Empty year filter".to_string()));
        }
        let year_id = Self::extract_filter_id(year_filter, "year=");
        let encoded = urlencoding::encode(year_id);
        let path = format!(
            "{}/{}/all?type={}&year={}",
            EP_LIBRARY_SECTIONS, library_key, TYPE_ALBUM, encoded
        );
        let response: AlbumsResponse = self.get(&path).await?;
        Ok(response.media_container.metadata)
    }

    pub async fn get_collections(&self, library_key: &str) -> Result<Vec<Genre>, ApiError> {
        use super::models::GenresResponse;
        let path = format!(
            "{}/{}/collection?type={}",
            EP_LIBRARY_SECTIONS, library_key, TYPE_ALBUM
        );
        let response: GenresResponse = self.get(&path).await?;
        Ok(response.media_container.directory)
    }

    pub async fn get_collection_albums(
        &self,
        library_key: &str,
        collection_filter: &str,
    ) -> Result<Vec<Album>, ApiError> {
        if collection_filter.is_empty() {
            return Err(ApiError::ParseError("Empty collection filter".to_string()));
        }
        let collection_id = Self::extract_filter_id(collection_filter, "collection=");
        let encoded = urlencoding::encode(collection_id);
        let path = format!(
            "{}/{}/all?type={}&collection={}",
            EP_LIBRARY_SECTIONS, library_key, TYPE_ALBUM, encoded
        );
        let response: AlbumsResponse = self.get(&path).await?;
        Ok(response.media_container.metadata)
    }

    pub async fn get_countries(&self, library_key: &str) -> Result<Vec<Genre>, ApiError> {
        use super::models::GenresResponse;
        let path = format!(
            "{}/{}/country?type={}",
            EP_LIBRARY_SECTIONS, library_key, TYPE_ALBUM
        );
        let response: GenresResponse = self.get(&path).await?;
        Ok(response.media_container.directory)
    }

    pub async fn get_country_albums(
        &self,
        library_key: &str,
        country_filter: &str,
    ) -> Result<Vec<Album>, ApiError> {
        if country_filter.is_empty() {
            return Err(ApiError::ParseError("Empty country filter".to_string()));
        }
        let country_id = Self::extract_filter_id(country_filter, "country=");
        let encoded = urlencoding::encode(country_id);
        let path = format!(
            "{}/{}/all?type={}&country={}",
            EP_LIBRARY_SECTIONS, library_key, TYPE_ALBUM, encoded
        );
        let response: AlbumsResponse = self.get(&path).await?;
        Ok(response.media_container.metadata)
    }

    pub async fn get_labels(&self, library_key: &str) -> Result<Vec<Genre>, ApiError> {
        use super::models::GenresResponse;
        let path = format!(
            "{}/{}/label?type={}",
            EP_LIBRARY_SECTIONS, library_key, TYPE_ALBUM
        );
        let response: GenresResponse = self.get(&path).await?;
        Ok(response.media_container.directory)
    }

    pub async fn get_label_albums(
        &self,
        library_key: &str,
        label_filter: &str,
    ) -> Result<Vec<Album>, ApiError> {
        if label_filter.is_empty() {
            return Err(ApiError::ParseError("Empty label filter".to_string()));
        }
        let label_id = Self::extract_filter_id(label_filter, "label=");
        let encoded = urlencoding::encode(label_id);
        let path = format!(
            "{}/{}/all?type={}&label={}",
            EP_LIBRARY_SECTIONS, library_key, TYPE_ALBUM, encoded
        );
        let response: AlbumsResponse = self.get(&path).await?;
        Ok(response.media_container.metadata)
    }

    pub async fn get_formats(&self, library_key: &str) -> Result<Vec<Genre>, ApiError> {
        use super::models::GenresResponse;
        let path = format!(
            "{}/{}/format?type={}",
            EP_LIBRARY_SECTIONS, library_key, TYPE_ALBUM
        );
        let response: GenresResponse = self.get(&path).await?;
        Ok(response.media_container.directory)
    }

    pub async fn get_format_albums(
        &self,
        library_key: &str,
        format_filter: &str,
    ) -> Result<Vec<Album>, ApiError> {
        if format_filter.is_empty() {
            return Err(ApiError::ParseError("Empty format filter".to_string()));
        }
        let format_id = Self::extract_filter_id(format_filter, "format=");
        let encoded = urlencoding::encode(format_id);
        let path = format!(
            "{}/{}/all?type={}&format={}",
            EP_LIBRARY_SECTIONS, library_key, TYPE_ALBUM, encoded
        );
        let response: AlbumsResponse = self.get(&path).await?;
        Ok(response.media_container.metadata)
    }

    pub async fn get_studios(&self, library_key: &str) -> Result<Vec<Genre>, ApiError> {
        use super::models::GenresResponse;
        let path = format!(
            "{}/{}/studio?type={}",
            EP_LIBRARY_SECTIONS, library_key, TYPE_ALBUM
        );
        let response: GenresResponse = self.get(&path).await?;
        Ok(response.media_container.directory)
    }

    pub async fn get_studio_albums(
        &self,
        library_key: &str,
        studio_filter: &str,
    ) -> Result<Vec<Album>, ApiError> {
        if studio_filter.is_empty() {
            return Err(ApiError::ParseError("Empty studio filter".to_string()));
        }
        let studio_id = Self::extract_filter_id(studio_filter, "studio=");
        let encoded = urlencoding::encode(studio_id);
        let path = format!(
            "{}/{}/all?type={}&studio={}",
            EP_LIBRARY_SECTIONS, library_key, TYPE_ALBUM, encoded
        );
        let response: AlbumsResponse = self.get(&path).await?;
        Ok(response.media_container.metadata)
    }

    // ========================================================================
    // Folder Browsing Methods
    // ========================================================================

    /// Get root folders for a library section.
    pub async fn get_library_folders(&self, library_key: &str) -> Result<FolderResponse, ApiError> {
        let path = format!("{}/{}/folder", EP_LIBRARY_SECTIONS, library_key);
        self.get(&path).await
    }

    /// Get contents of a specific folder.
    pub async fn get_folder_contents(&self, folder_key: &str) -> Result<FolderResponse, ApiError> {
        self.get(folder_key).await
    }

    /// Convert folder metadata into sorted tracks for playback.
    fn folder_response_to_tracks(response: FolderResponse) -> Vec<Track> {
        let mut tracks: Vec<Track> = response
            .media_container
            .metadata
            .into_iter()
            .filter_map(Self::folder_meta_to_track)
            .collect();
        tracks.sort_by(|a, b| a.title.cmp(&b.title));
        tracks
    }

    /// Convert a single folder metadata entry to a Track.
    fn folder_meta_to_track(meta: FolderMetadata) -> Option<Track> {
        let rating_key = meta.rating_key?;
        Some(Track {
            view_count: None,
            parent_index: None,
            origin: Default::default(),
            rating_key,
            key: meta.key,
            title: meta.title,
            duration: meta.duration,
            parent_title: meta.parent_title,
            grandparent_title: meta.grandparent_title,
            index: meta.index,
            year: None,
            parent_year: None,
            parent_rating_key: meta.parent_rating_key,
            grandparent_rating_key: meta.grandparent_rating_key,
            thumb: None,
            parent_thumb: None,
            grandparent_thumb: None,
            original_title: None,
            media: meta
                .media
                .into_iter()
                .map(|m| Media {
                    id: m.id,
                    duration: m.duration,
                    bitrate: m.bitrate,
                    audio_channels: m.audio_channels.map(|c| c as u8),
                    audio_codec: m.audio_codec,
                    container: m.container,
                    part: m
                        .parts
                        .into_iter()
                        .map(|p| MediaPart {
                            id: p.id,
                            key: p.key.unwrap_or_default(),
                            duration: p.duration,
                            file: p.file,
                            size: p.size,
                            container: p.container,
                        })
                        .collect(),
                })
                .collect(),
        })
    }

    /// Get all tracks in a folder, suitable for playback.
    pub async fn get_folder_tracks(&self, folder_key: &str) -> Result<Vec<Track>, ApiError> {
        let response = self.get_folder_contents(folder_key).await?;
        Ok(Self::folder_response_to_tracks(response))
    }

    /// Get all tracks at the library root level, suitable for playback.
    ///
    /// Similar to `get_folder_tracks` but for the library root folder.
    pub async fn get_library_root_tracks(&self, library_key: &str) -> Result<Vec<Track>, ApiError> {
        let response = self.get_library_folders(library_key).await?;
        Ok(Self::folder_response_to_tracks(response))
    }

    // ========================================================================
    // Hub/Discovery Methods
    // ========================================================================

    /// Get home hubs (Mixes For You, Recently Played, etc.).
    pub async fn get_home_hubs(&self) -> Result<Vec<Hub>, ApiError> {
        let response: HubsResponse = self.get(EP_HUBS).await?;
        Ok(response.media_container.hub)
    }

    /// Get music-specific hubs for a library.
    pub async fn get_music_hubs(&self, library_key: &str) -> Result<Vec<Hub>, ApiError> {
        let path = format!("{}/sections/{}", EP_HUBS, library_key);
        let response: HubsResponse = self.get(&path).await?;
        Ok(response.media_container.hub)
    }

    /// Get children/sub-stations for a station category.
    pub async fn get_station_children(&self, station_key: &str) -> Result<Vec<Station>, ApiError> {
        station_library_key(station_key)?;
        tracing::debug!("Getting station children for key: {}", station_key);

        if station_key.contains("/mood")
            || station_key.contains("/style")
            || station_key.contains("/decade")
        {
            return self.get_category_items(station_key).await;
        }

        let raw = self.get_raw(station_key).await?;
        tracing::debug!(
            "Station children raw response (first 1000 chars): {}",
            truncate_to_boundary(&raw, 1000)
        );

        let response: StationsResponse = serde_json::from_str(&raw).map_err(|e| {
            tracing::error!(
                "Station children parse error: {} - Response: {}",
                e,
                truncate_to_boundary(&raw, 500)
            );
            ApiError::ParseError(format!("Station children parse error: {}", e))
        })?;

        for hub in &response.media_container.hub {
            let stations = hub.stations();
            if !stations.is_empty() {
                tracing::info!("Found {} child stations", stations.len());
                return Ok(stations);
            }
        }

        tracing::warn!("No child stations found in hub response");
        Ok(vec![])
    }

    /// Get category items (moods, styles, decades) and convert to Station objects.
    async fn get_category_items(&self, category_path: &str) -> Result<Vec<Station>, ApiError> {
        tracing::debug!("Getting category items for: {}", category_path);

        let raw = self.get_raw(category_path).await?;
        tracing::debug!(
            "Category response (first 500 chars): {}",
            truncate_to_boundary(&raw, 500)
        );

        let response: serde_json::Value = serde_json::from_str(&raw)
            .map_err(|e| ApiError::ParseError(format!("Category parse error: {}", e)))?;

        let mut stations = Vec::new();
        let library_key = station_library_key(category_path)?;
        let container = response
            .get("MediaContainer")
            .and_then(|value| value.as_object())
            .ok_or_else(|| {
                ApiError::ParseError("Station choices response has no MediaContainer".into())
            })?;
        if container
            .get("Directory")
            .is_some_and(|value| !value.is_array())
        {
            return Err(ApiError::ParseError(
                "Station choices Directory is not a list".into(),
            ));
        }

        if let Some(directories) = response
            .get("MediaContainer")
            .and_then(|mc| mc.get("Directory"))
            .and_then(|d| d.as_array())
        {
            tracing::info!("Found {} category items", directories.len());

            for dir in directories {
                let title = dir
                    .get("title")
                    .and_then(|t| t.as_str())
                    .unwrap_or("Unknown");
                if category_path.contains("/decade") && !is_plausible_decade(title) {
                    tracing::warn!("Ignoring implausible Plex decade metadata: {}", title);
                    continue;
                }
                // Get the numeric key (e.g., "349383" for style, "209005" for mood)
                // This is required for filtering - Plex API uses numeric IDs, not names
                let numeric_key = dir.get("key").and_then(|k| k.as_str()).unwrap_or("");

                let (station_type, identifier) = if category_path.contains("/mood") {
                    ("mood", "mood")
                } else if category_path.contains("/style") {
                    ("style", "style")
                } else if category_path.contains("/decade") {
                    ("decade", "decade")
                } else {
                    ("category", "other")
                };

                // Include both numeric ID (for API) and title (for display)
                // Format: /library/sections/{lib}/stations/{type}?id={key}&title={title}
                let playable_key = format!(
                    "{}/{}/stations/{}?id={}&title={}",
                    EP_LIBRARY_SECTIONS,
                    library_key,
                    identifier,
                    numeric_key,
                    urlencoding::encode(title)
                );

                stations.push(Station {
                    key: playable_key,
                    title: title.to_string(),
                    station_type: station_type.to_string(),
                    identifier: Some(identifier.to_string()),
                    thumb: dir
                        .get("thumb")
                        .and_then(|t| t.as_str())
                        .map(|s| s.to_string()),
                    art: None,
                    description: None,
                });
            }
        }

        tracing::info!("Converted {} category items to stations", stations.len());
        Ok(stations)
    }

    /// Get radio stations for a music library.
    /// Returns the standard Plex station types, adding the date-sensitive
    /// On This Day station only when its hub currently contains albums.
    pub async fn get_stations(&self, library_key: &str) -> Result<Vec<Station>, ApiError> {
        // Plex has 7 persistent station types plus the date-sensitive On This Day.
        // Rather than parse the hubs API (which returns expanded mood/style lists),
        // we construct these directly.
        let mut stations = vec![
            Station {
                key: format!("{}/{}/stations/library", EP_LIBRARY_SECTIONS, library_key),
                title: "Library Radio".to_string(),
                station_type: "station".to_string(),
                identifier: Some("library".to_string()),
                thumb: None,
                art: None,
                description: Some("Random tracks from your library".to_string()),
            },
            Station {
                key: format!("{}/{}/stations/deepCuts", EP_LIBRARY_SECTIONS, library_key),
                title: "Deep Cuts Radio".to_string(),
                station_type: "station".to_string(),
                identifier: Some("deepCuts".to_string()),
                thumb: None,
                art: None,
                description: Some("Less popular tracks from your library".to_string()),
            },
            Station {
                key: format!(
                    "{}/{}/stations/timeTravel",
                    EP_LIBRARY_SECTIONS, library_key
                ),
                title: "Time Travel Radio".to_string(),
                station_type: "station".to_string(),
                identifier: Some("timeTravel".to_string()),
                thumb: None,
                art: None,
                description: Some("Chronological journey through your library".to_string()),
            },
            Station {
                key: format!(
                    "{}/{}/stations/randomAlbum",
                    EP_LIBRARY_SECTIONS, library_key
                ),
                title: "Random Album Radio".to_string(),
                station_type: "station".to_string(),
                identifier: Some("randomAlbum".to_string()),
                thumb: None,
                art: None,
                description: Some("Play a random album from your library".to_string()),
            },
            Station {
                key: format!("{}/{}/mood", EP_LIBRARY_SECTIONS, library_key),
                title: "Mood Radio".to_string(),
                station_type: "station.category".to_string(),
                identifier: Some("mood".to_string()),
                thumb: None,
                art: None,
                description: Some("Play music by mood".to_string()),
            },
            Station {
                key: format!("{}/{}/style", EP_LIBRARY_SECTIONS, library_key),
                title: "Style Radio".to_string(),
                station_type: "station.category".to_string(),
                identifier: Some("style".to_string()),
                thumb: None,
                art: None,
                description: Some("Play music by style".to_string()),
            },
            Station {
                key: format!("{}/{}/decade", EP_LIBRARY_SECTIONS, library_key),
                title: "Decade Radio".to_string(),
                station_type: "station.category".to_string(),
                identifier: Some("decade".to_string()),
                thumb: None,
                art: None,
                description: Some("Play music from a specific decade".to_string()),
            },
        ];

        // Plex only exposes this hub on dates represented in the library.
        // Keeping the station list conditional avoids presenting a control
        // that is guaranteed to return an empty queue most days.
        match self.get_music_hubs(library_key).await {
            Ok(hubs)
                if hubs.iter().any(|hub| {
                    hub.hub_identifier == "music.onthisday" && !hub.metadata.is_empty()
                }) =>
            {
                stations.push(Station {
                    key: format!("{}/{}/stations/onThisDay", EP_LIBRARY_SECTIONS, library_key),
                    title: "On This Day".to_string(),
                    station_type: "station".to_string(),
                    identifier: Some("onThisDay".to_string()),
                    thumb: None,
                    art: None,
                    description: Some("Albums released on today's date".to_string()),
                })
            }
            Ok(_) => tracing::debug!(
                "On This Day is not available for library {} today",
                library_key
            ),
            Err(error) if error.is_connection_error() => return Err(error),
            Err(error) => tracing::warn!(
                "Could not determine On This Day availability for library {}: {}",
                library_key,
                error
            ),
        }

        tracing::debug!("Returning {} station types", stations.len());
        Ok(stations)
    }

    // =============================================================================
    // STATION QUEUE IMPLEMENTATION GUIDELINES
    // =============================================================================
    //
    // Station queue creation can be called from the main event loop, so it MUST NOT
    // block for extended periods. Follow these rules:
    //
    // 1. PREFER PlayQueue API: Use create_station_queue_via_playqueue() when possible.
    //    This lets the Plex server build the queue, which is much faster.
    //
    // 2. LIMIT NETWORK CALLS: If manual fetching is required, limit to MAX 10 calls.
    //    Example: 3 decades × 2 albums × 1 track fetch = 7 calls max.
    //
    // 3. TIMEOUT PROTECTION: Event loop wraps station calls with 30-second timeout.
    //    Don't rely on this - design for <10 second completion.
    //
    // 4. FAIL GRACEFULLY: If a station partially fails, return what you have rather
    //    than failing entirely. Some tracks > no tracks.
    //
    // 5. LOG APPROPRIATELY: Use tracing::info for success, tracing::warn for issues
    //    users should know about, tracing::debug for internal details.
    //
    // These requests run in supervised background tasks, with a total operation
    // timeout. Bounded request counts also limit server load during failures.
    // =============================================================================

    /// Use the same request for initial radio tracks and subsequent refills.
    pub async fn create_radio_queue(
        &mut self,
        source: &RadioSource,
    ) -> Result<Vec<Track>, ApiError> {
        match source {
            RadioSource::Artist(key) => self.create_radio_from_metadata(key).await,
            RadioSource::Sonic(key) => self.get_similar_tracks(key, 100).await,
            RadioSource::Station(key) => self.create_station_queue(key).await,
        }
    }

    /// Create a play queue from a station.
    pub async fn create_station_queue(
        &mut self,
        station_key: &str,
    ) -> Result<Vec<Track>, ApiError> {
        tracing::debug!("Creating station queue for key: {}", station_key);

        let (library_key, station_type, query) = station_parts(station_key)?;
        if let Some(query) = query {
            let filters: Vec<_> = query
                .split('&')
                .filter_map(|part| part.split_once('='))
                .collect();
            if filters
                .iter()
                .any(|(name, _)| *name == "id" || *name == "title")
            {
                if !matches!(station_type, "mood" | "style" | "decade")
                    || !filters.iter().any(|(name, value)| {
                        (*name == "id" || *name == "title") && !value.is_empty()
                    })
                {
                    return Err(ApiError::ParseError(
                        "Invalid station filter; refresh the station list".into(),
                    ));
                }
                return self.create_filtered_station_queue(station_key).await;
            }
        }

        tracing::debug!("Station type: {}, library: {}", station_type, library_key);

        // Random Album Radio does not need Plex's sonic radio engine. Some
        // servers accept its PlayQueue request but return a successful empty
        // queue, so build it directly from ordinary library metadata instead.
        if station_type == "randomAlbum" {
            return self.create_random_album_queue(library_key).await;
        }

        // Try to create tracks based on station type.
        // For library/deepCuts, try PlayQueue API first for server-curated
        // results, then fall back to direct queries if PlayQueue fails or
        // returns empty.
        match station_type {
            "library" | "deepCuts" => {
                // Try PlayQueue API first (server has access to popularity, ratings, play history)
                match self.create_station_queue_via_playqueue(station_key).await {
                    Ok(tracks) if !tracks.is_empty() => {
                        tracing::info!(
                            "{} radio via PlayQueue: {} tracks",
                            station_type,
                            tracks.len()
                        );
                        return Ok(tracks);
                    }
                    Ok(_) => tracing::debug!(
                        "{} PlayQueue returned no tracks, trying fallback",
                        station_type
                    ),
                    Err(e) => tracing::debug!(
                        "{} PlayQueue failed ({}), trying fallback",
                        station_type,
                        e
                    ),
                }

                // Fallback to direct queries
                match station_type {
                    "library" => {
                        let path = format!(
                            "{}/{}/all?type={}&sort=random&limit={}",
                            EP_LIBRARY_SECTIONS, library_key, TYPE_TRACK, DEFAULT_SEARCH_LIMIT
                        );
                        let response: TracksResponse = self.get(&path).await?;
                        tracing::info!(
                            "Library radio fallback: {} tracks",
                            response.media_container.metadata.len()
                        );
                        Ok(response.media_container.metadata)
                    }
                    "deepCuts" => {
                        let path = format!(
                            "{}/{}/all?type={}&sort=viewCount:asc,random&limit={}",
                            EP_LIBRARY_SECTIONS, library_key, TYPE_TRACK, DEFAULT_SEARCH_LIMIT
                        );
                        let response: TracksResponse = self.get(&path).await?;
                        tracing::info!(
                            "Deep cuts radio fallback: {} tracks",
                            response.media_container.metadata.len()
                        );
                        Ok(response.media_container.metadata)
                    }
                    _ => unreachable!(),
                }
            }
            "timeTravel" => {
                // Time Travel Radio: chronological journey through your library's history
                return self.create_time_travel_queue(library_key).await;
            }
            "onThisDay" => {
                // On This Day: albums released on today's date
                return self.create_on_this_day_queue(library_key).await;
            }
            _ => {
                // For other station types, try the playQueue API as fallback
                self.create_station_queue_via_playqueue(station_key).await
            }
        }
    }

    /// Build Random Album Radio without Plex's sonic PlayQueue endpoint.
    ///
    /// A server can contain stale album rows whose children have disappeared.
    /// Ask for a small randomized candidate set and choose the first playable
    /// album. If the album query itself is unexpectedly empty, use a random
    /// track to identify an album before falling back to that track alone.
    /// The worst case is eight requests, within the station-call budget above.
    async fn create_random_album_queue(&self, library_key: &str) -> Result<Vec<Track>, ApiError> {
        const ALBUM_CANDIDATE_COUNT: usize = 5;

        let albums_path = format!(
            "{}/{}/all?type={}&sort=random&limit={}",
            EP_LIBRARY_SECTIONS, library_key, TYPE_ALBUM, ALBUM_CANDIDATE_COUNT
        );
        let albums_resp: AlbumsResponse = self.get(&albums_path).await?;

        for album in albums_resp
            .media_container
            .metadata
            .iter()
            .take(ALBUM_CANDIDATE_COUNT)
        {
            if album.rating_key.is_empty() {
                tracing::warn!("Random album candidate had no rating key: {}", album.title);
                continue;
            }

            let tracks_path = format!("{}/{}/children", EP_LIBRARY_METADATA, album.rating_key);
            match self.get::<TracksResponse>(&tracks_path).await {
                Ok(response) if !response.media_container.metadata.is_empty() => {
                    tracing::info!(
                        "Random Album Radio: {} - {} tracks",
                        album.title,
                        response.media_container.metadata.len()
                    );
                    return Ok(response.media_container.metadata);
                }
                Ok(_) => {
                    tracing::warn!(
                        "Skipping empty random album candidate: {} ({})",
                        album.title,
                        album.rating_key
                    );
                }
                Err(error) => {
                    tracing::warn!(
                        "Skipping unavailable random album candidate {} ({}): {}",
                        album.title,
                        album.rating_key,
                        error
                    );
                }
            }
        }

        // A random track provides a second route to a playable album when an
        // incomplete library scan makes the album-level query return nothing.
        let track_path = format!(
            "{}/{}/all?type={}&sort=random&limit=1",
            EP_LIBRARY_SECTIONS, library_key, TYPE_TRACK
        );
        let mut track_response: TracksResponse = self.get(&track_path).await?;
        let Some(seed) = track_response.media_container.metadata.first() else {
            tracing::warn!("Random Album Radio found no albums or tracks in library {library_key}");
            return Ok(Vec::new());
        };

        if let Some(album_key) = seed
            .parent_rating_key
            .as_deref()
            .filter(|key| !key.is_empty())
        {
            let tracks_path = format!("{}/{}/children", EP_LIBRARY_METADATA, album_key);
            match self.get::<TracksResponse>(&tracks_path).await {
                Ok(response) if !response.media_container.metadata.is_empty() => {
                    tracing::info!(
                        "Random Album Radio recovered album {} from random track - {} tracks",
                        album_key,
                        response.media_container.metadata.len()
                    );
                    return Ok(response.media_container.metadata);
                }
                Ok(_) => tracing::warn!(
                    "Random Album Radio track seed referenced empty album {}",
                    album_key
                ),
                Err(error) => tracing::warn!(
                    "Random Album Radio could not load track seed album {}: {}",
                    album_key,
                    error
                ),
            }
        }

        tracing::warn!("Random Album Radio falling back to one playable library track");
        Ok(std::mem::take(&mut track_response.media_container.metadata))
    }

    /// Create station queue using the playQueue API (may not work on all servers).
    async fn create_station_queue_via_playqueue(
        &mut self,
        station_key: &str,
    ) -> Result<Vec<Track>, ApiError> {
        let server = self.require_server()?.to_string();

        let machine_id = self.get_server_machine_id().await?;
        tracing::debug!("Server machine ID: {}", machine_id);

        let uri = format!(
            "server://{}/com.plexapp.plugins.library{}",
            machine_id, station_key
        );

        let path = format!(
            "{}?type=audio&uri={}&shuffle=0&repeat=0&continuous=1&includeChapters=1&includeMarkers=1&includeRelated=1",
            EP_PLAY_QUEUES,
            urlencoding::encode(&uri)
        );

        tracing::debug!("PlayQueue request path: {}", path);

        // Auth travels in the X-Plex-Token header (build_headers below).
        let url = format!("{}{}", server, path);

        let response = self
            .http
            .post(&url)
            .headers(self.build_headers()?)
            .timeout(self.request_timeout.min(PLAY_QUEUE_TIMEOUT))
            .send()
            .await?;

        if !response.status().is_success() {
            let status = response.status().as_u16();
            let message = read_error_body(response).await;
            tracing::error!("PlayQueue creation failed: {} - {}", status, message);
            return Err(ApiError::ServerError { status, message });
        }

        let text = read_response_text_limited(response, MAX_SMALL_RESPONSE_BYTES).await?;
        tracing::debug!(
            "PlayQueue response (first 500 chars): {}",
            truncate_to_boundary(&text, 500)
        );

        let queue: PlayQueueResponse = serde_json::from_str(&text).map_err(|e| {
            tracing::error!(
                "PlayQueue parse error: {} - Response: {}",
                e,
                truncate_to_boundary(&text, 500)
            );
            ApiError::ParseError(format!("PlayQueue parse error: {}", e))
        })?;

        tracing::info!(
            "Station queue created with {} tracks",
            queue.media_container.metadata.len()
        );
        Ok(queue.media_container.metadata)
    }

    /// Create artist radio, using Plex's server-curated queue when available
    /// and the artist's own shuffled tracks as a resilient fallback.
    pub async fn create_radio_from_metadata(
        &mut self,
        rating_key: &str,
    ) -> Result<Vec<Track>, ApiError> {
        let radio_result = self
            .create_radio_from_metadata_via_playqueue(rating_key)
            .await;
        if matches!(&radio_result, Ok(tracks) if !tracks.is_empty()) {
            return radio_result;
        }

        match self.get_artist_all_tracks(rating_key).await {
            Ok(mut tracks) if !tracks.is_empty() => {
                use rand::seq::SliceRandom;
                tracks.shuffle(&mut rand::rng());
                tracing::info!(
                    "Artist radio fallback for {}: using {} shuffled artist tracks",
                    rating_key,
                    tracks.len()
                );
                Ok(tracks)
            }
            Ok(_) => radio_result,
            Err(fallback_error) => {
                if let Err(primary_error) = radio_result {
                    tracing::warn!(
                        "Artist radio PlayQueue failed for {} ({}); direct fallback also failed ({})",
                        rating_key,
                        primary_error,
                        fallback_error
                    );
                }
                Err(fallback_error)
            }
        }
    }

    /// Use the Plex playQueue API, which incorporates server-side similarity,
    /// popularity, ratings, listening history, and sonic analysis.
    async fn create_radio_from_metadata_via_playqueue(
        &mut self,
        rating_key: &str,
    ) -> Result<Vec<Track>, ApiError> {
        let server = self.require_server()?.to_string();
        let machine_id = self.get_server_machine_id().await?;

        let uri = format!(
            "server://{}/com.plexapp.plugins.library/library/metadata/{}",
            machine_id, rating_key
        );

        let path = format!(
            "{}?type=audio&uri={}&shuffle=1&repeat=0&continuous=1&includeChapters=1&includeMarkers=1&includeRelated=1",
            EP_PLAY_QUEUES,
            urlencoding::encode(&uri)
        );

        tracing::debug!("Radio from metadata request: {}", path);

        // Auth travels in the X-Plex-Token header (build_headers below).
        let url = format!("{}{}", server, path);

        let response = self
            .http
            .post(&url)
            .headers(self.build_headers()?)
            .timeout(self.request_timeout.min(PLAY_QUEUE_TIMEOUT))
            .send()
            .await?;

        if !response.status().is_success() {
            let status = response.status().as_u16();
            let message = read_error_body(response).await;
            tracing::error!("Radio PlayQueue creation failed: {} - {}", status, message);
            return Err(ApiError::ServerError { status, message });
        }

        let text = read_response_text_limited(response, MAX_SMALL_RESPONSE_BYTES).await?;
        tracing::debug!(
            "Radio PlayQueue response (first 500 chars): {}",
            truncate_to_boundary(&text, 500)
        );

        let queue: PlayQueueResponse = serde_json::from_str(&text).map_err(|e| {
            tracing::error!(
                "Radio PlayQueue parse error: {} - Response: {}",
                e,
                truncate_to_boundary(&text, 500)
            );
            ApiError::ParseError(format!("Radio PlayQueue parse error: {}", e))
        })?;

        tracing::info!(
            "Radio from metadata created with {} tracks",
            queue.media_container.metadata.len()
        );
        Ok(queue.media_container.metadata)
    }

    /// Create a filtered play queue for mood/style/decade stations.
    /// Uses the playQueue API which is what Plexamp uses for these stations.
    async fn create_filtered_station_queue(
        &mut self,
        station_key: &str,
    ) -> Result<Vec<Track>, ApiError> {
        tracing::info!("Creating filtered station queue for: {}", station_key);

        // Try playQueue API first (this is what Plexamp uses)
        match self.create_station_queue_via_playqueue(station_key).await {
            Ok(tracks) if !tracks.is_empty() => {
                tracing::info!("PlayQueue returned {} tracks", tracks.len());
                return Ok(tracks);
            }
            Ok(_) => {
                tracing::debug!("PlayQueue returned no tracks, trying direct query");
            }
            Err(e) => {
                tracing::debug!("PlayQueue failed ({}), trying direct query", e);
            }
        }

        // Fallback: try direct query with filter
        // Parse station key format: /library/sections/{lib}/stations/{type}?id={key}&title={title}
        let parts: Vec<&str> = station_key.split('?').collect();
        let path_part = parts.first().unwrap_or(&"");
        let query_part = parts.get(1).unwrap_or(&"");

        let library_key = station_library_key(path_part)?;

        let is_decade = path_part.contains("/decade");
        let filter_type = if path_part.contains("/mood") {
            "mood"
        } else if path_part.contains("/style") {
            "style"
        } else {
            "decade"
        };

        // Parse query parameters: id={key}&title={title}
        let mut numeric_id = String::new();
        let mut title = String::new();
        for param in query_part.split('&') {
            if let Some(id) = param.strip_prefix("id=") {
                numeric_id = id.to_string();
            } else if let Some(t) = param.strip_prefix("title=") {
                title = urlencoding::decode(t).unwrap_or_default().to_string();
            }
        }

        tracing::info!(
            "Fallback: Creating {} radio for '{}' (id={}) in library {}",
            filter_type,
            title,
            numeric_id,
            library_key
        );

        // Use numeric ID for filtering - Plex API requires numeric IDs for style/mood
        // For decade, use the numeric value from the ID (it's already numeric like "1980")
        let filter_value = if !numeric_id.is_empty() {
            numeric_id.clone()
        } else if is_decade {
            // Legacy fallback: extract numeric from title like "1980s" -> "1980"
            title.chars().filter(|c| c.is_ascii_digit()).collect()
        } else {
            // Legacy fallback: use title (may not work for styles)
            title.clone()
        };

        // Style and decade metadata is attached to albums, not tracks directly.
        // We need to get albums first, then get their tracks.
        if filter_type == "style" || filter_type == "decade" {
            return self
                .create_album_filter_radio_tracks(library_key, filter_type, &filter_value)
                .await;
        }

        // Mood filters work directly on tracks
        let filter_path = format!(
            "{}/{}/all?type={}&{}={}&sort=random&limit={}",
            EP_LIBRARY_SECTIONS,
            library_key,
            TYPE_TRACK,
            filter_type,
            urlencoding::encode(&filter_value),
            DEFAULT_SEARCH_LIMIT
        );

        tracing::debug!("Filtered tracks path: {}", filter_path);

        let response: TracksResponse = self.get(&filter_path).await?;

        tracing::info!(
            "Filtered station returned {} tracks",
            response.media_container.metadata.len()
        );
        Ok(response.media_container.metadata)
    }

    /// Create radio tracks by first getting albums matching a filter, then getting their tracks.
    /// Style and decade metadata is attached to albums, not tracks, so we need this approach.
    pub async fn create_album_filter_radio_tracks(
        &self,
        library_key: &str,
        filter_type: &str,
        filter_value: &str,
    ) -> Result<Vec<Track>, ApiError> {
        // Get random albums matching this filter (style or decade)
        let albums_path = format!(
            "{}/{}/all?type={}&{}={}&sort=random&limit=10",
            EP_LIBRARY_SECTIONS, library_key, TYPE_ALBUM, filter_type, filter_value
        );

        tracing::debug!("{} radio albums path: {}", filter_type, albums_path);

        let albums_resp: AlbumsResponse = self.get(&albums_path).await?;

        if albums_resp.media_container.metadata.is_empty() {
            tracing::info!(
                "No albums found for {} filter {}",
                filter_type,
                filter_value
            );
            return Ok(vec![]);
        }

        tracing::debug!(
            "Found {} albums for {} filter",
            albums_resp.media_container.metadata.len(),
            filter_type
        );

        // Continue past stale or unavailable candidates. If every child
        // request fails, preserve the API error instead of reporting that the
        // filter simply contains no music.
        let mut all_tracks = Vec::new();
        let mut successful_child_requests = 0usize;
        let mut first_error = None;
        // PlayQueue + album-list + eight child requests stays within the
        // station-wide ten-request budget.
        const MAX_ALBUM_CHILD_REQUESTS: usize = 8;
        for album in albums_resp
            .media_container
            .metadata
            .iter()
            .take(MAX_ALBUM_CHILD_REQUESTS)
        {
            let tracks_path = format!("{}/{}/children", EP_LIBRARY_METADATA, album.rating_key);
            match self.get::<TracksResponse>(&tracks_path).await {
                Ok(tracks_resp) => {
                    successful_child_requests += 1;
                    all_tracks.extend(tracks_resp.media_container.metadata);
                }
                Err(error) => {
                    tracing::warn!(
                        "{} radio: failed to load album {}: {}",
                        filter_type,
                        album.rating_key,
                        error
                    );
                    if first_error.is_none() {
                        first_error = Some(error);
                    }
                }
            }
        }

        if all_tracks.is_empty() && successful_child_requests == 0 {
            if let Some(error) = first_error {
                return Err(error);
            }
        }

        // Shuffle the tracks
        use rand::seq::SliceRandom;
        all_tracks.shuffle(&mut rand::rng());

        // Limit to DEFAULT_SEARCH_LIMIT
        all_tracks.truncate(DEFAULT_SEARCH_LIMIT as usize);

        tracing::info!(
            "{} radio returned {} tracks from {} albums",
            filter_type,
            all_tracks.len(),
            albums_resp
                .media_container
                .metadata
                .len()
                .min(MAX_ALBUM_CHILD_REQUESTS)
        );

        Ok(all_tracks)
    }

    /// Create Time Travel Radio queue using PlayQueue API.
    ///
    /// IMPORTANT: Station queues should ALWAYS use the PlayQueue API when possible.
    /// This lets the Plex server do the heavy lifting and avoids blocking the UI.
    ///
    /// If PlayQueue fails, falls back to a LIMITED manual approach starting from earliest decades.
    /// NEVER make more than 10 sequential network calls for any station.
    async fn create_time_travel_queue(
        &mut self,
        library_key: &str,
    ) -> Result<Vec<Track>, ApiError> {
        self.create_time_travel_station(library_key)
            .await
            .map(|(tracks, _, _)| tracks)
    }

    /// Create Time Travel Radio together with the continuation state used by
    /// the player. This keeps the decade list and next index consistent with
    /// the exact fallback batch that produced the initial tracks.
    pub async fn create_time_travel_station(
        &mut self,
        library_key: &str,
    ) -> Result<(Vec<Track>, Vec<String>, Option<usize>), ApiError> {
        // Try PlayQueue API first (preferred - server does the work)
        let station_key = format!(
            "{}/{}/stations/timeTravel",
            EP_LIBRARY_SECTIONS, library_key
        );

        match self.create_station_queue_via_playqueue(&station_key).await {
            Ok(tracks) if !tracks.is_empty() => {
                tracing::info!(
                    "Time Travel Radio: PlayQueue returned {} tracks",
                    tracks.len()
                );
                let decades = self.get_time_travel_decades(library_key).await?;
                return Ok((tracks, decades, Some(0)));
            }
            Ok(_) => tracing::debug!("Time Travel PlayQueue returned no tracks, trying fallback"),
            Err(e) => tracing::debug!("Time Travel PlayQueue failed ({}), trying fallback", e),
        }

        // Fallback: Start from the beginning chronologically
        // Get decades first, then fetch from index 0
        let decades = self.get_time_travel_decades(library_key).await?;
        if decades.is_empty() {
            return Ok((vec![], vec![], None));
        }

        // Start from the beginning (index 0)
        let (tracks, next_index) = self
            .fetch_time_travel_track_batch(library_key, &decades, 0)
            .await?;
        Ok((tracks, decades, Some(next_index)))
    }

    /// Get sorted list of valid decades for Time Travel Radio.
    ///
    /// Returns decade values like ["1950", "1960", "1970", ...] sorted chronologically.
    pub async fn get_time_travel_decades(
        &self,
        library_key: &str,
    ) -> Result<Vec<String>, ApiError> {
        let decades_path = format!("{}/{}/decade", EP_LIBRARY_SECTIONS, library_key);
        let decade_items = self.get_category_items(&decades_path).await?;

        // Filter malformed and implausible metadata, then sort chronologically.
        let mut decades: Vec<(i32, String)> = decade_items
            .iter()
            .filter_map(|s| {
                parse_plausible_music_year(&s.title)
                    .filter(|year| year % 10 == 0)
                    .map(|year| (year, s.title.replace("s", "")))
            })
            .collect();

        decades.sort_by_key(|(y, _)| *y);

        let result: Vec<String> = decades.into_iter().map(|(_, v)| v).collect();
        tracing::info!("Time Travel Radio: found {} valid decades", result.len());
        Ok(result)
    }

    /// Fetch Time Travel tracks starting from a specific decade index.
    ///
    /// This enables chronological continuation - call with increasing indices
    /// to progress through time. Wraps around when reaching the end.
    ///
    /// LIMIT: Fetches from up to 3 productive decades with at most 10 requests.
    pub async fn fetch_time_travel_tracks_from_index(
        &self,
        library_key: &str,
        decades: &[String],
        start_index: usize,
    ) -> Result<Vec<Track>, ApiError> {
        self.fetch_time_travel_track_batch(library_key, decades, start_index)
            .await
            .map(|(tracks, _)| tracks)
    }

    /// Fetch a Time Travel batch and return the next unvisited decade index.
    /// Sparse or failed decades do not consume the productive-decade target,
    /// while a hard request budget keeps the operation bounded.
    pub async fn fetch_time_travel_track_batch(
        &self,
        library_key: &str,
        decades: &[String],
        start_index: usize,
    ) -> Result<(Vec<Track>, usize), ApiError> {
        use rand::seq::SliceRandom;

        const TARGET_DECADES_PER_FETCH: usize = 3;
        const ALBUMS_PER_DECADE: usize = 2; // LIMIT: Albums per decade
        const TRACKS_PER_ALBUM: usize = 3; // LIMIT: Tracks per album
                                           // Initial creation also spends one request on PlayQueue and one on the
                                           // decade list, keeping the complete operation within ten requests.
        const MAX_REQUESTS_PER_FETCH: usize = 8;

        if decades.is_empty() {
            return Ok((vec![], 0));
        }

        let mut all_tracks = Vec::new();
        let total_decades = decades.len();
        let mut visited = 0usize;
        let mut productive_decades = 0usize;
        let mut requests = 0usize;
        let mut successful_child_requests = 0usize;
        let mut first_error = None;

        while visited < total_decades
            && productive_decades < TARGET_DECADES_PER_FETCH
            && requests < MAX_REQUESTS_PER_FETCH
        {
            let decade_idx = (start_index + visited) % total_decades;
            let decade_value = &decades[decade_idx];
            visited += 1;

            let albums_path = format!(
                "{}/{}/all?type={}&decade={}&sort=rating:desc&limit={}",
                EP_LIBRARY_SECTIONS, library_key, TYPE_ALBUM, decade_value, ALBUMS_PER_DECADE
            );

            requests += 1;
            let before = all_tracks.len();
            match self.get::<AlbumsResponse>(&albums_path).await {
                Ok(resp) => {
                    for album in resp.media_container.metadata.iter().take(ALBUMS_PER_DECADE) {
                        if requests >= MAX_REQUESTS_PER_FETCH {
                            break;
                        }
                        let tracks_path =
                            format!("{}/{}/children", EP_LIBRARY_METADATA, album.rating_key);
                        requests += 1;
                        match self.get::<TracksResponse>(&tracks_path).await {
                            Ok(tracks_resp) => {
                                successful_child_requests += 1;
                                let mut tracks = tracks_resp.media_container.metadata;
                                tracks.shuffle(&mut rand::rng());
                                all_tracks.extend(tracks.into_iter().take(TRACKS_PER_ALBUM));
                            }
                            Err(error) => {
                                tracing::warn!(
                                    "Time Travel: failed to load album {}: {}",
                                    album.rating_key,
                                    error
                                );
                                if first_error.is_none() {
                                    first_error = Some(error);
                                }
                            }
                        }
                    }
                }
                Err(error) => {
                    tracing::warn!("Time Travel: failed to load {}s: {}", decade_value, error);
                    if first_error.is_none() {
                        first_error = Some(error);
                    }
                }
            }

            if all_tracks.len() > before {
                productive_decades += 1;
            }

            tracing::debug!(
                "Time Travel: {}s (idx {}) -> {} tracks total",
                decade_value,
                decade_idx,
                all_tracks.len()
            );
        }

        if all_tracks.is_empty() && successful_child_requests == 0 {
            if let Some(error) = first_error {
                return Err(error);
            }
        }

        let end_index = (start_index + visited) % total_decades;
        tracing::info!(
            "Time Travel Radio: fetched {} tracks from decades {}-{} (indices {}-{})",
            all_tracks.len(),
            &decades[start_index % total_decades],
            &decades[(start_index + visited.saturating_sub(1)) % total_decades],
            start_index % total_decades,
            end_index
        );

        Ok((all_tracks, end_index))
    }

    /// Create On This Day queue from the music hubs API.
    /// Finds the "music.onthisday" hub and fetches tracks from its albums.
    async fn create_on_this_day_queue(&self, library_key: &str) -> Result<Vec<Track>, ApiError> {
        let hubs = self.get_music_hubs(library_key).await?;

        // Find the On This Day hub
        let otd_hub = hubs
            .into_iter()
            .find(|h| h.hub_identifier == "music.onthisday");
        let hub = match otd_hub {
            Some(h) => h,
            None => {
                tracing::info!("On This Day: no hub found (no albums released on today's date)");
                return Ok(vec![]);
            }
        };

        if hub.metadata.is_empty() {
            tracing::info!("On This Day: hub found but no albums");
            return Ok(vec![]);
        }

        tracing::info!("On This Day: found {} albums in hub", hub.metadata.len());

        // The hubs request plus nine album requests stays within the
        // station-wide ten-request budget.
        let mut all_tracks = Vec::new();
        let mut successful_album_requests = 0usize;
        let mut first_error = None;
        for album_meta in hub.metadata.iter().take(9) {
            match self.get_album_tracks(&album_meta.rating_key).await {
                Ok(tracks) => {
                    successful_album_requests += 1;
                    tracing::debug!(
                        "On This Day: {} - {} tracks",
                        album_meta.title,
                        tracks.len()
                    );
                    all_tracks.extend(tracks);
                }
                Err(e) => {
                    tracing::warn!(
                        "On This Day: failed to get tracks for '{}': {}",
                        album_meta.title,
                        e
                    );
                    if first_error.is_none() {
                        first_error = Some(e);
                    }
                }
            }
        }

        if all_tracks.is_empty() && successful_album_requests == 0 {
            if let Some(error) = first_error {
                return Err(error);
            }
        }

        tracing::info!(
            "On This Day: {} total tracks from {} albums",
            all_tracks.len(),
            hub.metadata.len().min(9)
        );

        Ok(all_tracks)
    }

    /// Create artist radio using the shared server-radio plus direct-track
    /// fallback path.
    pub async fn create_artist_radio_queue(
        &mut self,
        artist_rating_key: &str,
    ) -> Result<Vec<Track>, ApiError> {
        self.create_radio_from_metadata(artist_rating_key).await
    }

    /// Get the server's machine identifier (needed for playQueue URIs).
    /// Caches the result to avoid redundant network calls.
    async fn get_server_machine_id(&mut self) -> Result<String, ApiError> {
        if let Some(ref id) = self.cached_machine_id {
            return Ok(id.clone());
        }
        let response: serde_json::Value = self.get("/").await?;
        let id = response
            .get("MediaContainer")
            .and_then(|mc| mc.get("machineIdentifier"))
            .and_then(|v| v.as_str())
            .map(|s| s.to_string())
            .ok_or_else(|| ApiError::ParseError("Could not get server machine ID".to_string()))?;
        self.cached_machine_id = Some(id.clone());
        Ok(id)
    }

    // ========================================================================
    // Search Methods
    // ========================================================================

    /// Search across all content.
    pub async fn search(&self, query: &str) -> Result<SearchResults, ApiError> {
        let path = format!(
            "{}?query={}&limit={}&{}=0&{}={}",
            EP_HUBS_SEARCH,
            urlencoding::encode(query),
            DEFAULT_SEARCH_LIMIT,
            PARAM_CONTAINER_START,
            PARAM_CONTAINER_SIZE,
            DEFAULT_SEARCH_LIMIT
        );
        let response: SearchResponse = self.get(&path).await?;

        let mut results = SearchResults::default();

        for hub in response.media_container.hub {
            if let Some(metadata) = hub.metadata {
                match hub.hub_type.as_str() {
                    "artist" => match serde_json::from_value::<Vec<Artist>>(metadata) {
                        Ok(artists) => results.artists = artists,
                        Err(e) => tracing::warn!("Failed to parse artists: {}", e),
                    },
                    "album" => match serde_json::from_value::<Vec<Album>>(metadata) {
                        Ok(albums) => results.albums = albums,
                        Err(e) => tracing::warn!("Failed to parse albums: {}", e),
                    },
                    "track" => match serde_json::from_value::<Vec<Track>>(metadata) {
                        Ok(tracks) => {
                            tracing::debug!("Search found {} tracks", tracks.len());
                            results.tracks = tracks;
                        }
                        Err(e) => tracing::warn!("Failed to parse tracks: {}", e),
                    },
                    "playlist" => match serde_json::from_value::<Vec<Playlist>>(metadata) {
                        Ok(playlists) => results.playlists = playlists,
                        Err(e) => tracing::warn!("Failed to parse playlists: {}", e),
                    },
                    _ => {}
                }
            }
        }

        Ok(results)
    }

    // ========================================================================
    // Sonic Similarity
    // ========================================================================

    /// Get sonically similar tracks via the /nearest endpoint.
    pub async fn get_similar_tracks(
        &self,
        rating_key: &str,
        limit: u32,
    ) -> Result<Vec<Track>, ApiError> {
        let path = format!(
            "{}/{}/nearest?limit={}&maxDistance=0.25",
            EP_LIBRARY_METADATA, rating_key, limit
        );

        let response: TracksResponse = self.get(&path).await?;
        let tracks = response.media_container.metadata;

        tracing::info!(
            "get_similar_tracks for {} found {} tracks",
            rating_key,
            tracks.len()
        );

        Ok(tracks)
    }

    /// Get sonically similar tracks with configurable maxDistance.
    /// Looser distance (e.g. 0.5) finds more diverse bridge tracks for DJ Stretch.
    pub async fn get_similar_tracks_with_distance(
        &self,
        rating_key: &str,
        limit: u32,
        max_distance: f32,
    ) -> Result<Vec<Track>, ApiError> {
        let path = format!(
            "{}/{}/nearest?limit={}&maxDistance={}",
            EP_LIBRARY_METADATA, rating_key, limit, max_distance
        );

        tracing::info!("Sonic similarity request: {}", path);
        let response: TracksResponse = self.get(&path).await.map_err(|e| {
            tracing::warn!(
                "Sonic similarity request failed for key={}: {}",
                rating_key,
                e
            );
            e
        })?;
        let tracks = response.media_container.metadata;

        tracing::info!(
            "Sonic similarity for key={} (maxDistance={}) returned {} tracks",
            rating_key,
            max_distance,
            tracks.len()
        );

        Ok(tracks)
    }

    /// Compute a sonic path between two tracks using Plex's /computePath endpoint.
    /// Returns a sequence of tracks forming a sonic bridge between start and end.
    pub async fn compute_path(
        &self,
        section_id: &str,
        start_id: &str,
        end_id: &str,
        count: usize,
        max_distance: f32,
    ) -> Result<Vec<Track>, ApiError> {
        let path = format!(
            "{}/{}/computePath?startID={}&endID={}&count={}&maxDistance={}",
            EP_LIBRARY_SECTIONS, section_id, start_id, end_id, count, max_distance
        );

        let response: TracksResponse = self.get(&path).await?;
        let tracks = response.media_container.metadata;

        tracing::info!(
            "compute_path from {} to {} (count={}, maxDistance={}) returned {} tracks",
            start_id,
            end_id,
            count,
            max_distance,
            tracks.len()
        );

        Ok(tracks)
    }

    /// Get sonically similar artists via the /nearest endpoint.
    pub async fn get_similar_artists(
        &self,
        rating_key: &str,
        limit: u32,
    ) -> Result<Vec<Artist>, ApiError> {
        let path = format!(
            "{}/{}/nearest?limit={}&maxDistance=0.25",
            EP_LIBRARY_METADATA, rating_key, limit
        );

        let response: ArtistsResponse = self.get(&path).await?;
        let artists = response.media_container.metadata;

        tracing::info!(
            "get_similar_artists for {} found {} artists",
            rating_key,
            artists.len()
        );

        Ok(artists)
    }

    /// Get sonically similar albums via the /nearest endpoint.
    pub async fn get_similar_albums(
        &self,
        rating_key: &str,
        limit: u32,
    ) -> Result<Vec<Album>, ApiError> {
        let path = format!(
            "{}/{}/nearest?limit={}&maxDistance=0.25",
            EP_LIBRARY_METADATA, rating_key, limit
        );

        let response: AlbumsResponse = self.get(&path).await?;
        let albums = response.media_container.metadata;

        tracing::info!(
            "get_similar_albums for {} found {} albums",
            rating_key,
            albums.len()
        );

        Ok(albums)
    }

    // ========================================================================
    // Streaming URLs
    // ========================================================================

    /// Get the direct stream URL for a track.
    pub fn get_stream_url(&self, track: &Track) -> Result<String, ApiError> {
        let part = track.stream_part().ok_or(ApiError::NoMediaAvailable)?;
        // Validate authentication here, but carry the token in the request
        // header. Query-string credentials leak into logs, process telemetry,
        // proxies, and crash reports.
        self.require_token()?;
        let server = self.require_server()?;

        Ok(format!("{}{}", server, part.key))
    }

    /// Get a transcoded stream URL (Plex converts to MP3 at the given bitrate).
    ///
    /// Two-step process verified by testing against PMS:
    /// 1. Call `/video/:/transcode/universal/decision` to establish the transcode session
    /// 2. Return the `/music/:/transcode/universal/start` URL for the actual MP3 stream
    ///
    /// Critical details discovered through testing:
    /// - `X-Plex-Platform` MUST be "iOS" — PMS rejects transcoding for "macos"/"linux"
    ///   platforms, assuming they can direct-play everything.
    /// - The decision step MUST be called first or start returns 400.
    /// - All Plex auth params go in the query string, NOT as HTTP headers.
    /// - Uses `protocol=http` with mp3 profile for a single direct MP3 stream.
    pub async fn get_transcoded_stream_url(
        &self,
        track: &Track,
        bitrate_kbps: u32,
    ) -> Result<String, ApiError> {
        let token = self.require_token()?;
        let server = self.require_server()?;
        let session_id = uuid::Uuid::new_v4().to_string();

        let path = if !track.key.is_empty() {
            track.key.clone()
        } else {
            format!("{}/{}", EP_LIBRARY_METADATA, track.rating_key)
        };

        let profile_extra = "add-transcode-target(type=musicProfile&context=streaming&protocol=http&container=mp3&audioCodec=mp3)";

        let common_params = format!(
            "path={}\
             &directPlay=0&directStream=1\
             &protocol=http\
             &musicBitrate={}\
             &session={}\
             &X-Plex-Session-Identifier={}\
             &X-Plex-Token={}\
             &X-Plex-Client-Identifier={}\
             &X-Plex-Product={}\
             &X-Plex-Version={}\
             &X-Plex-Platform={}\
             &X-Plex-Client-Profile-Extra={}",
            urlencoding::encode(&path),
            bitrate_kbps,
            &session_id,
            &session_id,
            urlencoding::encode(token),
            urlencoding::encode(&self.client_info.client_identifier),
            urlencoding::encode(&self.client_info.product),
            urlencoding::encode(&self.client_info.version),
            urlencoding::encode("iOS"),
            urlencoding::encode(profile_extra),
        );

        // Prefer the authenticated HTTPS server address. Some PMS versions
        // reject universal-transcode decisions through plex.direct; only then
        // fall back to the LAN IP over HTTP. This avoids silently downgrading
        // every session while preserving compatibility with those servers.
        let mut candidates = vec![server.to_string()];
        if let Ok(parsed) = reqwest::Url::parse(server) {
            if parsed
                .host_str()
                .is_some_and(|host| host.ends_with(".plex.direct"))
            {
                if let Some(host) = parsed.host_str() {
                    if let Some(encoded_ip) = host.split('.').next() {
                        let raw_ip = encoded_ip.replace('-', ".");
                        if raw_ip.parse::<std::net::Ipv4Addr>().is_ok() {
                            let port = parsed.port().unwrap_or(32400);
                            let fallback = format!("http://{raw_ip}:{port}");
                            if fallback != server {
                                candidates.push(fallback);
                            }
                        }
                    }
                }
            }
        }

        let mut last_error =
            ApiError::Connection("transcode decision could not be established".to_string());
        for transcode_server in candidates {
            let decision_url =
                format!("{transcode_server}/video/:/transcode/universal/decision?{common_params}");
            tracing::info!(
                "Transcode decision ({}kbps): {}",
                bitrate_kbps,
                redact_url(&decision_url)
            );

            match self
                .send_sensitive_get(&decision_url, HeaderMap::new())
                .await
            {
                Ok(response) if response.status().is_success() => {
                    // The decision body is not needed. Do not buffer an
                    // untrusted, unbounded response merely to reuse a socket.
                    drop(response);
                    let start_url = format!(
                        "{transcode_server}/music/:/transcode/universal/start?{common_params}"
                    );
                    tracing::info!(
                        "Transcode stream ready ({}kbps): {}",
                        bitrate_kbps,
                        redact_url(&start_url)
                    );
                    return Ok(start_url);
                }
                Ok(response) => {
                    let status = response.status();
                    tracing::warn!(
                        "Transcode decision via {} returned HTTP {}",
                        transcode_server,
                        status
                    );
                    last_error = ApiError::ServerError {
                        status: status.as_u16(),
                        message: "transcode decision was rejected".to_string(),
                    };
                }
                Err(error) => {
                    tracing::warn!(
                        "Transcode decision via {} failed: {}",
                        transcode_server,
                        error
                    );
                    last_error = error;
                }
            }
        }

        Err(last_error)
    }

    /// Get client identifier.
    pub fn client_identifier(&self) -> &str {
        &self.client_info.client_identifier
    }

    /// Get thumbnail URL with transcoding for size.
    pub fn get_thumb_url(
        &self,
        thumb_path: &str,
        width: u32,
        height: u32,
    ) -> Result<String, ApiError> {
        self.require_token()?;
        let server = self.require_server()?;

        Ok(format!(
            "{}{}?width={}&height={}&minSize=1&upscale=1&url={}",
            server,
            EP_PHOTO_TRANSCODE,
            width,
            height,
            urlencoding::encode(thumb_path)
        ))
    }

    /// Get raw thumbnail URL without transcoding.
    pub fn get_thumb_url_raw(&self, thumb_path: &str) -> Result<String, ApiError> {
        self.require_token()?;
        let server = self.require_server()?;

        Ok(format!("{}{}", server, thumb_path))
    }

    /// Fetch artwork image data as bytes.
    pub async fn fetch_artwork(&self, thumb_path: &str, size: u32) -> Result<Vec<u8>, ApiError> {
        let url = self.get_thumb_url(thumb_path, size, size)?;

        let response = self.send_get(&url, self.build_headers()?).await?;

        if !response.status().is_success() {
            return Err(ApiError::ServerError {
                status: response.status().as_u16(),
                message: "Failed to fetch artwork".to_string(),
            });
        }

        if response
            .content_length()
            .is_some_and(|length| length > MAX_ARTWORK_BYTES as u64)
        {
            return Err(ApiError::ParseError(format!(
                "Artwork exceeds {} MiB limit",
                MAX_ARTWORK_BYTES / (1024 * 1024),
            )));
        }

        let capacity = response
            .content_length()
            .and_then(|length| usize::try_from(length).ok())
            .unwrap_or(64 * 1024)
            .min(MAX_ARTWORK_BYTES);
        let mut bytes = Vec::with_capacity(capacity);
        let mut body = response.bytes_stream();
        while let Some(chunk) = body.next().await {
            let chunk = chunk?;
            if bytes.len().saturating_add(chunk.len()) > MAX_ARTWORK_BYTES {
                return Err(ApiError::ParseError(format!(
                    "Artwork exceeds {} MiB limit",
                    MAX_ARTWORK_BYTES / (1024 * 1024),
                )));
            }
            bytes.extend_from_slice(&chunk);
        }
        Ok(bytes)
    }

    // ========================================================================
    // Playback Reporting
    // ========================================================================

    /// Report playback start to Plex (for "Continue Listening" etc.).
    pub async fn report_playback_start(
        &self,
        track: &Track,
        position_ms: u64,
        session_id: Option<&str>,
    ) -> Result<(), ApiError> {
        self.report_timeline(track, position_ms, "playing", None, session_id)
            .await
    }

    /// Report playback progress.
    pub async fn report_playback_progress(
        &self,
        track: &Track,
        position_ms: u64,
        session_id: Option<&str>,
    ) -> Result<(), ApiError> {
        self.report_timeline(track, position_ms, "playing", None, session_id)
            .await
    }

    /// Report playback stop with continuation flag.
    ///
    /// - `continuing=true`: Client is moving to another track (don't clear from Now Playing)
    /// - `continuing=false`: Playback truly ended (clear from Now Playing)
    pub async fn report_playback_stop(
        &self,
        track: &Track,
        position_ms: u64,
        continuing: bool,
        session_id: Option<&str>,
    ) -> Result<(), ApiError> {
        self.report_timeline(track, position_ms, "stopped", Some(continuing), session_id)
            .await
    }

    /// Internal helper for timeline reporting.
    ///
    /// The `continuing` parameter is only meaningful when state is "stopped":
    /// - `Some(true)`: Moving to another track
    /// - `Some(false)`: Truly stopping playback
    /// - `None`: Not applicable (for playing state)
    ///
    /// The `session_id` is sent as `X-Plex-Session-Identifier` header to correlate
    /// all timeline reports for a single playback session.
    async fn report_timeline(
        &self,
        track: &Track,
        position_ms: u64,
        state: &str,
        continuing: Option<bool>,
        session_id: Option<&str>,
    ) -> Result<(), ApiError> {
        use reqwest::header::HeaderValue;

        let mut path = format!(
            "{}?ratingKey={}&key={}&state={}&time={}&duration={}&identifier=com.plexapp.plugins.library",
            EP_TIMELINE, track.rating_key, track.key, state, position_ms, track.duration_ms()
        );

        // Add continuing parameter when stopping (tells Plex whether to clear the session)
        if let Some(cont) = continuing {
            path.push_str(&format!("&continuing={}", if cont { 1 } else { 0 }));
        }

        let url = self.build_url(&path)?;
        let mut headers = self.build_headers()?;

        // Add session identifier header if provided (correlates all reports for this playback session)
        if let Some(sid) = session_id {
            headers.insert(
                HEADER_PLEX_SESSION_ID,
                HeaderValue::from_str(sid)
                    .map_err(|_| ApiError::InvalidHeader(HEADER_PLEX_SESSION_ID.to_string()))?,
            );
        }

        let response = self.send_get(&url, headers).await?;
        if !response.status().is_success() {
            let status = response.status().as_u16();
            let message = read_error_body(response).await;
            return Err(ApiError::ServerError { status, message });
        }

        Ok(())
    }

    /// Mark a track as played (scrobble).
    pub async fn scrobble(&self, rating_key: &str) -> Result<(), ApiError> {
        let path = format!(
            "{}?key=/library/metadata/{}&identifier=com.plexapp.plugins.library",
            EP_SCROBBLE, rating_key
        );
        let url = self.build_url(&path)?;

        let response = self.send_get(&url, self.build_headers()?).await?;

        if !response.status().is_success() {
            let status = response.status().as_u16();
            let message = read_error_body(response).await;
            return Err(ApiError::ServerError { status, message });
        }

        Ok(())
    }

    // ========================================================================
    // Helper Methods
    // ========================================================================

    /// Extract filter ID from a filter string (e.g., "genre=123" -> "123").
    fn extract_filter_id<'a>(filter: &'a str, prefix: &str) -> &'a str {
        if filter.contains(prefix) {
            filter
                .split(prefix)
                .nth(1)
                .and_then(|s| s.split('&').next())
                .unwrap_or(filter)
        } else {
            filter
        }
    }
}

// ============================================================================
// Standalone Connection Testing
// ============================================================================

/// Test if a server URL is reachable with a short timeout.
/// Returns Ok(()) if reachable, Err with reason if not.
///
/// This is used to test multiple connection options before committing to one,
/// which is essential for remote access when local IPs are unreachable.
///
/// Note: Sends full Plex client headers as some servers may require them to respond.
pub async fn test_connection(
    url: &str,
    token: &str,
    client_identifier: &str,
) -> Result<(), ApiError> {
    test_connection_for_server(url, token, client_identifier, None).await
}

fn identity_machine_identifier(body: &str) -> Option<String> {
    serde_json::from_str::<serde_json::Value>(body)
        .ok()
        .and_then(|value| {
            value
                .get("MediaContainer")
                .and_then(|container| container.get("machineIdentifier"))
                .and_then(serde_json::Value::as_str)
                .map(str::to_owned)
        })
        .or_else(|| {
            ["machineIdentifier=\"", "machineIdentifier='"]
                .into_iter()
                .find_map(|marker| {
                    let (_, rest) = body.split_once(marker)?;
                    let quote = marker.chars().last()?;
                    rest.split_once(quote)
                        .map(|(identifier, _)| identifier.to_string())
                })
        })
}

/// Probe a Plex identity endpoint and optionally require the expected server.
/// This prevents a configured local or private URL from silently selecting
/// a different Plex server that happens to answer on the same port.
pub async fn test_connection_for_server(
    url: &str,
    token: &str,
    client_identifier: &str,
    expected_machine_id: Option<&str>,
) -> Result<(), ApiError> {
    use super::auth::PlexClientInfo;

    let http = shared_http_client()?;

    // Use the stored client_identifier — Plex tokens are tied to the identifier
    // they were issued for, so a mismatch can cause 400/401 errors.
    let client_info = PlexClientInfo {
        client_identifier: client_identifier.to_string(),
        ..PlexClientInfo::default()
    };

    let response = http
        .get(format!("{}/identity", url.trim_end_matches('/')))
        .header(HEADER_PLEX_TOKEN, token)
        .header(HEADER_PLEX_PRODUCT, &client_info.product)
        .header(HEADER_PLEX_VERSION, &client_info.version)
        .header(HEADER_PLEX_CLIENT_ID, &client_info.client_identifier)
        .header(HEADER_PLEX_DEVICE_NAME, &client_info.device_name)
        .header(HEADER_PLEX_PLATFORM, &client_info.platform)
        .header("Accept", "application/json")
        .timeout(Duration::from_secs(CONNECTION_TEST_TIMEOUT_SECS))
        .send()
        .await?;

    if !response.status().is_success() {
        return Err(ApiError::ServerError {
            status: response.status().as_u16(),
            message: "Server returned error".to_string(),
        });
    }

    if let Some(expected) = expected_machine_id.filter(|expected| !expected.is_empty()) {
        let body = read_response_text_limited(response, MAX_ERROR_RESPONSE_BYTES).await?;
        let actual = identity_machine_identifier(&body);
        if actual.as_deref() != Some(expected) {
            return Err(ApiError::Connection(
                "address answered for a different Plex server".to_string(),
            ));
        }
    }
    Ok(())
}

#[cfg(test)]
mod identity_tests {
    use super::{
        decode_response_text, identity_machine_identifier, is_plausible_decade,
        parse_plausible_music_year, PlexClient,
    };
    use tokio::io::{AsyncReadExt, AsyncWriteExt};
    use tokio::net::TcpListener;

    async fn serve_json(listener: &TcpListener, expected_path: &str, body: &str) {
        let (mut stream, _) = listener.accept().await.expect("accept test request");
        let mut request = vec![0; 4096];
        let size = stream.read(&mut request).await.expect("read test request");
        let request = String::from_utf8_lossy(&request[..size]);
        assert!(
            request.starts_with(&format!("GET {expected_path} HTTP/1.1\r\n")),
            "unexpected request: {request}"
        );

        let response = format!(
            "HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nContent-Length: {}\r\nConnection: close\r\n\r\n{}",
            body.len(),
            body
        );
        stream
            .write_all(response.as_bytes())
            .await
            .expect("write test response");
    }

    async fn serve_response(
        listener: &TcpListener,
        method: &str,
        expected_path_prefix: &str,
        status: &str,
        body: &str,
    ) {
        let (mut stream, _) = listener.accept().await.expect("accept test request");
        let mut request = vec![0; 8192];
        let size = stream.read(&mut request).await.expect("read test request");
        let request = String::from_utf8_lossy(&request[..size]);
        assert!(
            request.starts_with(&format!("{method} {expected_path_prefix}")),
            "unexpected request: {request}"
        );

        let response = format!(
            "HTTP/1.1 {status}\r\nContent-Type: application/json\r\nContent-Length: {}\r\nConnection: close\r\n\r\n{}",
            body.len(),
            body
        );
        stream
            .write_all(response.as_bytes())
            .await
            .expect("write test response");
    }

    #[test]
    fn replaces_invalid_utf8_without_discarding_metadata() {
        let body = decode_response_text(b"before \xff after".to_vec());
        assert_eq!(body, "before \u{fffd} after");
    }

    #[test]
    fn reads_json_identity() {
        let body = r#"{"MediaContainer":{"machineIdentifier":"server-id"}}"#;
        assert_eq!(
            identity_machine_identifier(body).as_deref(),
            Some("server-id")
        );
    }

    #[test]
    fn reads_xml_identity() {
        let body = r#"<MediaContainer machineIdentifier="server-id"></MediaContainer>"#;
        assert_eq!(
            identity_machine_identifier(body).as_deref(),
            Some("server-id")
        );
    }

    #[test]
    fn rejects_identity_without_identifier() {
        assert_eq!(identity_machine_identifier("{}"), None);
    }

    #[test]
    fn rejects_implausible_year_and_decade_metadata() {
        assert_eq!(parse_plausible_music_year("1997"), Some(1997));
        assert!(is_plausible_decade("1990s"));
        assert!(!is_plausible_decade("1997"));
        assert!(!is_plausible_decade("6190s"));
        assert!(!is_plausible_decade("Unknown"));
    }

    #[tokio::test]
    async fn artist_radio_falls_back_when_playqueue_errors() {
        let listener = TcpListener::bind("127.0.0.1:0")
            .await
            .expect("bind test server");
        let address = listener.local_addr().expect("test server address");
        let server = tokio::spawn(async move {
            serve_response(
                &listener,
                "GET",
                "/ HTTP/1.1",
                "200 OK",
                r#"{"MediaContainer":{"machineIdentifier":"server-id"}}"#,
            )
            .await;
            serve_response(
                &listener,
                "POST",
                "/playQueues?",
                "503 Service Unavailable",
                r#"{"error":"unavailable"}"#,
            )
            .await;
            serve_response(
                &listener,
                "GET",
                "/library/metadata/artist-1/allLeaves HTTP/1.1",
                "200 OK",
                r#"{"MediaContainer":{"size":1,"Metadata":[{"ratingKey":"track-1","title":"Track"}]}}"#,
            )
            .await;
        });

        let mut client = PlexClient::new_with_url(
            &format!("http://{address}"),
            Some("test-token"),
            "test-client",
        )
        .expect("create test client");
        let tracks = client
            .create_radio_from_metadata("artist-1")
            .await
            .expect("use direct artist fallback");

        assert_eq!(tracks.len(), 1);
        assert_eq!(tracks[0].rating_key, "track-1");
        server.await.expect("test server task");
    }

    #[tokio::test]
    async fn time_travel_skips_failed_and_sparse_decades() {
        let listener = TcpListener::bind("127.0.0.1:0")
            .await
            .expect("bind test server");
        let address = listener.local_addr().expect("test server address");
        let server = tokio::spawn(async move {
            serve_response(
                &listener,
                "GET",
                "/library/sections/5/all?type=9&decade=1900&sort=rating:desc&limit=2 HTTP/1.1",
                "200 OK",
                "not-json",
            )
            .await;

            for (decade, album, track) in [
                ("1910", "album-1", "track-1"),
                ("1920", "album-2", "track-2"),
                ("1930", "album-3", "track-3"),
            ] {
                serve_response(
                    &listener,
                    "GET",
                    &format!(
                        "/library/sections/5/all?type=9&decade={decade}&sort=rating:desc&limit=2 HTTP/1.1"
                    ),
                    "200 OK",
                    &format!(
                        r#"{{"MediaContainer":{{"size":1,"Metadata":[{{"ratingKey":"{album}","title":"Album"}}]}}}}"#
                    ),
                )
                .await;
                serve_response(
                    &listener,
                    "GET",
                    &format!("/library/metadata/{album}/children HTTP/1.1"),
                    "200 OK",
                    &format!(
                        r#"{{"MediaContainer":{{"size":1,"Metadata":[{{"ratingKey":"{track}","title":"Track"}}]}}}}"#
                    ),
                )
                .await;
            }
        });

        let client = PlexClient::new_with_url(
            &format!("http://{address}"),
            Some("test-token"),
            "test-client",
        )
        .expect("create test client");
        let decades = vec!["1900", "1910", "1920", "1930"]
            .into_iter()
            .map(str::to_string)
            .collect::<Vec<_>>();
        let (tracks, next_index) = client
            .fetch_time_travel_track_batch("5", &decades, 0)
            .await
            .expect("skip failed decade");

        assert_eq!(tracks.len(), 3);
        assert_eq!(next_index, 0);
        server.await.expect("test server task");
    }

    #[tokio::test]
    async fn omits_on_this_day_when_plex_has_no_hub() {
        let listener = TcpListener::bind("127.0.0.1:0")
            .await
            .expect("bind test server");
        let address = listener.local_addr().expect("test server address");
        let server = tokio::spawn(async move {
            serve_response(
                &listener,
                "GET",
                "/hubs/sections/5 HTTP/1.1",
                "200 OK",
                r#"{"MediaContainer":{"Hub":[]}}"#,
            )
            .await;
        });

        let client = PlexClient::new_with_url(
            &format!("http://{address}"),
            Some("test-token"),
            "test-client",
        )
        .expect("create test client");
        let stations = client.get_stations("5").await.expect("load stations");

        assert!(stations
            .iter()
            .all(|station| station.identifier.as_deref() != Some("onThisDay")));
        server.await.expect("test server task");
    }

    #[tokio::test]
    async fn includes_on_this_day_when_plex_has_releases() {
        let listener = TcpListener::bind("127.0.0.1:0")
            .await
            .expect("bind test server");
        let address = listener.local_addr().expect("test server address");
        let server = tokio::spawn(async move {
            serve_response(
                &listener,
                "GET",
                "/hubs/sections/5 HTTP/1.1",
                "200 OK",
                r#"{"MediaContainer":{"Hub":[{"hubIdentifier":"music.onthisday","title":"On This Day","type":"album","Metadata":[{"ratingKey":"album-1","key":"/library/metadata/album-1","title":"Album","type":"album"}]}]}}"#,
            )
            .await;
        });

        let client = PlexClient::new_with_url(
            &format!("http://{address}"),
            Some("test-token"),
            "test-client",
        )
        .expect("create test client");
        let stations = client.get_stations("5").await.expect("load stations");

        assert!(stations
            .iter()
            .any(|station| station.identifier.as_deref() == Some("onThisDay")));
        server.await.expect("test server task");
    }

    #[tokio::test]
    async fn random_album_station_bypasses_empty_sonic_play_queue() {
        let listener = TcpListener::bind("127.0.0.1:0")
            .await
            .expect("bind test server");
        let address = listener.local_addr().expect("test server address");
        let server = tokio::spawn(async move {
            serve_json(
                &listener,
                "/library/sections/5/all?type=9&sort=random&limit=5",
                r#"{"MediaContainer":{"size":1,"Metadata":[{"ratingKey":"album-1","title":"Album"}]}}"#,
            )
            .await;
            serve_json(
                &listener,
                "/library/metadata/album-1/children",
                r#"{"MediaContainer":{"size":1,"Metadata":[{"ratingKey":"track-1","title":"Track","parentTitle":"Album","parentRatingKey":"album-1"}]}}"#,
            )
            .await;
        });

        let mut client = PlexClient::new_with_url(
            &format!("http://{address}"),
            Some("test-token"),
            "test-client",
        )
        .expect("create test client");
        let tracks = client
            .create_station_queue("/library/sections/5/stations/randomAlbum")
            .await
            .expect("create random album station");

        assert_eq!(tracks.len(), 1);
        assert_eq!(tracks[0].rating_key, "track-1");
        server.await.expect("test server task");
    }
}
