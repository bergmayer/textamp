//! Plex catalog response envelopes. Domain metadata is shared with other backends.
pub use crate::library::catalog::{Album, Artist, GenreTag};
pub use crate::library::track::{Media, MediaPart, Track};
use serde::{Deserialize, Serialize};

/// Response wrapper for artists.
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "PascalCase")]
pub struct ArtistsResponse {
    pub media_container: ArtistsContainer,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ArtistsContainer {
    #[serde(default)]
    pub size: u32,
    #[serde(default)]
    pub total_size: Option<u32>,
    #[serde(default, rename = "Metadata")]
    pub metadata: Vec<Artist>,
}

/// Response wrapper for albums.
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "PascalCase")]
pub struct AlbumsResponse {
    pub media_container: AlbumsContainer,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct AlbumsContainer {
    #[serde(default)]
    pub size: u32,
    #[serde(default)]
    pub total_size: Option<u32>,
    #[serde(default, rename = "Metadata")]
    pub metadata: Vec<Album>,
}

/// Response wrapper for tracks.
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "PascalCase")]
pub struct TracksResponse {
    pub media_container: TracksContainer,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct TracksContainer {
    #[serde(default, rename = "Metadata")]
    pub metadata: Vec<Track>,
    /// Number of items in this response. Used by paginated callers to
    /// decide whether to fetch another page (Plex omits this for some
    /// endpoints; default 0 then triggers a fall-through to the
    /// metadata length).
    #[serde(default)]
    pub size: u32,
    /// Total number of items across all pages. `None` for endpoints
    /// that don't paginate (Plex returns the field only when it
    /// applied a Container-Start/Container-Size request).
    #[serde(default)]
    pub total_size: Option<u32>,
}
