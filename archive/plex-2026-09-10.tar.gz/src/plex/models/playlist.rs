//! Plex playlist response envelope.
pub use crate::library::catalog::Playlist;
use serde::{Deserialize, Serialize};

/// Response wrapper for playlists.
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "PascalCase")]
pub struct PlaylistsResponse {
    pub media_container: PlaylistsContainer,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "PascalCase")]
pub struct PlaylistsContainer {
    #[serde(default, rename = "Metadata")]
    pub metadata: Vec<Playlist>,
}
