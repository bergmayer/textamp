//! Hub models for Plex home screen.

use serde::{Deserialize, Serialize};

pub use crate::library::station::{RadioSource, Station, StationKind};

/// A hub/section on the home screen.
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct Hub {
    pub hub_identifier: String,
    pub title: String,
    #[serde(rename = "type")]
    pub hub_type: String,
    #[serde(default)]
    pub hub_key: Option<String>,
    #[serde(default)]
    pub more: bool,
    #[serde(default)]
    pub size: u32,
    #[serde(default, rename = "Metadata")]
    pub metadata: Vec<HubMetadata>,
}

impl Hub {
    /// Get the hub type as an enum.
    pub fn get_type(&self) -> HubType {
        HubType::from(self.hub_identifier.as_str())
    }

    /// Check if this hub is music-related.
    pub fn is_music(&self) -> bool {
        // Check hub_identifier for music-related content
        self.hub_identifier.contains("music")
            || self.hub_type == "artist"
            || self.hub_type == "album"
            || self.hub_type == "track"
            || self.hub_type == "playlist"
    }
}

/// Hub type classification.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum HubType {
    MixesForYou,
    RecentlyPlayed,
    RecentlyAdded,
    OnThisDay,
    Stations,
    SimilarArtists,
    SimilarAlbums,
    Playlists,
    Custom,
}

impl From<&str> for HubType {
    fn from(s: &str) -> Self {
        match s {
            "music.recent.added" => HubType::RecentlyAdded,
            "music.recent.played" => HubType::RecentlyPlayed,
            "music.playlists" => HubType::Playlists,
            "hub.music.mixes" | "music.mixes" => HubType::MixesForYou,
            "music.onthisday" => HubType::OnThisDay,
            "music.stations" => HubType::Stations,
            s if s.contains("similar") => HubType::SimilarArtists,
            _ => HubType::Custom,
        }
    }
}

/// Hub metadata item (can be artist, album, track, or playlist).
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct HubMetadata {
    pub rating_key: String,
    pub key: String,
    pub title: String,
    #[serde(rename = "type")]
    pub item_type: String,
    #[serde(default)]
    pub thumb: Option<String>,
    #[serde(default)]
    pub art: Option<String>,
    // Album/Track specific
    #[serde(default)]
    pub parent_title: Option<String>,
    #[serde(default)]
    pub grandparent_title: Option<String>,
    #[serde(default)]
    pub year: Option<u16>,
}

impl HubMetadata {
    /// Convert to a HubItem enum based on type.
    pub fn to_hub_item(&self) -> HubItem {
        match self.item_type.as_str() {
            "artist" => HubItem::Artist(self.clone()),
            "album" => HubItem::Album(self.clone()),
            "track" => HubItem::Track(self.clone()),
            "playlist" => HubItem::Playlist(self.clone()),
            _ => HubItem::Unknown(self.clone()),
        }
    }
}

/// Enumeration of possible hub items.
#[derive(Debug, Clone)]
pub enum HubItem {
    Artist(HubMetadata),
    Album(HubMetadata),
    Track(HubMetadata),
    Playlist(HubMetadata),
    Unknown(HubMetadata),
}

/// Response wrapper for hubs.
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "PascalCase")]
pub struct HubsResponse {
    pub media_container: HubsContainer,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "PascalCase")]
pub struct HubsContainer {
    #[serde(default, rename = "Hub")]
    pub hub: Vec<Hub>,
}

/// Response for stations hub request.
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "PascalCase")]
pub struct StationsResponse {
    pub media_container: StationsContainer,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct StationsContainer {
    #[serde(default, rename = "Hub")]
    pub hub: Vec<StationsHub>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct StationsHub {
    #[serde(default)]
    pub context: Option<String>,
    #[serde(default)]
    pub title: String,
    #[serde(default, rename = "Directory")]
    pub directory: Vec<Station>,
    #[serde(default, rename = "Metadata")]
    pub metadata: Vec<Station>,
}

impl StationsHub {
    /// Get all stations from either Directory or Metadata fields.
    pub fn stations(&self) -> Vec<Station> {
        if !self.directory.is_empty() {
            self.directory.clone()
        } else {
            self.metadata.clone()
        }
    }
}

/// Response for playQueue creation.
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "PascalCase")]
pub struct PlayQueueResponse {
    pub media_container: PlayQueueContainer,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct PlayQueueContainer {
    #[serde(default)]
    pub play_queue_id: Option<u64>,
    #[serde(default)]
    pub play_queue_selected_item_id: Option<u64>,
    #[serde(default, rename = "Metadata")]
    pub metadata: Vec<super::Track>,
}
