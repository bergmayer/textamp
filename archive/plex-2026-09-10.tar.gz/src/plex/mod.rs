//! Plex API, authentication, connection selection, and disk caches.
//!
//! App handlers own loading and refresh orchestration. They use PlexClient
//! and the cache types directly; this module owns no application state.

mod artwork_cache;
mod auth;
mod cache;
mod client;
mod connection;
pub mod constants;
mod error;
pub mod library_directory;
pub mod models;
pub mod remote;
mod spectrogram;
mod waveform;

pub use artwork_cache::ArtworkCache;
pub use auth::{AccountMarker, PlexAuth, PlexClientInfo, ServerInfo, StoredAuth};
pub use cache::{CacheData, CachedFolder, CachedPlaylistTracks, LibraryCache};
pub(crate) use client::station_library_key;
pub use client::{test_connection, test_connection_for_server, PlexClient};
pub use connection::{
    classify_connection, select_connection, ConnectionKind, ConnectionSelection, MeasuredConnection,
};
pub use error::ApiError;
pub use remote::RemotePlayerClient;
pub use spectrogram::{
    generate_spectrogram, generate_spectrogram_from_pcm, SpectrogramCache, SpectrogramData,
};
pub use waveform::{
    generate_waveform, generate_waveform_from_pcm, WaveformCache, WaveformData, WaveformError,
};
pub mod analysis;
