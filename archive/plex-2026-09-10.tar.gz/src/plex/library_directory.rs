//! Small, credential-free directory of saved accounts and music libraries.
//! Unlike the active playback catalog, this survives source switches and outages.
use super::{PlexAuth, PlexClient};
use anyhow::Result;
use futures::{stream, StreamExt};
use serde::{Deserialize, Serialize};

// One ordered directory writer. A cancelled discovery's blocking save must not
// resurrect entries after removal or overwrite a newer refresh.
static REVISION: std::sync::Mutex<u64> = std::sync::Mutex::new(0);

pub fn begin_update() -> u64 {
    let mut revision = REVISION.lock().unwrap_or_else(|e| e.into_inner());
    *revision = revision.wrapping_add(1);
    *revision
}

pub fn save_current(revision: u64, accounts: &[Account]) -> Result<()> {
    let current = REVISION.lock().unwrap_or_else(|e| e.into_inner());
    if *current == revision {
        save(accounts)?;
    }
    Ok(())
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct Library {
    pub server_id: String,
    pub server_name: String,
    pub key: String,
    pub title: String,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct Account {
    pub id: String,
    pub name: String,
    #[serde(default)]
    pub libraries: Vec<Library>,
}

fn path() -> std::path::PathBuf {
    crate::config::XdgPaths::new("textamp")
        .data_dir
        .join("plex-libraries.json")
}

pub fn load() -> Result<Vec<Account>> {
    let cached: Vec<Account> = match std::fs::read(path()) {
        Ok(bytes) => serde_json::from_slice(&bytes)?,
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => vec![],
        Err(error) => return Err(error.into()),
    };
    // The credential store is authoritative for account membership.
    Ok(PlexAuth::saved_accounts()?
        .into_iter()
        .map(|(id, name)| Account {
            libraries: cached
                .iter()
                .find(|a| a.id == id)
                .map(|a| a.libraries.clone())
                .unwrap_or_default(),
            id,
            name,
        })
        .collect())
}

pub fn save(accounts: &[Account]) -> Result<()> {
    Ok(crate::util::private_file::write_private_file(
        &path(),
        &serde_json::to_vec(accounts)?,
    )?)
}

/// Refresh only library metadata, never songs or the active Plex session.
/// Failed servers retain their last known libraries; successful empty responses
/// remove genuinely deleted libraries. Probing and reads have a per-server bound.
pub async fn discover(mut account: Account) -> Result<(Account, Vec<String>)> {
    let id = account.id.clone();
    let stored = tokio::task::spawn_blocking(move || PlexAuth::saved_account(&id)).await??;
    let auth = PlexAuth::from_stored_auth(&stored)?;
    let servers = auth.get_servers(&stored.token).await?;
    let results: Vec<_> = stream::iter(servers.iter().cloned())
        .map(|server| {
            let stored = &stored;
            async move {
                let result = tokio::time::timeout(std::time::Duration::from_secs(25), async {
                    let selection = super::select_connection(
                        &server,
                        &stored.token,
                        &stored.client_identifier,
                        &[],
                    )
                    .await?;
                    let mut client = PlexClient::new(super::PlexClientInfo {
                        client_identifier: stored.client_identifier.clone(),
                        ..Default::default()
                    })?;
                    client.set_auth_token(stored.token.clone());
                    client.set_server(selection.selected.url);
                    Ok::<_, anyhow::Error>(
                        client
                            .get_libraries()
                            .await?
                            .into_iter()
                            .filter(|l| l.is_music())
                            .map(|l| Library {
                                server_id: server.client_identifier.clone(),
                                server_name: crate::util::sanitize_display_text(&server.name)
                                    .into_owned(),
                                key: l.key,
                                title: crate::util::sanitize_display_text(&l.title).into_owned(),
                            })
                            .collect::<Vec<_>>(),
                    )
                })
                .await;
                (server, result)
            }
        })
        .buffer_unordered(3)
        .collect()
        .await;
    let mut warnings = Vec::new();
    account
        .libraries
        .retain(|l| servers.iter().any(|s| s.client_identifier == l.server_id));
    for (server, result) in results {
        match result {
            Ok(Ok(libraries)) => {
                account
                    .libraries
                    .retain(|l| l.server_id != server.client_identifier);
                account.libraries.extend(libraries);
            }
            // Do not expose URLs/tokens from external error bodies in the manager.
            _ => warnings.push(format!(
                "{}: unavailable; saved libraries kept",
                server.name
            )),
        }
    }
    account
        .libraries
        .sort_by_key(|l| (l.server_name.to_lowercase(), l.title.to_lowercase()));
    Ok((account, warnings))
}
