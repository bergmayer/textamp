# textamp

textamp is a terminal music player for Plex, Navidrome, and plain folder libraries.
It gives you fast keyboard access to a large music library.
You can also use a mouse.

## Symbol shortcuts

These keys give quick access to the main commands:

| Key | Function |
|---|---|
| `/` | Filter the focused column. |
| `:` | Open the command palette. |
| `,` | Open Settings. |
| `\` | Change the Miller-column layout. |
| `|` | Show Library and Now Playing in a tall split. |
| `<` | Play the previous track. |
| `>` | Play the next track. |

To quit, type `:q` and press Enter. Quit is the first result for `q` or `Q`.

## Main functions

- Browse music by artist, album, playlist, tag, or folder.
- Play audio locally or on a Plex player.
- Search, filter, and manage a queue.
- Use radio, DJ modes, remix tools, and Sonic Adventure where the library supports them.
- Show album art, artist information, and audio visualizers.
- Search Apple Music, Spotify, or YouTube for selected music.

Ordinary Navidrome radio uses its catalog. Sonic functions require Plex analysis
and Plex Pass, or the corresponding Navidrome/AudioMuse analysis support, and must
be enabled for that library. Plex player discovery and casting are Plex-only;
Navidrome and folder libraries play locally.

## Requirements

- A local folder, a WebDAV folder, a Navidrome account, or a Plex account and music server
- A color terminal

For high-quality album art, use a terminal with Kitty, Sixel, or iTerm2 graphics.
textamp can also draw art with half blocks or Braille characters.

## macOS launcher

The optional `packaging/macos/Textamp.app` launcher can sit beside the `textamp`
executable in `~/Applications`. Double-click **Textamp.app** to run the current
binary in a new Ghostty window, even when Ghostty is already running.
Ghostty must be installed at `/Applications/Ghostty.app`. The launcher does not
change your terminal defaults or Ghostty configuration.

## Browse music

The main screen uses Miller columns.
Each column shows the child items of the selection in the preceding column.
Press `\` to select one of these layouts:

- Shrink all columns to fit the screen.
- Keep each column at half of the terminal width and scroll horizontally.

Press `|` to show Library above Now Playing in a tall split.

For Plex, the Folders section uses the Plex library folder structure.
Use it for music that does not have useful tags.

## Libraries and accounts

Textamp opens your last selected library in the normal app interface.
Use **F3** for a compact library switcher; Enter opens the selected library and
Esc cancels. Add and manage libraries in **F2 → Settings → Libraries** (also
available by pressing F2 from the switcher). Opening either does not stop playback.
Local folders, WebDAV, Plex, and Navidrome can coexist. Folder names are editable;
their stable identities do not change when renamed. Plex libraries display their
server and account in the details panel. Saved Plex libraries are retained locally
and refreshed in the background for every saved account, even when using folders
or Navidrome. An unavailable server does not erase its saved libraries. Discovery
reads library metadata only, not the music catalog. Selecting a Plex library
connects its own account automatically. Credentials stay in their private stores.

In Settings → Libraries:

- `Tab` / `Shift+Tab`: move between the settings sidebar and its content.
  Arrows follow the visible order without wrapping:
  **sidebar ↔ Libraries ↔ Accounts ↔ Add library**. From Add library, Left goes
  to Accounts, then Libraries, then the sidebar. Up/down selects rows or sidebar
  sections; Enter opens the selection. Tabs can also be clicked.
  `[Active]` marks the playing library; highlighting a row does not switch it.
  The Libraries list contains playable sources, not setup commands;
  Accounts holds saved Plex/Navidrome sign-ins. Enter opens an account dialog with
  **Sign out** and **Cancel** buttons; it does not switch the playing library.
- **Add library** offers Local, WebDAV, Plex, and Navidrome separately.
  WebDAV uses one form for URL, username, masked password and optional name.
  Add checks the connection before saving; failures stay in the form so you can
  correct them. Esc/Cancel discards the draft and cancels an ongoing check.
  Duplicate connections are rejected, including edits that would duplicate another
  entry. WebDAV/Navidrome identity uses the server URL and username, not the
  display name or password; local folders are compared by resolved path. Different
  accounts and different folder roots remain separate libraries.
- `W`: add WebDAV; `P`: connect Plex; `F5`: refresh Plex discovery.
- `A`: add an absolute local path (`~/Music` also works), or a WebDAV `https://host/path/` URL.
- `R`: rename the highlighted folder library.
- `N`: add a Navidrome account: server URL, username, then masked password.
  Server URLs may include a reverse-proxy path. Use HTTPS outside trusted networks.
  A single-folder account shows just its named library. “All music” is an aggregate
  offered only alongside multiple folders (or before folder discovery completes).
  `R` renames the account label; `C` replaces its credentials; `Delete` removes
  the saved account without deleting anything on the server.
- `C`: edit the selected WebDAV library in the same form, or replace Navidrome
  credentials. A blank password in the WebDAV edit form keeps the saved password;
  clear the username to use anonymous access.
- `Delete`: remove a folder library after confirmation. Music files are never
  deleted. To sign out of Plex or Navidrome, use Accounts → Enter → Sign out.
  Only that account's saved access is removed; other accounts are retained.
- `Enter`: open the highlighted library or account dialog. Arrow and page keys scroll the list;
  a first mouse click only highlights and preserves the viewport.

Folder libraries browse lazily, with directories first and natural filename
ordering (`2` before `10`). Enter on a file queues the folder's audio files and
starts at that file. Queue, enqueue/next, shuffle, pause, seeking, volume,
external music searches, and visualizers reuse the normal player. `/` filters
the current column; `F5` reloads it. There is no recursive catalog scan or
library-wide search for these sources. Symlinks are omitted from listings.

Embedded tags supply playback metadata, duration when available, and cover art.
`F4` shows the provider's artist biography, falling back to Wikipedia when it is
missing or unavailable. Folder libraries use the playing track's embedded artist
tags (the highlighted track in Queue); directory names are never guessed.
Wikipedia matching requires an exact artist name/alias and musical-artist identity
in Wikidata, then verifies the linked article. Ambiguous same-name musicians are
not automatically selected. Lookups are English-only and on demand; the artist
name is sent to Wikimedia, not your file paths or library credentials.
Articles display as clean paragraphs, headings and lists, with up to eight photos.
Use `↑↓` to scroll, `←→` for photos, and `B` to open the credited source article.
Text and image credits appear at the end. Unmatched artists show an explanation.
There is no custom biography sidecar format.

Filename order is independent of tags. Folder sources offer Library and Random
Album Radio, but not sonic analysis, server playlists, or Plex casting.
No music is sent to an online analysis service.

WebDAV is the supported remote-file transport. It requires
the canonical collection URL and does not follow redirects. Use HTTPS outside
trusted networks; HTTP sends credentials without transport encryption.

Remote audio downloads to a private temporary file before playback (2 GiB and
120-second transfer limits). It is removed when its last playback/analysis
consumer releases it. This supports normal seeking but is **not progressive
remote streaming or offline caching**. Local audio is decoded directly from disk.
Waveform/spectrogram generation has size limits; live meters/spectrum do not
require whole-file analysis.

Configuration remains TOML. Advanced source options:

```toml
default_folder_source = "home"

[[folder_sources]]
id = "home"
name = "Local Music"
kind = "local"
path = "/Users/me/Music"

[[folder_sources]]
id = "dav"
name = "WebDAV Music"
kind = "webdav"
url = "https://music.example/dav/"
username = "music"
# password_env = "DAV_PASSWORD" # optional environment override
```

Saved passwords live separately in `folder-credentials.toml` in Textamp's data
directory, and saved Plex credentials in `accounts/`. These are private files
(0600 on Unix), not encrypted keychain storage. Passwords are excluded from
configuration, URLs, track identities, and diagnostic formatting. Existing
`auth.toml` installations are compatible. New Plex view preferences are scoped
by account/server/library; legacy unscoped preferences remain read-only defaults.

See [library architecture and future integrations](docs/LIBRARY_SOURCES.md) for
the extension boundaries, free metadata alternatives, and verification scope.

Background refresh failures keep existing data and show a status message,
not an error dialog. Category loads run two at a time, with the visible section
first in the queue. Temporary failures retry after 30 seconds and then 2 minutes;
after that, use `F5` to retry the current section. `F5` also bypasses the wait.
Album and track listings load in pages. A failed or incomplete load does not
replace the cache. A slow category refresh triggers route recovery only if a
separate connectivity check also fails; reconnecting does not mark failed data fresh.
Search and cache-write failures display an error. An incomplete folder crawl
keeps unseen cached folders; the existing age and manual-clear settings still apply.

### Main shortcuts

Use `F1` or `Ctrl+H` for the complete shortcut list.

| Key | Function |
|---|---|
| `Tab` / `Shift+Tab` | Change between Library and Now Playing; switch keyboard focus in split mode. |
| `Ctrl+L` | Open Library. |
| `Ctrl+G` | Open Album Genres. |
| `Ctrl+O` | Open Folders. |
| `Ctrl+U` | Open Queue. |
| `Ctrl+N` | Open the Now Playing visualizer. |
| `Ctrl+F` | Search the library (current-folder files for Local/WebDAV). |
| `Ctrl+P` | Open the command palette. |
| `F2` | Open Settings. |
| `F3` | Switch library (F2 from the picker opens library settings). |
| `F4` | Show information about the selected artist. |
| `F5` | Refresh the current section. |
| `F6` / `Ctrl+V` | Change the sort or view options. |
| `Alt+R` | Start Random Album Radio (same station as the Radio menu); local/WebDAV albums are leaf folders. |

In split mode, only the active pane shows focused borders and selection styling.
Click a queue row, artwork, or the visualizer to give it keyboard focus; scroll
the pane under the pointer without changing keyboard focus. Text dialogs capture
input and cannot click through to the player. Help scrolling uses its actual
wrapped content and available height, including in split mode.

The filter stays with the column that had focus when you started it.

Letter keys jump to titles.
The jump ignores an initial `The`.
`Shift` plus a letter matches the second letter of the title.

An album or playlist track list starts with a Play row.
Press `Enter` on this row to play the complete list.

Opening a track shows its details and related commands.
A mouse click selects an item without changing the scroll position.

## Queue and playback

`Ctrl+E` adds a selection to the end of the queue.
`Ctrl+Shift+E` puts it after the current track.

| Key | Function |
|---|---|
| `Space` | Play or pause. |
| `Shift+Left` / `Shift+Right` | Move by 10 seconds. |
| `Delete` | Remove selected queue tracks. |
| `Shift+Up` / `Shift+Down` | Move selected queue tracks. |
| `Ctrl+S` | Save the queue as a Plex or Navidrome playlist. |
| `Ctrl+X` | Clear the queue. |
| `Ctrl+Z` | Undo the last queue edit or remix. |
| `v` | Start a new multiple selection. |
| `V` | Add to the current multiple selection. |

The Now Playing view has Waveform, Spectrum, Spectrogram, Vectorscope,
Spectral Landscape, and Studio Meters. Press `Up` to focus the tab bar, then
`Left` / `Right` to switch modes, or click a tab. Narrow panes use shorter labels.

Spectral Landscape draws a receding wireframe of the last 12 seconds using
the existing spectral cache. Studio Meters show sampled local PCM RMS, sample
peaks, 1.5-second peak holds, stereo correlation, and a short RMS history.
These are pre-volume readings, not LUFS, true peaks, or hardware-output levels.
Meters require local playback; remote Plex players do not supply PCM.
The meter bars show RMS as solid fill, sample peaks as a thin line, and held
peaks as a vertical mark, on a −60 to 0 dBFS scale. The unlabelled rail below
them shows stereo correlation from −1 (left) to +1 (right); silence has no marker.

Click or drag the waveform or transport scrubber to seek. A drag can start
anywhere on the bar and keeps its scale when the pointer leaves the row.
Uncached tracks reopen the stream and decode forward in the background, so
seeking may briefly rebuffer (longer on slow connections or long tracks).
Pause is preserved. Landscape and Meters canvases do not seek; their transport
scrubber still does.

## Radio and discovery

Radio supplies a continuous queue. Selecting a station keeps the current music
and queue until the source returns replacement tracks. Failed or empty requests leave
that queue intact. The palette’s **Stop Playback** command cancels a pending
station start; Play/Pause also cancels it before toggling the current music.
Refills do not skip the current track. If the source returns no new tracks, use Next
to retry or choose another station.
Available stations include Library, Deep Cuts, Time Travel, and Random Album.
Mood, Style, and Decade open station choices in the palette. Choose
`Radio: Back` to return to the parent list, or press Esc to close it.
DJ Modes and Remix Tools are available from both Queue and Now Playing.
On This Day requires albums with matching release dates.
You can also select a mood, style, or decade.

DJ modes add tracks while the queue plays.
They use sonic similarity, artist relationships, or release dates.
Only one DJ mode can be active.

Remix tools change the current queue one time.
They can add related tracks, replace tracks, or shuffle the queue.
Partial lookup failures are reported without discarding successful changes.
Use `Ctrl+Z` to undo a remix.

Sonic Adventure makes a path between two selected tracks.
Artist Radio can combine two or more artists.

| Key | Function |
|---|---|
| `Ctrl+M` | Show similar music. |
| `Ctrl+R` | Show related artists. |
| `Ctrl+J` | Open the current track or album in Library. |

The command palette contains other radio and discovery commands.
It also contains the Apple Music, Spotify, and YouTube searches.
On macOS, Apple Music search uses the Music app's catalog search controls.
macOS may ask you to allow your terminal to control Music
and System Events under Privacy & Security → Automation, and to enable
Accessibility for that host app. Textamp does not change these permissions.
If native search is unavailable, it opens Apple Music's US web search instead.
Search handoffs run in the background with a timeout; no clipboard contents
are replaced. Other platforms use web search directly.

## Plex metadata

Plex does not keep Artist and Album Artist as separate fields.
When possible, textamp uses track-artist names as aliases.
Search, filters, radio, and Sonic Adventure recognize these aliases.

Artists appearing only on Plex compilation albums are listed under Compilations.

Album Genres and Artist Genres are separate because Plex supplies them that way.
Moods and Styles come from Plex analysis data.


## Fast local browsing cache

All library types retain metadata locally. Opening a saved library uses cached
data first; a failed refresh leaves the previous data usable. The first visit
still needs access to the source. This is a browsing cache, not offline music
downloads or a recursive folder scan.

| Library | Cached data | Automatic refresh |
|---|---|---|
| Plex | Library/category and folder caches | Weekly; unopened subfolders on next visit |
| Navidrome | Artists, albums, tracks, genres, playlists and supported extensions | Weekly |
| AudioMuse | Analysis metadata for tracks in the selected Navidrome library | Weekly, after the catalog is available |
| Local folder / WebDAV | Each visited directory listing | Weekly on opening; visible directory also checked while running |

While Textamp runs, hourly timestamp checks refresh metadata only when it is at
least a week old. Opening a library or directory also checks its cache age.
Inactive libraries refresh when next opened, not through a background daemon;
folder libraries are never recursively scanned by this schedule. Artwork, audio,
and waveform caches retain their separate on-demand/eviction policies. Refreshing
AudioMuse downloads existing server analysis; it does not start an analysis scan.

**F5** bypasses the cache and refreshes the current folder or Navidrome catalog.
After a failed Navidrome refresh, F5 retries; navigation does not start a retry loop.
**Settings → Cache** shows the current source's metadata-cache size and offers
clear-and-reload for all library types. Clearing removes cached metadata, not
music files, library settings, or credentials.

Non-Plex snapshots live under the XDG/platform cache directory in `sources/`,
with private permissions and atomic writes. They are separated by provider,
source/account identity, server/root, username, and selected library/path. Renaming
a library retains its cache. Invalid cache files are logged and fetched again.
Only complete successful responses replace saved snapshots, including legitimate
empty results. Snapshots are streamed through gzip, with a 512 MiB compressed disk
budget and an 8 GiB expanded-data safety limit. This supports catalogs larger than
the former 256 MiB JSON limit without creating a second serialized copy in memory.
Legacy JSON caches remain readable and migrate on refresh. Old snapshots are
evicted as needed. Plex retains its existing cache storage.

## Navidrome

Navidrome uses its standard OpenSubsonic API, independently of Plex authentication.
Multiple accounts on the same or different servers are supported. The last selected
account/library is remembered. Passwords are stored in the private application-data
file `navidrome-credentials.toml` (0600 on Unix), not in config, track IDs, or logs.
Requests use salted Subsonic authentication; this is not a substitute for HTTPS.

Artists, albums, genres, tracks and playlists use the usual browsing, search,
queue, shuffle, artwork, biography, streaming, seeking, and visualizer controls.
Metadata is loaded with bounded pagination into a persistent, cache-first catalog;
`F5` refreshes it. A failed refresh leaves the previous catalog usable. Saved metadata
can be browsed while the server is unavailable; streaming still requires the server.
Interrupted metadata reads retry once, while server mutations are never retried.
This is not an offline download manager. “Folders” shows an artist/album virtual
tree, **not the server's disk directories**, matching Navidrome's API model.
Albums play in disc/track order; playlists preserve server order. Playlists and
saved playback queues are account-wide and may include songs from several libraries.

The left sidebar separates native system lists from saved playlists with dividers:
**Recently played albums**, **Recently added albums**, **Most played albums**, and
**Favorite songs/albums/artists** appear above your saved playlists. The album
history lists show the first 100 results in Navidrome's order. Favorites use the
account's actual stars, not imported playlists with similar names. These system
lists are fetched on opening; `F5` refreshes the open list. They cannot be renamed,
deleted, or replaced like a saved playlist. In Library, `F5` refreshes the catalog,
including playlist deletions made in another client. Sidebar arrows skip labelled headings;
the mouse wheel scrolls long lists without changing keyboard focus.

`Ctrl+G` browses **album genres → albums → tracks**. All of Navidrome's structured
genre tags are included, not just its legacy first-genre field. These are library
metadata, not AudioMuse predictions. Sorting ignores case; names are preserved (no guessed splitting
of names such as “R&B / Soul”). Plex-only artist-genre, mood, and style sections are
not offered for Navidrome; sonic recommendations use the separate server capability.

Use the sidebar for favorites, album-history lists, and AudioMuse browse categories;
these destinations are not duplicated in the command palette. Use `:` to favorite
or unfavorite a selection, rate songs, show lyrics, generate a 100-song random mix,
and save/restore the server playback queue. AudioMuse's **Describe music…** and
**Search lyrics…** remain search actions in the palette. Restoring
a queue starts playback at its saved song and position. In Playlists, the palette
also offers rename, delete, and replacement with the current queue; destructive
changes require confirmation. `Ctrl+S` creates a new playlist from the queue.
Server permissions and read-only/smart-playlist restrictions remain authoritative.

Playback reports update Navidrome play history. Its biographies take precedence
over the Wikipedia fallback. Recommendations use the server's similarity results;
continuous stations use the same Radio controls as Plex. Album/artist selection
and tag filtering are implemented in a shared, network-free
catalog service; provider adapters supply data and sonic requests. Library, Random Artist,
Random Album, Deep Cuts (least-played tracks), Time Travel, Decade and selected-artist
radio use the selected catalog. Random albums retain disc/track order and radio
refills avoid tracks already queued. Mood Radio uses album mood tags and also
offers the connected AudioMuse server's available mood centroids, clearly labeled;
Style / Genre Radio uses the server's genre tags, not Plex's separate style taxonomy.
On This Day requires full release dates (local date when available, UTC otherwise).
Missing metadata produces an explanation, never unrelated random music.

Sonic Radio continues the current song without restarting it, then plays sonic
recommendations instead of the previous upcoming queue. From any track's `:`
palette or right-click menu, choose **Start Sonic Radio based on track**. A different
selected track plays first; selecting the current track preserves its position
and paused/playing state. Failed discovery leaves playback and the queue alone;
stopping or switching tracks while continuation is loading cancels the pending switch.
If the song ends before discovery completes, playback waits for the results
instead of advancing the old queue. Pausing does not cancel the continuation.
The action is hidden for libraries without enabled sonic analysis.
Random Artist Radio chooses only artists with at least **25 distinct tracks in
the selected library**. Explicit artist radio and Artist Mix have no such minimum.

All six DJ modes and four sonic/artist remixes are available. Twofer and Contempo
use artist/year metadata; Groupie and Artist Mix use server artist similarity.
Gemini, Freeze, Stretch, Doppelganger, Album Mix, Sonic Radio and Sonic Adventure
prefer the advertised OpenSubsonic `sonicSimilarity` extension, with the library's
direct AudioMuse connection as a fallback when the extension is missing, fails,
or returns no usable matches. Artist Mix/Groupie prefer server artist affinity,
with analyzed seed-track affinity as a fallback. Results are restricted to exact
IDs in the selected library. Paths must preserve endpoints, order, and scope.
An unavailable/incomplete analysis index produces an explanation, not random
music passed off as a sonic match; ordinary stations still work.
Textamp does not install/configure AudioMuse-AI or start analysis jobs. Failed
radio startup leaves the old queue playing; stale DJ/remix results are discarded.

Keyboard shortcuts, the Radio palette and Now Playing select the same provider's
stations. `Ctrl+S` saves the active queue or radio station as a playlist in Plex
or Navidrome, not a hidden inactive queue. Plain local/WebDAV libraries hide
server-only discovery and playlist commands, but support Library Radio and Random
Album Radio. Random Album chooses a playable bottommost folder and keeps every
file in natural filename order. Library Radio also includes loose parent files.
Discovery only reads directory listings, reusing the persistent browser cache;
it does not scan tags or download audio. It samples random branches, not uniformly
across all albums (which would require indexing the whole tree). Each request
visits at most 256 directories, with a 30-second deadline; choose a smaller root
if the tree is too sparse. Exhausted stations can be restarted to replay albums.
Plex player discovery/casting appears
only with Plex; streaming-quality controls appear with Plex and Navidrome.

**Per-library sonic features:** in **F2 → Libraries → Libraries**, highlight a
Plex or Navidrome library and click **Sonic features** or press **I**. The saved
toggle controls whether analysis-dependent features are shown and attempted for
that library. Turning it off hides sonic similarity/Adventure, Gemini/Freeze/
Stretch DJ modes, sonic remixes and sonic stations, including the track-details
similarity pane. Ordinary radio, Twofer/Contempo/Groupie, metadata browsing,
biographies and all visualizers remain available. Pending sonic results are
invalidated without stopping the current song. The preference is independent for
each account/server/library (including Navidrome's All music selection); existing
libraries default to On. On permits requests but does not mean analysis is ready.
Folder libraries do not show this toggle or these sonic features.

All local-output visualizers work independently of the library provider. Waveform
and spectrogram analysis decode one packet at a time, coarsening time summaries
for long recordings instead of retaining whole-track PCM. Studio meters and the
vectorscope sample the playback decoder; they need no server-side sonic analysis.
Folder analysis waits for the local/WebDAV file to finish preparing.
Availability of biographies, recommendations, lyrics and sonic analysis depends on
the server's metadata and configured integrations.

Protocol references: [Navidrome compatibility](https://www.navidrome.org/docs/developers/subsonic-api/)
and [OpenSubsonic sonic similarity](https://opensubsonic.netlify.app/docs/extensions/sonicsimilarity/).

### Direct AudioMuse discovery

In **Settings → Libraries**, select a Navidrome library and click **Connect
AudioMuse…** (or press **M**). Enter the AudioMuse URL, username, password and the
music-server name configured in AudioMuse. **Save** checks the connection;
**Disconnect** removes only Textamp's analysis connection. Credentials are stored
privately in `audiomuse-credentials.toml`, not in the configuration or cache.
Each binding belongs to the selected account and music folder.

The left sidebar groups ordinary browsing and Navidrome system lists together
under **browse**, followed by **audiomuse** and **playlists** (Plex also labels its pinned playlists). All
library types have a **Search…** entry above **browse**, with no outer sidebar title.
Highlighting it shows the theme-colored Textamp logo and “press enter for search”
in the content pane, without discarding your browsing position. Arrowing
past a search entry does not open it; press Enter/Right or click to activate.
For local/WebDAV libraries this searches audio filenames in the current folder;
`/` still filters the folder list, including directory names, without scanning the share.

In **Settings → Textamp**, highlight a theme to preview the logo in its colors on
the right; press **Enter** to apply it. Narrow windows keep the settings list usable
and omit the preview. The **About** screen retains the logo's original colors.

**Settings → Sections** shows visibility checkboxes relevant to the current library
type, including each Navidrome system list and connected AudioMuse view. Select
**Favorite artists** and press **Enter** or **Space** to hide it. These preferences
persist across restarts and apply to libraries of that type; they do not remove
favorites or playlists from the server. Re-enable a hidden collection here to browse
it again; it does not appear as a command-palette shortcut. Arrow keys and
Page Up/Down scroll long checkbox lists.

The AudioMuse group offers **AI labels**, **Tempo**, **Energy**, **Musical key**,
**Analyzed tracks**, **Describe music…**, and **Search lyrics…**. The first five
use a persistent analysis cache on the same weekly schedule as library metadata.
The initial load fetches metadata
in pages with visible progress and a preview of the first matching page, and
**F5** also refreshes it immediately. Switching views does not
restart the shared import; it can finish and save while you browse elsewhere.
Updates compare server fingerprints and fetch only changed
tracks, without downloading embeddings or audio. An ongoing scan can supply
partial results; tracks without analysis are not classified. Disabled or empty
CLAP/lyrics indexes produce a clear explanation rather than an unrelated search.

For a local visibility check, `cargo run --example audiomuse_check -- --sidebar`
reports which AudioMuse entries the saved Navidrome configuration exposes, without
contacting either server. This check currently requires one saved Navidrome account.

Inferred labels remain separate from **Album Genres**, which still uses file-tag
metadata. MusiCNN labels include styles, moods, instruments and other descriptors;
Textamp does not pretend they are all genres, probabilities, or album-wide facts.
Zero-filled model outputs are omitted. Tempo groups are under 90, 90–119, 120–159,
and 160+ BPM; energy groups divide the normalized 0–1 range into thirds.
The **AudioMuse analysis** command in the palette shows the selected track's
labels/scores, BPM, energy and key.

Results resolve through exact Navidrome IDs in the current library's catalog and
use the existing track navigation, queue and playback. Search ranking is preserved;
results outside the selected library are omitted. If AudioMuse translates a
requested ID to a different duplicate file,
Textamp omits that ambiguous result (or retains previously verified cached analysis)
and reports unmatched IDs; it does not guess from titles. No server playlist is created
unless you explicitly save the queue. AudioMuse failures do not stop music.
Disabling the library's **Sonic features** hides AudioMuse discovery and cancels
its pending requests. The connection can still be managed in Settings.

Textamp does not start/restart scans, change AudioMuse settings, modify file tags,
or access AudioMuse's database. Sonic similarity, paths, and mood stations can use
AudioMuse directly as well as Navidrome's plugin. Direct discovery uses authenticated JSON
APIs and requires its server-scoped analysis export (`/api/sync`).

Read-only live check: `cargo run --example audiomuse_check -- --sync`.
This checks the saved connection and refreshes its local analysis cache; it does
not start audio or create playlists. Protocol tests: `cargo test --test audiomuse`.
Use `--sonic` instead of `--sync` to check live mood, similarity and path queries
without refreshing the local analysis cache or starting a scan.

## Provider boundaries

The UI and shortcuts emit shared actions; providers resolve their own library
IDs and return normalized tracks. Queue state, navigation, local playback and
visualizers are shared. Navidrome requests live in `src/app/sources/navidrome`,
with HTTP transport in `src/navidrome`; Plex transport lives in `src/plex`.
`src/library/capabilities.rs` declares backend operations; the shared station catalog,
command visibility, DJ controls, and output settings consume those declarations.
The per-library sonic preference and server readiness are separate from support.
`src/app/sources::route` is the central backend boundary; `routing.rs` prevents
unhandled library requests from falling through to Plex. Account management remains independent
of the active library so you can add Plex while listening to Navidrome.

See the [provider-boundary review](docs/provider-boundary-review-2026-09-07.md)
for the earlier audit, and the [radio/capability review](docs/radio-capabilities-2026-09-07.md)
for this refactor, the backend integration contract, parity and verification scope.

## Engineering checks

```sh
cargo build --release --bin textamp
cargo test
cargo fmt --all -- --check
cargo clippy --all-targets -- -D warnings
```

Read-only checks against the saved default Navidrome account:
`cargo run --example navidrome_check`. Add `-- --audio` for muted native playback,
pause and seeking; `-- --catalog` checks full catalog loading and genre navigation.
`-- --sonic` makes one similarity probe. These checks do not modify playlists,
ratings, play history, or analysis jobs. The explicit `--add URL USERNAME` option
saves an account locally, reading the password from stdin (disable terminal echo
first); normal checks use the private credential store.

Navidrome protocol/state tests run in `cargo test --test navidrome` using isolated
HTTP fixtures. The two ignored live tests and
`tests/fixtures/navidrome_tui_smoke.py` require a dedicated Navidrome on
`127.0.0.1:14533`, account `fixture` / `fixture-password`, and exactly two silent
18-second tracks (artist `Fixture Artist`, album `Fixture Album`, titles
`First Song` and `Second Song`). Never point these tests at a personal server:
they create/delete a test playlist and change fixture favorites, ratings, play
history, and the saved queue. The native test also requires an audio device.
The PTY smoke uses temporary configuration, credentials, logs, and caches.

Read-only live Plex checks: `cargo run --bin textamp-test-tui`.
Add `-- --server-only` to check the saved media-server connection without
contacting the Plex account endpoint. The test does not play or scrobble music.
Use `-- --server-only --random-album-radio` to check Random Album Radio from
palette selection through station loading, plus Mood/Style/Decade choices
and Back navigation, without starting playback.

Audio-device smoke test: `cargo run --example audio_smoke`. It is silent;
add `-- --audible` to hear the test tone. It checks pause, resume, seek,
and natural completion. Add `-- --stream` for a silent loopback-HTTP test of
forward/backward streamed seeking, paused seeking, completion, and cancellation;
it needs an audio device but no Plex server or credentials.

See [ENGINEERING_REVIEW.md](ENGINEERING_REVIEW.md) for the review, complexity
measurements, and verification limits.

## License

textamp uses the Unlicense.
See `LICENSE`.
