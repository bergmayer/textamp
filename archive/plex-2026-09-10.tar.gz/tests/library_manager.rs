use crossterm::event::{KeyCode, KeyEvent, KeyModifiers, MouseButton, MouseEvent, MouseEventKind};
use ratatui::{backend::TestBackend, Terminal};
use textamp::app::action::SearchAction;
use textamp::app::handlers::{key_input, mouse_input};
use textamp::app::sources::{self, manager, ActiveSource, LibraryChoice, SourceAction};
use textamp::app::state::{SettingsFocus, SettingsSection, View};
use textamp::app::{Action, AppState};
use textamp::config::Config;
use textamp::library::{FolderLocation, FolderSource};
use textamp::plex::library_directory::{Account, Library};

fn account(id: &str, title: &str) -> Account {
    Account {
        id: id.into(),
        name: format!("Account {id}"),
        libraries: vec![Library {
            server_id: "server".into(),
            server_name: "Server".into(),
            key: "1".into(),
            title: title.into(),
        }],
    }
}
fn config() -> Config {
    Config {
        folder_sources: vec![FolderSource {
            id: "beatles".into(),
            name: "Beatles".into(),
            location: FolderLocation::Webdav {
                url: "https://example.test/".into(),
                username: Some("listener".into()),
                password_env: None,
            },
        }],
        navidrome_sources: vec![textamp::navidrome::Source {
            id: "nav".into(),
            name: "Navidrome account".into(),
            url: "https://nav.test/".into(),
            username: "listener".into(),
            libraries: vec![],
        }],
        default_navidrome: Some(textamp::navidrome::Selection {
            source_id: "nav".into(),
            folder: None,
        }),
        ..Default::default()
    }
}
fn press(state: &mut AppState, key: KeyCode) -> Vec<Action> {
    key_input::handle_key(KeyEvent::new(key, KeyModifiers::NONE), state, &config())
}

fn open_settings(state: &mut AppState) {
    state.set_view(View::Settings);
    state.settings_state.section = SettingsSection::Libraries;
    state.settings_state.focus = SettingsFocus::Content;
}

#[test]
fn tab_and_backtab_leave_library_content_and_reach_every_settings_section() {
    let mut state = AppState::new();
    manager::initialize(&mut state, &config());
    open_settings(&mut state);
    for tab in manager::Tab::ALL {
        manager::select_tab(&mut state, tab);
        press(&mut state, KeyCode::BackTab);
        assert_eq!(state.settings_state.focus, SettingsFocus::Sections);
        for section in SettingsSection::all() {
            assert_eq!(state.settings_state.section, *section);
            press(&mut state, KeyCode::Tab);
            assert_eq!(state.settings_state.focus, SettingsFocus::Content);
            press(&mut state, KeyCode::BackTab);
            assert_eq!(state.settings_state.focus, SettingsFocus::Sections);
            press(&mut state, KeyCode::Down);
        }
        state.settings_state.section = SettingsSection::Libraries;
        press(&mut state, KeyCode::Tab);
        assert_eq!(state.sources.manager_tab, tab);
    }
}

#[test]
fn active_marker_is_visible_before_a_long_name_and_not_the_highlighted_row() {
    for width in [40, 80, 140] {
        let mut state = AppState::new();
        manager::initialize(&mut state, &config());
        open_settings(&mut state);
        state.sources.folders[0].name = "A very long library name which will be clipped".into();
        state.sources.active = ActiveSource::Folder("beatles".into());
        state.popups.library_picker_index = 1;
        let mut terminal = Terminal::new(TestBackend::new(width, 24)).unwrap();
        terminal
            .draw(|frame| {
                textamp::ui::render(frame, &state);
            })
            .unwrap();
        let text: String = terminal
            .backend()
            .buffer()
            .content
            .iter()
            .map(|cell| cell.symbol())
            .collect();
        assert!(text.contains("Active: A"));
        assert!(text.contains("[Active] A"));
        assert!(
            !text.contains("> [Active]"),
            "highlight must not imply activation"
        );
    }
}

#[test]
fn sole_navidrome_folder_has_one_named_choice_in_settings_and_switcher() {
    let mut config = config();
    let source = &mut config.navidrome_sources[0];
    source.libraries = vec![textamp::navidrome::MusicFolder {
        id: "1".into(),
        name: "Music Library".into(),
    }];
    let session = sources::navidrome::Session {
        client: textamp::navidrome::Client::new(source, "fixture".into(), None).unwrap(),
        source: source.clone(),
        extensions: Default::default(),
    };
    assert_eq!(session.client.folder.as_deref(), Some("1"));
    let mut state = AppState::new();
    manager::initialize(&mut state, &config);
    state.sources.active = ActiveSource::Navidrome(Box::new(session));
    for popup in [false, true] {
        state.popups.library_picker_active = popup;
        let choices = sources::choices(&state);
        let nav: Vec<_> = choices
            .iter()
            .filter(|c| matches!(c, LibraryChoice::Navidrome { .. }))
            .collect();
        assert_eq!(nav.len(), 1);
        assert!(nav[0].label().starts_with("Music Library"));
        assert!(nav[0].active(&state));
    }
    state.sources.navidrome[0]
        .libraries
        .push(textamp::navidrome::MusicFolder {
            id: "2".into(),
            name: "Other".into(),
        });
    assert_eq!(
        sources::choices(&state)
            .iter()
            .filter(|c| matches!(c, LibraryChoice::Navidrome { .. }))
            .count(),
        3
    );
}

#[test]
fn startup_keeps_the_normal_interface_and_an_independent_provider_directory() {
    let mut state = AppState::new();
    manager::initialize(&mut state, &config());
    manager::receive(
        &mut state,
        0,
        Ok(vec![account("one", "Music"), account("two", "Music")]),
        String::new(),
        true,
    );
    let entries = sources::choices(&state);
    assert!(!state.popups.library_picker_active);
    assert!(state.active_library.is_none());
    assert!(!state.library_loading);
    assert_eq!(entries.len(), 4);
    assert_eq!(
        entries
            .iter()
            .filter(|c| matches!(c, LibraryChoice::SavedPlex { .. }))
            .count(),
        2
    );
    assert!(!entries
        .iter()
        .any(|c| matches!(c, LibraryChoice::AddFolder | LibraryChoice::ConnectPlex)));
    state.sources.active = ActiveSource::Folder("beatles".into());
    state.libraries.clear();
    state.available_servers.clear();
    assert_eq!(
        sources::choices(&state).len(),
        4,
        "directory survives unrelated player state"
    );
    open_settings(&mut state);
    press(&mut state, KeyCode::Right);
    assert_eq!(state.sources.manager_tab, manager::Tab::Accounts);
    assert_eq!(sources::choices(&state).len(), 3);
    press(&mut state, KeyCode::Right);
    assert_eq!(state.sources.manager_tab, manager::Tab::Add);
    assert_eq!(sources::choices(&state).len(), 4);
}

#[test]
fn refresh_preserves_selection_and_rejects_superseded_results() {
    let mut state = AppState::new();
    manager::initialize(&mut state, &config());
    state.sources.directory_request = 4;
    state.popups.library_picker_index = sources::choices(&state)
        .iter()
        .position(|c| matches!(c, LibraryChoice::Folder(_)))
        .unwrap();
    manager::receive(
        &mut state,
        4,
        Ok(vec![account("one", "A new library")]),
        String::new(),
        false,
    );
    assert!(matches!(
        sources::choices(&state)[state.popups.library_picker_index],
        LibraryChoice::Folder(_)
    ));
    manager::receive(&mut state, 3, Ok(vec![]), String::new(), true);
    assert_eq!(state.sources.accounts.len(), 1);
    manager::receive(&mut state, 4, Err("offline".into()), String::new(), true);
    assert_eq!(state.sources.accounts.len(), 1);
    assert!(state.sources.directory_status.contains("offline"));
}

#[test]
fn manager_owns_navigation_and_refresh_keys_instead_of_the_underlying_view() {
    let mut state = AppState::new();
    manager::initialize(&mut state, &config());
    open_settings(&mut state);
    for key in ['a', 'p', 's', 'n'] {
        assert!(key_input::handle_key(
            KeyEvent::new(KeyCode::Char(key), KeyModifiers::CONTROL),
            &mut state,
            &config()
        )
        .is_empty());
    }
    assert!(matches!(
        press(&mut state, KeyCode::F(5)).as_slice(),
        [Action::Source(SourceAction::RefreshAccounts)]
    ));
    assert!(matches!(
        press(&mut state, KeyCode::Char('w')).as_slice(),
        [Action::Source(SourceAction::Choose(
            LibraryChoice::AddWebdav
        ))]
    ));
    assert!(press(&mut state, KeyCode::Char('s')).is_empty());
    press(&mut state, KeyCode::Right);
    assert_eq!(state.sources.manager_tab, manager::Tab::Accounts);
    press(&mut state, KeyCode::Left);
    assert_eq!(state.settings_state.focus, SettingsFocus::Content);
    assert_eq!(state.sources.manager_tab, manager::Tab::Libraries);
}

#[test]
fn arrows_follow_the_visible_order_in_both_directions_without_wrapping() {
    let mut state = AppState::new();
    manager::initialize(&mut state, &config());
    open_settings(&mut state);
    state.settings_state.focus = SettingsFocus::Sections;
    for expected in manager::Tab::ALL {
        press(&mut state, KeyCode::Right);
        assert_eq!(state.settings_state.focus, SettingsFocus::Content);
        assert_eq!(state.sources.manager_tab, expected);
    }
    state.popups.library_picker_index = 2;
    press(&mut state, KeyCode::Right);
    assert_eq!(state.sources.manager_tab, manager::Tab::Add);
    assert_eq!(
        state.popups.library_picker_index, 2,
        "right edge must not wrap or reset selection"
    );
    for expected in [manager::Tab::Accounts, manager::Tab::Libraries] {
        state.sources.picker_scroll_pin = Some(0);
        press(&mut state, KeyCode::Left);
        assert_eq!(state.settings_state.focus, SettingsFocus::Content);
        assert_eq!(state.sources.manager_tab, expected);
        assert!(state.sources.picker_scroll_pin.is_none());
    }
    press(&mut state, KeyCode::Left);
    assert_eq!(state.settings_state.focus, SettingsFocus::Sections);
    press(&mut state, KeyCode::Left);
    assert_eq!(state.settings_state.focus, SettingsFocus::Sections);
    press(&mut state, KeyCode::Down);
    assert_eq!(state.settings_state.section, SettingsSection::Textamp);
    press(&mut state, KeyCode::Right);
    assert_eq!(state.settings_state.focus, SettingsFocus::Content);
    press(&mut state, KeyCode::Left);
    press(&mut state, KeyCode::Up);
    press(&mut state, KeyCode::Right);
    assert_eq!(state.settings_state.section, SettingsSection::Libraries);
    assert_eq!(state.settings_state.focus, SettingsFocus::Content);
    assert_eq!(state.sources.manager_tab, manager::Tab::Libraries);
}

#[test]
fn sidebar_focus_and_neighbor_hints_match_the_navigation() {
    let mut state = AppState::new();
    manager::initialize(&mut state, &config());
    open_settings(&mut state);
    let mut terminal = Terminal::new(TestBackend::new(140, 24)).unwrap();
    for tab in manager::Tab::ALL {
        manager::select_tab(&mut state, tab);
        terminal
            .draw(|frame| {
                let feedback = textamp::ui::render(frame, &state);
                state.apply_render_feedback(feedback);
            })
            .unwrap();
        let text: String = terminal
            .backend()
            .buffer()
            .content
            .iter()
            .map(|cell| cell.symbol())
            .collect();
        let previous = tab.previous().map(manager::Tab::title).unwrap_or("sidebar");
        assert!(text.contains(&format!("← {previous}")));
        assert!(!text.contains("> libraries"));
        let rect = state
            .hit_regions
            .library_manager_tabs
            .iter()
            .find(|(_, candidate)| *candidate == tab)
            .unwrap()
            .0;
        let focused_background = terminal
            .backend()
            .buffer()
            .cell((rect.x, rect.y))
            .unwrap()
            .bg;
        press(&mut state, KeyCode::BackTab);
        terminal
            .draw(|frame| {
                textamp::ui::render(frame, &state);
            })
            .unwrap();
        let text: String = terminal
            .backend()
            .buffer()
            .content
            .iter()
            .map(|cell| cell.symbol())
            .collect();
        assert!(text.contains("> libraries"));
        assert_ne!(
            terminal
                .backend()
                .buffer()
                .cell((rect.x, rect.y))
                .unwrap()
                .bg,
            focused_background
        );
        press(&mut state, KeyCode::Tab);
    }
}

#[test]
fn manager_renders_and_mouse_hits_only_lists_and_tabs_at_multiple_sizes() {
    for (width, height) in [(140, 42), (80, 24), (40, 12)] {
        let mut state = AppState::new();
        manager::initialize(&mut state, &config());
        open_settings(&mut state);
        state.sources.accounts = vec![account("one", "Music")];
        let mut terminal = Terminal::new(TestBackend::new(width, height)).unwrap();
        terminal
            .draw(|frame| {
                let feedback = textamp::ui::render(frame, &state);
                state.apply_render_feedback(feedback);
            })
            .unwrap();
        let buffer = terminal.backend().buffer();
        let text: String = buffer.content.iter().map(|cell| cell.symbol()).collect();
        assert!(text.contains("Libraries"));
        if width >= 80 {
            assert!(text.contains("Beatles"));
        }
        if width >= 110 {
            let region = state.hit_regions.library_picker.clone().unwrap();
            let previous = state.popups.library_picker_index;
            let actions = mouse_input::handle_mouse(
                MouseEvent {
                    kind: MouseEventKind::Down(MouseButton::Left),
                    column: region.items_area.right() + 1,
                    row: region.items_area.y + 3,
                    modifiers: KeyModifiers::NONE,
                },
                &mut state,
            );
            assert!(actions.is_empty(), "details are not clickable library rows");
            assert_eq!(state.popups.library_picker_index, previous);
            let button = state.hit_regions.library_audiomuse.unwrap();
            let actions = mouse_input::handle_mouse(
                MouseEvent {
                    kind: MouseEventKind::Down(MouseButton::Left),
                    column: button.x,
                    row: button.y,
                    modifiers: KeyModifiers::NONE,
                },
                &mut state,
            );
            assert!(
                matches!(actions.as_slice(), [Action::Source(SourceAction::AudioMuse(command))]
                if matches!(command.as_ref(), sources::audiomuse::Command::Configure(LibraryChoice::Navidrome { .. })))
            );
            assert_eq!(state.popups.library_picker_index, previous);
        }
        if width < 80 {
            continue;
        }
        let tabs = state.hit_regions.library_manager_tabs.clone();
        let rect = tabs[2].0;
        mouse_input::handle_mouse(
            MouseEvent {
                kind: MouseEventKind::Down(MouseButton::Left),
                column: rect.x,
                row: rect.y,
                modifiers: KeyModifiers::NONE,
            },
            &mut state,
        );
        assert_eq!(state.sources.manager_tab, manager::Tab::Add);
    }
}

#[test]
fn startup_uses_the_saved_source_without_requiring_a_picker() {
    let mut config = config();
    assert!(matches!(
        manager::startup_choice(&config),
        Some(LibraryChoice::Navidrome { .. })
    ));
    config.default_navidrome = None;
    config.default_folder_source = Some("beatles".into());
    assert!(matches!(
        manager::startup_choice(&config),
        Some(LibraryChoice::Folder(_))
    ));
    config.default_folder_source = Some("removed".into());
    assert!(
        manager::startup_choice(&config).is_none(),
        "otherwise use normal Plex startup"
    );
}

#[test]
fn quick_switcher_is_compact_and_does_not_offer_management_commands() {
    let mut state = AppState::new();
    manager::initialize(&mut state, &config());
    state.set_view(View::Browse);
    state.popups.library_picker_active = true;
    let mut terminal = Terminal::new(TestBackend::new(140, 42)).unwrap();
    terminal
        .draw(|frame| {
            let feedback = textamp::ui::render(frame, &state);
            state.apply_render_feedback(feedback);
        })
        .unwrap();
    let text: String = terminal
        .backend()
        .buffer()
        .content
        .iter()
        .map(|cell| cell.symbol())
        .collect();
    assert!(text.contains("Switch library"));
    assert!(text.contains("Beatles"));
    assert!(text.contains("F2 manage"));
    assert!(state.hit_regions.library_manager_tabs.is_empty());
    assert!(
        state
            .hit_regions
            .library_picker
            .as_ref()
            .unwrap()
            .outer
            .height
            < 15
    );
    for key in [
        KeyCode::Tab,
        KeyCode::Char('a'),
        KeyCode::Char('n'),
        KeyCode::Char('/'),
        KeyCode::Char(':'),
        KeyCode::Delete,
    ] {
        assert!(press(&mut state, key).is_empty());
    }
    assert_eq!(state.sources.manager_tab, manager::Tab::Libraries);
    assert!(matches!(
        press(&mut state, KeyCode::F(2)).as_slice(),
        [Action::Search(SearchAction::ManageLibraries)]
    ));
    assert!(matches!(
        press(&mut state, KeyCode::Esc).as_slice(),
        [Action::Search(SearchAction::CloseLibraryPicker)]
    ));
    assert_eq!(state.view, View::Browse);

    // The popup must not retain clickable tabs from underlying Settings.
    open_settings(&mut state);
    terminal
        .draw(|frame| {
            let feedback = textamp::ui::render(frame, &state);
            state.apply_render_feedback(feedback);
        })
        .unwrap();
    assert!(state.hit_regions.library_manager_tabs.is_empty());
}

#[tokio::test]
async fn switching_and_managing_are_separate_and_cancel_preserves_player_state() {
    use textamp::app::dispatch::dispatch_action;
    let mut state = AppState::new();
    let mut config = config();
    manager::initialize(&mut state, &config);
    state.sources.accounts = vec![account("one", "Music")];
    state.sources.active = ActiveSource::Folder("beatles".into());
    state.playback.position_ms = 1234;
    state.set_view(View::Browse);
    let mut client = textamp::plex::PlexClient::new(Default::default()).unwrap();
    let mut audio = textamp::audio::AudioPlayer::new_without_audio();
    let (tx, _rx) = tokio::sync::mpsc::channel(16);
    for action in [
        SearchAction::OpenLibraryPicker,
        SearchAction::ManageLibraries,
    ] {
        dispatch_action(
            action.into(),
            &mut state,
            &mut client,
            &mut audio,
            &mut config,
            &tx,
        )
        .await
        .unwrap();
    }
    assert!(manager::settings_active(&state));
    assert_eq!(state.settings_state.focus, SettingsFocus::Content);
    assert!(!state.popups.library_picker_active);
    manager::select_tab(&mut state, manager::Tab::Accounts);
    dispatch_action(
        SearchAction::OpenLibraryPicker.into(),
        &mut state,
        &mut client,
        &mut audio,
        &mut config,
        &tx,
    )
    .await
    .unwrap();
    assert_eq!(state.sources.manager_tab, manager::Tab::Libraries);
    assert!(sources::choices(&state)[state.popups.library_picker_index].active(&state));
    dispatch_action(
        SearchAction::CloseLibraryPicker.into(),
        &mut state,
        &mut client,
        &mut audio,
        &mut config,
        &tx,
    )
    .await
    .unwrap();
    assert_eq!(state.view, View::Settings);
    assert_eq!(state.playback.position_ms, 1234);
    assert_eq!(
        state.sources.active.folder().map(String::as_str),
        Some("beatles")
    );
    let choice = sources::choices(&state)[state.popups.library_picker_index].clone();
    dispatch_action(
        choice.action(),
        &mut state,
        &mut client,
        &mut audio,
        &mut config,
        &tx,
    )
    .await
    .unwrap();
    assert_eq!(
        state.view,
        View::Browse,
        "opening the active library leaves settings without reloading it"
    );
    assert_eq!(state.playback.position_ms, 1234);
}
