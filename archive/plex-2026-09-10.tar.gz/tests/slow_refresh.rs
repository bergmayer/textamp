use std::time::{Duration, Instant};
use textamp::app::action::AsyncError;
use textamp::app::dispatch::handle_core_event;
use textamp::app::event::{AuthEvent, CategoryLoadError, PreloadEvent};
use textamp::app::handlers::helpers;
use textamp::app::state::{BrowseCategory, ConnectionState, PlayStatus, RefreshCategory, View};
use textamp::app::{AppState, Event};
use textamp::plex::{ApiError, PlexClient};
use tokio::io::{AsyncReadExt, AsyncWriteExt};
use tokio::net::TcpListener;
use tokio::sync::mpsc;

fn state() -> AppState {
    let mut state = AppState::new();
    state.active_library = Some("1".into());
    state.libraries =
        vec![serde_json::from_str(r#"{"key":"1","title":"Music","type":"artist"}"#).unwrap()];
    state.view = View::Browse;
    state.connection = ConnectionState::Connected {
        username: "test".into(),
        has_plex_pass: true,
    };
    state.playback.status = PlayStatus::Playing;
    state
}

#[tokio::test]
async fn scheduled_refresh_checks_weekly_age_without_duplicate_or_fresh_requests() {
    let mut state = state();
    let client = PlexClient::new(Default::default()).unwrap();
    let (tx, _rx) = mpsc::channel(32);
    let now = textamp::library::cache::now();
    for category in RefreshCategory::all() {
        state.cache_mgmt.category_timestamps.insert(*category, now);
    }
    helpers::refresh_due_caches(&mut state, &client, &tx);
    assert!(state.cache_mgmt.requests.is_empty());
    assert!(state.cache_mgmt.pending.is_empty());
    state.cache_mgmt.category_timestamps.insert(
        RefreshCategory::Moods,
        now - textamp::library::cache::REFRESH_INTERVAL.as_secs(),
    );
    helpers::refresh_due_caches(&mut state, &client, &tx);
    assert!(
        state.cache_mgmt.requests.is_empty(),
        "timestamp checks are throttled"
    );
    state.cache_mgmt.next_refresh_check = None;
    helpers::refresh_due_caches(&mut state, &client, &tx);
    assert_eq!(state.cache_mgmt.requests.len(), 1);
    assert!(state
        .cache_mgmt
        .requests
        .contains_key(&RefreshCategory::Moods));
    let sequence = state.cache_mgmt.request_sequence;
    helpers::refresh_due_caches(&mut state, &client, &tx);
    assert_eq!(state.cache_mgmt.request_sequence, sequence);
    state.advance_library_generation();
    assert!(state.cache_mgmt.next_refresh_check.is_none());
    assert!(state.cache_mgmt.requests.is_empty());
}

fn failed(state: &AppState, category: RefreshCategory, retryable: bool) -> Event {
    Event::CategoryResult {
        generation: state.library_generation,
        category,
        request_id: state.cache_mgmt.requests[&category].0,
        result: Err(CategoryLoadError {
            error: AsyncError {
                message: "Plex request timed out".into(),
                connection_error: false,
            },
            retryable,
        }),
    }
}

#[tokio::test]
async fn plex_discovery_waits_for_cache_and_valid_empty_cache_does_not_refetch() {
    use textamp::app::event::DataEvent;
    let mut state = state();
    let mut client = PlexClient::new(Default::default()).unwrap();
    let (tx, _rx) = mpsc::channel(32);
    state.library_loading = true;
    let libraries = state.libraries.clone();
    handle_core_event(
        DataEvent::LibrariesLoaded {
            server_url: None,
            result: Ok(libraries.clone()),
        }
        .into(),
        &mut state,
        &mut client,
        &tx,
    );
    assert!(state.cache_mgmt.requests.is_empty());
    assert!(state.cache_mgmt.pending.is_empty());
    let mut cached = textamp::plex::CacheData::new_scoped("1", None);
    let now = textamp::library::cache::now();
    for category in RefreshCategory::all() {
        cached
            .category_timestamps
            .insert(category.cache_key().into(), now);
    }
    let actions = handle_core_event(
        PreloadEvent::LibraryCacheLoaded {
            library_key: "1".into(),
            cached: Box::new(cached),
        }
        .into(),
        &mut state,
        &mut client,
        &tx,
    );
    for action in actions {
        textamp::app::dispatch::dispatch_action(
            action,
            &mut state,
            &mut client,
            &mut textamp::audio::AudioPlayer::new_without_audio(),
            &mut Default::default(),
            &tx,
        )
        .await
        .unwrap();
    }
    handle_core_event(
        DataEvent::LibrariesLoaded {
            server_url: None,
            result: Ok(libraries),
        }
        .into(),
        &mut state,
        &mut client,
        &tx,
    );
    assert!(!state.library_loading);
    assert!(state.library.artists.is_empty());
    assert!(state.cache_mgmt.requests.is_empty(), "empty is not missing");
    assert!(state.cache_mgmt.pending.is_empty());

    state.cache_mgmt.category_timestamps.clear();
    let actions = handle_core_event(
        PreloadEvent::LibraryCacheLoadFailed {
            library_key: "1".into(),
        }
        .into(),
        &mut state,
        &mut client,
        &tx,
    );
    for action in actions {
        textamp::app::dispatch::dispatch_action(
            action,
            &mut state,
            &mut client,
            &mut textamp::audio::AudioPlayer::new_without_audio(),
            &mut Default::default(),
            &tx,
        )
        .await
        .unwrap();
    }
    assert_eq!(state.cache_mgmt.requests.len(), 2);
    assert!(
        !state.cache_mgmt.pending.is_empty(),
        "a genuinely missing cache is rebuilt"
    );
}

#[tokio::test]
async fn slow_metadata_with_healthy_identity_is_not_a_disconnect_or_modal_error() {
    let listener = TcpListener::bind("127.0.0.1:0").await.unwrap();
    let mut client = PlexClient::new_with_url_and_timeout(
        &format!("http://{}", listener.local_addr().unwrap()),
        Some("test"),
        "test",
        1,
    )
    .unwrap();
    let server = tokio::spawn(async move {
        let mut tasks = tokio::task::JoinSet::new();
        loop {
            let (mut stream, _) = listener.accept().await.unwrap();
            tasks.spawn(async move {
                let mut bytes = [0; 4096];
                let n = stream.read(&mut bytes).await.unwrap();
                if bytes[..n].starts_with(b"GET /identity ") {
                    stream
                        .write_all(
                            b"HTTP/1.1 200 OK\r\nContent-Length: 2\r\nConnection: close\r\n\r\n{}",
                        )
                        .await
                        .unwrap();
                } else {
                    tokio::time::sleep(Duration::from_secs(20)).await;
                }
            });
        }
    });
    let mut state = state();
    state
        .cache_mgmt
        .category_timestamps
        .insert(RefreshCategory::Moods, 17);
    state.library.moods =
        vec![serde_json::from_str(r#"{"key":"old","title":"Cached mood"}"#).unwrap()];
    let (tx, mut rx) = mpsc::channel(16);
    helpers::preload_data(&tx, RefreshCategory::Moods, "1", &client, &mut state);
    let event = tokio::time::timeout(Duration::from_secs(4), rx.recv())
        .await
        .unwrap()
        .unwrap();
    let actions = handle_core_event(event, &mut state, &mut client, &tx);
    assert!(
        actions.is_empty(),
        "healthy route should not enter recovery"
    );
    assert!(matches!(
        state.connection,
        ConnectionState::Connected { .. }
    ));
    assert!(state.notifications.last_error.is_none());
    assert!(state
        .notifications
        .status_message
        .as_deref()
        .unwrap()
        .contains("refresh failed"));
    assert_eq!(
        state.cache_mgmt.category_timestamps[&RefreshCategory::Moods],
        17
    );
    assert_eq!(state.library.moods[0].title, "Cached mood");
    assert_eq!(state.playback.status, PlayStatus::Playing);
    assert!(state.cache_mgmt.failures[&RefreshCategory::Moods]
        .retry_at
        .is_some());
    server.abort();
    let _ = server.await;
}

#[tokio::test]
async fn refresh_queue_is_bounded_prioritizes_view_and_cancels_on_library_change() {
    let mut state = state();
    let mut client = PlexClient::new(Default::default()).unwrap();
    let (tx, _rx) = mpsc::channel(32);
    helpers::preload_all_library_data(&tx, "1", "Music", &client, &mut state);
    assert_eq!(state.cache_mgmt.requests.len(), 2);
    state.browse_category = BrowseCategory::Folders;
    let pending = state.cache_mgmt.pending.len();
    helpers::check_staleness_on_view_load(&tx, &mut state, &client, RefreshCategory::Folders);
    assert_eq!(state.cache_mgmt.pending.len(), pending);
    let event = failed(&state, RefreshCategory::Artists, true);
    handle_core_event(event, &mut state, &mut client, &tx);
    assert_eq!(state.cache_mgmt.requests.len(), 2);
    assert!(state
        .cache_mgmt
        .requests
        .contains_key(&RefreshCategory::Folders));
    let stale = failed(&state, RefreshCategory::Folders, true);
    state.advance_library_generation();
    handle_core_event(stale, &mut state, &mut client, &tx);
    assert!(state.cache_mgmt.requests.is_empty());
    assert!(state.cache_mgmt.pending.is_empty());
    assert!(state.cache_mgmt.failures.is_empty());
    assert!(state.cache_mgmt.background_refresh.is_empty());
}

#[tokio::test]
async fn refused_connection_still_requests_recovery_without_background_dialog() {
    let listener = TcpListener::bind("127.0.0.1:0").await.unwrap();
    let url = format!("http://{}", listener.local_addr().unwrap());
    drop(listener);
    let mut client = PlexClient::new_with_url(&url, Some("test"), "test").unwrap();
    let mut state = state();
    let (tx, mut rx) = mpsc::channel(16);
    helpers::preload_data(&tx, RefreshCategory::Moods, "1", &client, &mut state);
    let event = tokio::time::timeout(Duration::from_secs(3), rx.recv())
        .await
        .unwrap()
        .unwrap();
    let actions = handle_core_event(event, &mut state, &mut client, &tx);
    assert!(actions.iter().any(|action| matches!(
        action,
        textamp::app::Action::System(textamp::app::action::SystemAction::RecoverConnection)
    )));
    assert!(matches!(state.connection, ConnectionState::Degraded { .. }));
    assert!(state.notifications.last_error.is_none());
}

#[tokio::test]
async fn background_retries_are_bounded_and_f5_bypasses_backoff() {
    let mut state = state();
    let mut client = PlexClient::new(Default::default()).unwrap();
    let (tx, _rx) = mpsc::channel(16);
    let category = RefreshCategory::Moods;
    helpers::preload_data(&tx, category, "1", &client, &mut state);
    for attempt in 1..=3 {
        let event = failed(&state, category, true);
        handle_core_event(event, &mut state, &mut client, &tx);
        assert_eq!(state.cache_mgmt.failures[&category].attempts, attempt);
        assert!(state.cache_mgmt.requests.is_empty());
        // Navigation cannot circumvent the cooldown or restart exhausted work.
        helpers::preload_data(&tx, category, "1", &client, &mut state);
        assert!(state.cache_mgmt.requests.is_empty());
        if attempt < 3 {
            assert!(state.cache_mgmt.failures[&category].retry_at.is_some());
            state
                .cache_mgmt
                .failures
                .get_mut(&category)
                .unwrap()
                .retry_at = Some(Instant::now());
            helpers::pump_category_loads(&tx, &mut state, &client);
            assert!(state.cache_mgmt.requests.contains_key(&category));
        }
    }
    assert!(state.notifications.last_error.is_none());
    assert!(state.cache_mgmt.failures[&category].retry_at.is_none());
    helpers::spawn_category_refresh(&tx, category, "1", &mut state, &client);
    assert!(state.cache_mgmt.failures.is_empty());
    let event = failed(&state, category, false);
    handle_core_event(event, &mut state, &mut client, &tx);
    assert!(
        state.notifications.last_error.is_some(),
        "explicit failure must be visible"
    );
    assert!(state.cache_mgmt.failures[&category].retry_at.is_none());
}

#[tokio::test]
async fn identity_recovery_does_not_complete_failed_category_or_clear_unrelated_error() {
    let mut state = state();
    let mut client = PlexClient::new_with_url("http://127.0.0.1:1", Some("test"), "test").unwrap();
    let (tx, _rx) = mpsc::channel(16);
    helpers::preload_data(&tx, RefreshCategory::Moods, "1", &client, &mut state);
    let event = failed(&state, RefreshCategory::Moods, true);
    handle_core_event(event, &mut state, &mut client, &tx);
    state.set_error("A requested track is unavailable".into());
    // Exercise an actual URL change, not only a successful same-route probe.
    client.set_server("http://127.0.0.1:2".into());
    handle_core_event(
        AuthEvent::ConnectionRecoverySucceeded {
            server_name: "test".into(),
            server_identifier: None,
            servers: vec![],
            selection: textamp::plex::ConnectionSelection {
                selected: textamp::plex::MeasuredConnection {
                    url: "http://127.0.0.1:1".into(),
                    kind: textamp::plex::ConnectionKind::Loopback,
                    latency_ms: 1,
                },
                fallbacks: vec![],
                failed_count: 0,
            },
        }
        .into(),
        &mut state,
        &mut client,
        &tx,
    );
    assert!(state
        .cache_mgmt
        .failures
        .contains_key(&RefreshCategory::Moods));
    assert!(!state
        .cache_mgmt
        .category_timestamps
        .contains_key(&RefreshCategory::Moods));
    assert_eq!(
        state.notifications.last_error.as_deref(),
        Some("A requested track is unavailable")
    );
    // Only the actual successful category response records freshness.
    state
        .cache_mgmt
        .failures
        .get_mut(&RefreshCategory::Moods)
        .unwrap()
        .retry_at = Some(Instant::now());
    helpers::pump_category_loads(&tx, &mut state, &client);
    let request_id = state.cache_mgmt.requests[&RefreshCategory::Moods].0;
    handle_core_event(
        Event::CategoryResult {
            generation: state.library_generation,
            category: RefreshCategory::Moods,
            request_id,
            result: Ok(Box::new(
                PreloadEvent::MoodsPreloaded {
                    library_key: "1".into(),
                    moods: vec![],
                }
                .into(),
            )),
        },
        &mut state,
        &mut client,
        &tx,
    );
    assert!(state.cache_mgmt.failures.is_empty());
    assert!(state
        .cache_mgmt
        .category_timestamps
        .contains_key(&RefreshCategory::Moods));
}

#[tokio::test]
async fn paginated_library_loads_reject_partial_or_repeated_results() {
    for media_type in [9, 10] {
        for ending in ["complete", "empty", "duplicate", "error"] {
            let listener = TcpListener::bind("127.0.0.1:0").await.unwrap();
            let client = PlexClient::new_with_url(
                &format!("http://{}", listener.local_addr().unwrap()),
                Some("test"),
                "test",
            )
            .unwrap();
            let server = tokio::spawn(async move {
                for offset in [0, 2] {
                    let (mut stream, _) = listener.accept().await.unwrap();
                    let mut bytes = [0; 4096];
                    let n = stream.read(&mut bytes).await.unwrap();
                    let request = String::from_utf8_lossy(&bytes[..n]);
                    assert!(request.contains(&format!("type={media_type}")));
                    assert!(request.contains(&format!("X-Plex-Container-Start={offset}")));
                    assert!(request.contains("X-Plex-Container-Size=200"));
                    let ids = if offset == 0 {
                        vec!["1", "2"]
                    } else {
                        match ending {
                            "complete" => vec!["3"],
                            "duplicate" => vec!["2"],
                            _ => vec![],
                        }
                    };
                    let items: Vec<_> = ids.iter().map(|id| serde_json::json!({"ratingKey":id,"key":format!("/library/metadata/{id}"),"title":id})).collect();
                    let body = serde_json::json!({"MediaContainer":{"offset":offset,"totalSize":3,"size":items.len(),"Metadata":items}}).to_string();
                    let status = if offset == 2 && ending == "error" {
                        "404 Not Found"
                    } else {
                        "200 OK"
                    };
                    stream.write_all(format!("HTTP/1.1 {status}\r\nContent-Length: {}\r\nConnection: close\r\n\r\n{body}", body.len()).as_bytes()).await.unwrap();
                }
            });
            let result = if media_type == 9 {
                client.get_albums("1").await.map(|v| v.len())
            } else {
                client.get_tracks("1").await.map(|v| v.len())
            };
            if ending == "complete" {
                assert_eq!(result.unwrap(), 3);
            } else {
                assert!(result.is_err());
            }
            server.await.unwrap();
        }
    }
    assert!(!ApiError::Timeout
        .user_message("Load Folders")
        .contains("lost contact"));
}
