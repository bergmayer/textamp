use textamp::plex::{PlexAuth, ServerInfo};

#[test]
fn saved_accounts_are_independent_and_logout_removes_only_active_credentials() {
    let root = tempfile::tempdir().unwrap();
    let status = std::process::Command::new(std::env::current_exe().unwrap())
        .args(["--exact", "account_storage_worker", "--nocapture"])
        .env("TEXTAMP_ACCOUNT_TEST", "1")
        .env("XDG_DATA_HOME", root.path())
        .env("XDG_CONFIG_HOME", root.path())
        .env("XDG_CACHE_HOME", root.path())
        .env("XDG_STATE_HOME", root.path())
        .status()
        .unwrap();
    assert!(status.success());
}

#[test]
fn account_storage_worker() {
    if std::env::var("TEXTAMP_ACCOUNT_TEST").as_deref() != Ok("1") {
        return;
    }
    let auth = PlexAuth::new().unwrap();
    let alice = serde_json::from_str(r#"{"id":11,"username":"Alice"}"#).unwrap();
    let bob = serde_json::from_str(r#"{"id":22,"username":"Bob"}"#).unwrap();
    auth.save_token("fixture-alice-token", Some(&alice))
        .unwrap();
    PlexAuth::update_server_info(&ServerInfo {
        url: "http://alice.test".into(),
        identifier: "server-a".into(),
        name: "Server A".into(),
    })
    .unwrap();
    PlexAuth::activate_account(None).unwrap();
    assert!(PlexAuth::load_token().is_none());
    auth.save_token("fixture-bob-token", Some(&bob)).unwrap();
    assert_eq!(PlexAuth::saved_accounts().unwrap().len(), 2);
    let active_before = PlexAuth::load_token().unwrap().token.clone();
    assert_eq!(
        PlexAuth::saved_account("id_11")
            .unwrap()
            .username
            .as_deref(),
        Some("Alice")
    );
    assert_eq!(PlexAuth::load_token().unwrap().token, active_before);
    assert!(PlexAuth::saved_account("../../auth").is_err());
    let mut directory = textamp::plex::library_directory::load().unwrap();
    directory[0]
        .libraries
        .push(textamp::plex::library_directory::Library {
            server_id: "server-a".into(),
            server_name: "Server A".into(),
            key: "1".into(),
            title: "Music".into(),
        });
    textamp::plex::library_directory::save(&directory).unwrap();
    assert_eq!(textamp::plex::library_directory::load().unwrap(), directory);
    let stale = textamp::plex::library_directory::begin_update();
    textamp::plex::library_directory::begin_update();
    textamp::plex::library_directory::save_current(stale, &[]).unwrap();
    assert_eq!(
        textamp::plex::library_directory::load().unwrap(),
        directory,
        "superseded background writes cannot erase a newer directory"
    );
    tokio::runtime::Runtime::new().unwrap().block_on(async {
        use textamp::app::sources::{self, LibraryChoice, SourceAction};
        let mut state = textamp::app::AppState::new();
        let mut client = textamp::plex::PlexClient::new(Default::default()).unwrap();
        let mut audio = textamp::audio::AudioPlayer::new_without_audio();
        let (tx, mut rx) = tokio::sync::mpsc::channel(32);
        sources::dispatch(
            SourceAction::Choose(LibraryChoice::SavedPlex {
                account_id: "id_11".into(),
                account_name: "Alice".into(),
                library: textamp::plex::library_directory::Library {
                    server_id: "server-a".into(),
                    server_name: "Server A".into(),
                    key: "7".into(),
                    title: "Chosen library".into(),
                },
            }),
            &mut state,
            &mut client,
            &mut audio,
            &mut Default::default(),
            &tx,
        )
        .await
        .unwrap();
        assert_eq!(
            state.sources.pending_plex_library,
            Some(("server-a".into(), "7".into()))
        );
        tokio::time::timeout(std::time::Duration::from_secs(3), async {
            while let Some(event) = rx.recv().await {
                if let textamp::app::Event::Effect(textamp::app::Action::Source(
                    SourceAction::AccountActivated { result, .. },
                )) = event
                {
                    result.unwrap();
                    break;
                }
            }
        })
        .await
        .unwrap();
        assert_eq!(
            PlexAuth::load_token().unwrap().username.as_deref(),
            Some("Alice")
        );
    });
    let stored = PlexAuth::load_token().unwrap();
    assert_eq!(stored.token.as_str(), "fixture-alice-token");
    assert_eq!(stored.server_identifier.as_deref(), Some("server-a"));
    assert!(PlexAuth::activate_account(Some("../../auth")).is_err());
    assert!(PlexAuth::remove_account("id_11").is_err());
    let epoch = PlexAuth::begin_account_storage_epoch();
    PlexAuth::begin_account_storage_epoch();
    assert!(PlexAuth::with_account_storage_epoch(epoch, PlexAuth::delete_token).is_none());
    assert!(PlexAuth::load_token().is_some());
    PlexAuth::delete_token().unwrap();
    let directory = textamp::plex::library_directory::load().unwrap();
    assert_eq!(directory.len(), 1);
    assert_eq!(
        directory[0].name, "Bob",
        "removed accounts cannot reappear from the cached directory"
    );
    assert_eq!(
        PlexAuth::saved_accounts().unwrap(),
        [("id_22".to_string(), "Bob".to_string())]
    );
    PlexAuth::activate_account(Some("id_22")).unwrap();
    assert_eq!(
        PlexAuth::load_token().unwrap().token.as_str(),
        "fixture-bob-token"
    );
    #[cfg(unix)]
    {
        use std::os::unix::fs::PermissionsExt;
        let paths = textamp::config::XdgPaths::new("textamp");
        assert_eq!(
            std::fs::metadata(paths.data_dir.join("accounts/id_22.toml"))
                .unwrap()
                .permissions()
                .mode()
                & 0o777,
            0o600
        );
    }
    textamp::library::credentials::save("folder-a", "first-password".into()).unwrap();
    auth.save_token("fixture-alice-token", Some(&alice))
        .unwrap();
    PlexAuth::sign_out_account("id_22").unwrap();
    assert_eq!(
        PlexAuth::load_token().unwrap().username.as_deref(),
        Some("Alice")
    );
    assert!(PlexAuth::saved_account("id_22").is_err());
    assert!(PlexAuth::sign_out_account("../../auth").is_err());
    tokio::runtime::Runtime::new().unwrap().block_on(async {
        use textamp::app::sources::{self, SourceAction};
        use textamp::app::state::{ConnectionState, View};
        let mut state = textamp::app::AppState::new();
        state.settings_state.username_input = "Alice".into();
        state.connection = ConnectionState::Connected {
            username: "Alice".into(),
            has_plex_pass: true,
        };
        state.sources.accounts = textamp::plex::library_directory::load().unwrap();
        let (tx, _rx) = tokio::sync::mpsc::channel(32);
        sources::dispatch(
            SourceAction::SignOutPlex {
                id: "id_11".into(),
                name: "Alice".into(),
            },
            &mut state,
            &mut textamp::plex::PlexClient::new(Default::default()).unwrap(),
            &mut textamp::audio::AudioPlayer::new_without_audio(),
            &mut Default::default(),
            &tx,
        )
        .await
        .unwrap();
        assert!(matches!(state.connection, ConnectionState::Disconnected));
        assert!(state.settings_state.username_input.is_empty());
        assert!(state.sources.accounts.is_empty());
        assert_eq!(state.view, View::Settings);
        assert!(textamp::app::tasks::finish_blocking(std::time::Duration::from_secs(5)).await);
    });
    assert!(PlexAuth::load_token().is_none());
    assert!(PlexAuth::saved_accounts().unwrap().is_empty());
    textamp::library::credentials::save("folder-b", "second-password".into()).unwrap();
    textamp::library::credentials::save("folder-a", "".into()).unwrap();
    assert!(textamp::library::credentials::load("folder-a")
        .unwrap()
        .is_none());
    assert_eq!(
        textamp::library::credentials::load("folder-b")
            .unwrap()
            .unwrap()
            .as_str(),
        "second-password"
    );
}
