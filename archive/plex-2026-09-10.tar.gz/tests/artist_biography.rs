use crossterm::event::{KeyCode, KeyEvent, KeyModifiers};
use textamp::app::action::SearchAction;
use textamp::app::event::UiEvent;
use textamp::app::handlers::{helpers, key_input};
use textamp::app::state::{ArtistBioPopup, View};
use textamp::app::{Action, AppState};
use textamp::config::Config;
use textamp::library::track::Track;
use textamp::services::biography::{BioImage, Biography};

fn popup() -> ArtistBioPopup {
    ArtistBioPopup {
        artist_name: "Tool".into(),
        document: Biography {
            text: "Current bio".into(),
            ..Default::default()
        },
        scroll: 0,
        loading: false,
        image_index: 0,
        task: None,
    }
}

#[test]
fn folder_biographies_require_embedded_artist_metadata_not_folder_names() {
    let mut state = AppState::new();
    state.view = View::NowPlaying;
    state.sources.active = textamp::app::sources::ActiveSource::Folder("local".into());
    state.queue.tracks = vec![Track::from_folder("local", "Tool/Album/01.flac")];
    state.queue.index = Some(0);
    assert!(helpers::get_artist_for_bio(&state).is_none());
    state.queue.tracks[0].original_title = Some("Tool".into());
    let actions = key_input::handle_key(
        KeyEvent::new(KeyCode::F(4), KeyModifiers::NONE),
        &mut state,
        &Config::default(),
    );
    assert!(
        matches!(&actions[..], [Action::Search(SearchAction::ShowArtistBio { artist_key, artist_name })] if artist_key.is_empty() && artist_name == "Tool")
    );
}

#[test]
fn biography_photo_navigation_and_close_preserve_main_view() {
    let mut state = AppState::new();
    state.view = View::NowPlaying;
    let mut bio = popup();
    bio.document.images = (0..2)
        .map(|n| BioImage {
            key: n.to_string(),
            data: vec![],
            caption: n.to_string(),
        })
        .collect();
    state.popups.artist_bio = Some(bio);
    let config = Config::default();
    key_input::handle_key(
        KeyEvent::new(KeyCode::Right, KeyModifiers::NONE),
        &mut state,
        &config,
    );
    assert_eq!(state.popups.artist_bio.as_ref().unwrap().image_index, 1);
    key_input::handle_key(
        KeyEvent::new(KeyCode::Right, KeyModifiers::NONE),
        &mut state,
        &config,
    );
    assert_eq!(state.popups.artist_bio.as_ref().unwrap().image_index, 0);
    key_input::handle_key(
        KeyEvent::new(KeyCode::F(4), KeyModifiers::NONE),
        &mut state,
        &config,
    );
    assert!(state.popups.artist_bio.is_none());
    assert_eq!(state.view, View::NowPlaying);
}

#[test]
fn biography_renders_readable_text_photos_and_shortcuts_at_small_sizes() {
    use ratatui::{backend::TestBackend, Terminal};
    let mut png = std::io::Cursor::new(Vec::new());
    image::DynamicImage::new_rgb8(20, 20)
        .write_to(&mut png, image::ImageFormat::Png)
        .unwrap();
    for (width, height) in [(120, 40), (60, 20), (12, 5)] {
        let mut state = AppState::new();
        state.artwork.mode = textamp::app::state::ArtworkMode::Braille;
        let mut bio = popup();
        bio.document.source_url = Some("https://en.wikipedia.org/wiki/Tool_(band)".into());
        bio.document.images.push(BioImage {
            key: "fixture".into(),
            data: png.get_ref().clone(),
            caption: "Band photo".into(),
        });
        state.popups.artist_bio = Some(bio);
        let mut terminal = Terminal::new(TestBackend::new(width, height)).unwrap();
        terminal
            .draw(|frame| {
                textamp::ui::render(frame, &state);
            })
            .unwrap();
        let buffer = terminal.backend().buffer();
        let text: String = buffer.content.iter().map(|cell| cell.symbol()).collect();
        if width == 120 {
            assert!(text.contains("Band photo"));
            assert!(text.contains("Current bio"));
            assert!(text.contains("B source"));
        }
    }
}

#[tokio::test]
async fn closing_bio_cancels_its_task_and_library_change_closes_popup() {
    let task = tokio::spawn(std::future::pending::<()>());
    let mut bio = popup();
    bio.task = Some(textamp::app::tasks::TaskLease::new(&task));
    let mut state = AppState::new();
    state.popups.artist_bio = Some(bio);
    state.advance_library_generation();
    assert!(state.popups.artist_bio.is_none());
    assert!(task.await.unwrap_err().is_cancelled());
}

#[test]
fn stale_biography_responses_cannot_replace_current_artist() {
    use textamp::app::dispatch::handle_core_event;
    let mut state = AppState::new();
    state.library_generation = 3;
    state.artist_bio_request_id = 4;
    state.popups.artist_bio = Some(popup());
    let mut client =
        textamp::plex::PlexClient::new(textamp::plex::PlexClientInfo::default()).unwrap();
    let (tx, _rx) = tokio::sync::mpsc::channel(8);
    for (generation, request_id) in [(2, 4), (3, 3)] {
        handle_core_event(
            UiEvent::ArtistBioLoaded {
                generation,
                request_id,
                result: Err("Stale failure".into()),
            }
            .into(),
            &mut state,
            &mut client,
            &tx,
        );
    }
    assert_eq!(
        state.popups.artist_bio.unwrap().document.text,
        "Current bio"
    );
}

#[tokio::test]
async fn plex_biography_is_used_without_wikipedia_fallback() {
    use tokio::io::{AsyncReadExt, AsyncWriteExt};
    let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
    let url = format!("http://{}", listener.local_addr().unwrap());
    let server = tokio::spawn(async move {
        let (mut stream, _) = listener.accept().await.unwrap();
        let mut request = [0; 4096];
        assert!(stream.read(&mut request).await.unwrap() > 0);
        let body = r#"{"MediaContainer":{"Metadata":[{"ratingKey":"1","title":"Fixture Artist","summary":"Provider biography wins."}]}}"#;
        stream.write_all(format!("HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nContent-Length: {}\r\nConnection: close\r\n\r\n{}", body.len(), body).as_bytes()).await.unwrap();
    });
    let client = textamp::plex::PlexClient::new_with_url(&url, Some("fixture"), "fixture").unwrap();
    let mut state = AppState::new();
    let (tx, mut rx) = tokio::sync::mpsc::channel(8);
    helpers::biography::show(
        &mut state,
        &client,
        &tx,
        "1".into(),
        "Fixture Artist".into(),
    );
    let event = tokio::time::timeout(std::time::Duration::from_secs(3), rx.recv())
        .await
        .unwrap()
        .unwrap();
    match event {
        textamp::app::Event::Ui(UiEvent::ArtistBioLoaded {
            result: Ok(bio), ..
        }) => {
            assert_eq!(bio.text, "Provider biography wins.");
            assert!(bio.source_url.is_none());
        }
        other => panic!("Unexpected result: {other:?}"),
    }
    server.await.unwrap();
}
