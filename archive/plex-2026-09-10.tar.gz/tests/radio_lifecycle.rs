use std::time::Duration;

use textamp::app::action::{PlaybackAction, RadioAction};
use textamp::app::dispatch::{dispatch_action, handle_core_event};
use textamp::app::event::{Event, RadioEvent};
use textamp::app::handlers::helpers;
use textamp::app::state::{ActiveStation, PlayStatus, PlaybackMode, RadioRefill};
use textamp::app::{Action, AppState};
use textamp::audio::AudioPlayer;
use textamp::config::Config;
use textamp::plex::models::{RadioSource, Track};
use textamp::plex::{ApiError, PlexClient};
use tokio::io::{AsyncReadExt, AsyncWriteExt};
use tokio::net::TcpListener;
use tokio::sync::mpsc;

fn track(key: &str) -> Track {
    serde_json::from_value(serde_json::json!({"ratingKey":key,"title":key})).unwrap()
}

fn station() -> ActiveStation {
    ActiveStation {
        source: RadioSource::Station("/library/sections/5/stations/randomAlbum".into()),
        title: "Random Album".into(),
    }
}

fn refill(keys: &[&str]) -> Event {
    RadioEvent::RadioTracksLoaded {
        result: Ok(keys.iter().map(|key| track(key)).collect()),
        time_travel_index: None,
    }
    .into()
}

fn loaded() -> Event {
    RadioEvent::StationTracksLoaded {
        station: station(),
        tracks: vec![track("replacement")],
        time_travel_decades: vec![],
        time_travel_index: None,
    }
    .into()
}

fn sonic_loaded(state: &mut AppState, playback_id: u64) -> Event {
    state.station_starting = Some(textamp::app::state::StationStart {
        title: "Sonic Radio".into(),
        continue_playback: Some(playback_id),
    });
    RadioEvent::StationTracksLoaded {
        station: ActiveStation {
            source: RadioSource::Sonic("first".into()),
            title: "Sonic Radio".into(),
        },
        tracks: vec![track("first"), track("similar")],
        time_travel_decades: vec![],
        time_travel_index: None,
    }
    .into()
}

#[tokio::test]
async fn sonic_station_and_track_action_preserve_current_audio_and_pause_state() {
    for status in [PlayStatus::Playing, PlayStatus::Paused] {
        for from_track in [false, true] {
            let mut p = Player::new();
            p.state.set_playback_mode(PlaybackMode::Queue);
            p.state.queue.tracks = vec![track("first"), track("old-next")];
            p.state.queue.index = Some(0);
            p.state.playback.status = status;
            p.state.playback.position_ms = 42_000;
            p.state.playback.request_id = 7;
            p.state.plex_session_id = Some("playing-session".into());
            let (client, server) = server_response("200 OK", r#"{"MediaContainer":{"Metadata":[{"ratingKey":"first","title":"seed"},{"ratingKey":"similar","title":"match"}]}}"#).await;
            p.client = client;
            p.dispatch(if from_track {
                RadioAction::StartSonicRadio(Box::new(track("first")))
            } else {
                RadioAction::PlayStation("/library/sections/5/stations/sonic".into())
            })
            .await;
            assert!(
                p.receive().await.is_empty(),
                "must not dispatch audio restart"
            );
            assert_eq!(p.state.playback_mode, PlaybackMode::Radio);
            assert_eq!(p.state.playback.status, status);
            assert_eq!(p.state.playback.position_ms, 42_000);
            assert_eq!(p.state.playback.request_id, 7);
            assert_eq!(p.state.plex_session_id.as_deref(), Some("playing-session"));
            assert_eq!(p.state.current_track().unwrap().rating_key, "first");
            assert_eq!(
                p.state
                    .radio
                    .tracks
                    .iter()
                    .map(|t| t.rating_key.as_str())
                    .collect::<Vec<_>>(),
                ["first", "similar"]
            );
            server.await.unwrap();
        }
    }
}

#[tokio::test]
async fn sonic_late_results_never_interrupt_a_new_playback_instance() {
    let mut p = Player::new();
    p.state.playback.request_id = 8;
    p.state.playback.position_ms = 2_000;
    let event = sonic_loaded(&mut p.state, 7);
    assert!(p.reduce(event).is_empty());
    assert_eq!(p.state.radio.tracks[1].rating_key, "last");
    assert_eq!(p.state.playback.position_ms, 2_000);
    assert!(p.state.station_starting.is_none());
}

#[tokio::test]
async fn sonic_result_after_song_ends_starts_matches_without_replaying_seed() {
    let mut p = Player::new();
    p.state.playback.status = PlayStatus::Stopped;
    let id = p.state.playback.request_id;
    let event = sonic_loaded(&mut p.state, id);
    let actions = p.reduce(event);
    assert!(matches!(
        actions.as_slice(),
        [Action::Radio(RadioAction::PlayCurrentRadioTrack)]
    ));
    assert_eq!(p.state.current_track().unwrap().rating_key, "similar");
}

#[tokio::test]
async fn natural_song_end_waits_for_sonic_discovery_instead_of_advancing_old_queue() {
    let mut p = Player::new();
    p.state.playback.playback_started_at = Some(std::time::Instant::now() - Duration::from_secs(5));
    let id = p.state.playback.request_id;
    let result = sonic_loaded(&mut p.state, id);
    assert!(p
        .reduce(textamp::app::event::PlaybackEvent::TrackEnded.into())
        .is_empty());
    assert_eq!(p.state.playback.status, PlayStatus::Stopped);
    assert_eq!(p.state.current_track().unwrap().rating_key, "first");
    assert!(p.state.station_starting.is_some());
    let actions = p.reduce(result);
    assert!(matches!(
        actions.as_slice(),
        [Action::Radio(RadioAction::PlayCurrentRadioTrack)]
    ));
    assert_eq!(p.state.current_track().unwrap().rating_key, "similar");
}

#[tokio::test]
async fn pausing_while_sonic_discovery_is_pending_preserves_the_continuation() {
    let mut p = Player::new();
    let id = p.state.playback.request_id;
    let result = sonic_loaded(&mut p.state, id);
    p.dispatch(PlaybackAction::TogglePlayPause).await;
    assert!(p.state.station_starting.is_some());
    assert_eq!(p.state.playback.status, PlayStatus::Paused);
    assert!(p.reduce(result).is_empty());
    assert_eq!(p.state.playback.status, PlayStatus::Paused);
    assert_eq!(p.state.current_track().unwrap().rating_key, "first");
    assert_eq!(p.state.radio.tracks[1].rating_key, "similar");
}

#[tokio::test]
async fn sonic_from_different_track_starts_selected_seed_not_randomized_match() {
    let mut p = Player::new();
    let (client, server) = server_response(
        "200 OK",
        r#"{"MediaContainer":{"Metadata":[{"ratingKey":"similar","title":"match"}]}}"#,
    )
    .await;
    p.client = client;
    p.dispatch(RadioAction::StartSonicRadio(Box::new(track("chosen"))))
        .await;
    assert_eq!(p.state.current_track().unwrap().rating_key, "first");
    let actions = p.receive().await;
    assert!(matches!(
        actions.as_slice(),
        [Action::Radio(RadioAction::PlayCurrentRadioTrack)]
    ));
    assert_eq!(p.state.current_track().unwrap().rating_key, "chosen");
    assert_eq!(p.state.radio.tracks[1].rating_key, "similar");
    server.await.unwrap();
}

#[tokio::test]
async fn sonic_with_no_matches_does_not_replace_the_queue_with_just_the_seed() {
    let mut p = Player::new();
    let (client, server) = server_response(
        "200 OK",
        r#"{"MediaContainer":{"Metadata":[{"ratingKey":"first","title":"seed"}]}}"#,
    )
    .await;
    p.client = client;
    p.dispatch(RadioAction::StartSonicRadio(Box::new(track("first"))))
        .await;
    assert!(p.receive().await.is_empty());
    assert_eq!(p.state.radio.tracks[1].rating_key, "last");
    assert_eq!(p.state.playback.status, PlayStatus::Playing);
    assert!(p
        .state
        .notifications
        .last_error
        .as_ref()
        .unwrap()
        .contains("No sonically similar"));
    server.await.unwrap();
}

struct Player {
    state: AppState,
    client: PlexClient,
    audio: AudioPlayer,
    config: Config,
    tx: mpsc::Sender<Event>,
    rx: mpsc::Receiver<Event>,
}

impl Player {
    fn new() -> Self {
        let (tx, rx) = mpsc::channel(32);
        let mut state = AppState::new();
        state.set_playback_mode(PlaybackMode::Radio);
        state.radio.tracks = vec![track("first"), track("last")];
        state.radio.track_index = Some(0);
        state.playback.status = PlayStatus::Playing;
        Self {
            state,
            client: PlexClient::new(Default::default()).unwrap(),
            audio: AudioPlayer::new_without_audio(),
            config: Config::default(),
            tx,
            rx,
        }
    }

    fn reduce(&mut self, event: Event) -> Vec<Action> {
        handle_core_event(event, &mut self.state, &mut self.client, &self.tx)
    }

    async fn dispatch(&mut self, action: impl Into<Action>) {
        dispatch_action(
            action.into(),
            &mut self.state,
            &mut self.client,
            &mut self.audio,
            &mut self.config,
            &self.tx,
        )
        .await
        .unwrap();
    }

    async fn receive(&mut self) -> Vec<Action> {
        let event = tokio::time::timeout(Duration::from_secs(3), self.rx.recv())
            .await
            .unwrap()
            .unwrap();
        self.reduce(event)
    }
}

#[tokio::test]
async fn prefetch_finishing_on_last_track_does_not_skip_it() {
    let mut p = Player::new();
    p.state.radio.refill = RadioRefill::Prefetching;
    assert!(helpers::advance_radio(
        &p.tx,
        &mut p.state,
        &p.client,
        &mut p.audio
    ));
    assert_eq!(p.state.current_track().unwrap().rating_key, "last");
    // Simulate the new track becoming audible before the outstanding refill finishes.
    p.state.playback.status = PlayStatus::Playing;
    assert!(p.reduce(refill(&["new", "new"])).is_empty());
    assert_eq!(p.state.current_track().unwrap().rating_key, "last");
    assert_eq!(
        p.state.radio.tracks.len(),
        3,
        "deduplicate within the response too"
    );
    assert_eq!(p.state.playback.status, PlayStatus::Playing);
}

#[tokio::test]
async fn next_at_buffer_end_waits_and_advances_once_when_tracks_arrive() {
    let mut p = Player::new();
    p.state.radio.track_index = Some(1);
    p.state.radio.refill = RadioRefill::Prefetching;
    p.state.playback.status = PlayStatus::Stopped;
    p.dispatch(PlaybackAction::Next).await;
    assert_eq!(p.state.radio.refill, RadioRefill::Waiting);
    let actions = p.reduce(refill(&["new"]));
    assert!(matches!(
        actions.as_slice(),
        [Action::Playback(PlaybackAction::Next)]
    ));
    for action in actions {
        p.dispatch(action).await;
    }
    assert_eq!(p.state.current_track().unwrap().rating_key, "new");
    assert!(p.reduce(refill(&["later"])).is_empty());
}

#[tokio::test]
async fn explicit_transport_input_cancels_a_pending_automatic_advance() {
    for action in [
        PlaybackAction::TogglePlayPause,
        PlaybackAction::Previous,
        PlaybackAction::Seek(0),
    ] {
        let mut p = Player::new();
        p.state.radio.refill = RadioRefill::Waiting;
        // Previous at index zero must cancel too, even though there is no previous track.
        p.dispatch(action).await;
        assert_eq!(p.state.radio.refill, RadioRefill::Prefetching);
        assert!(p.reduce(refill(&["new"])).is_empty());
        assert_eq!(p.state.current_track().unwrap().rating_key, "first");
    }
}

#[test]
fn empty_and_duplicate_only_refills_finish_without_an_automatic_retry_loop() {
    for keys in [vec![], vec!["first", "last", "last"]] {
        let mut p = Player::new();
        p.state.radio.refill = RadioRefill::Waiting;
        assert!(p.reduce(refill(&keys)).is_empty());
        assert_eq!(p.state.radio.refill, RadioRefill::Idle);
        assert_eq!(p.state.radio.tracks.len(), 2);
        assert!(p
            .state
            .notifications
            .last_error
            .as_ref()
            .unwrap()
            .contains("no new tracks"));
    }
}

async fn server_response(status: &str, body: &str) -> (PlexClient, tokio::task::JoinHandle<()>) {
    let listener = TcpListener::bind("127.0.0.1:0").await.unwrap();
    let client = PlexClient::new_with_url(
        &format!("http://{}", listener.local_addr().unwrap()),
        Some("fixture-token"),
        "test",
    )
    .unwrap();
    let response = format!(
        "HTTP/1.1 {status}\r\nContent-Length: {}\r\nConnection: close\r\n\r\n{body}",
        body.len()
    );
    let task = tokio::spawn(async move {
        let (mut socket, _) = listener.accept().await.unwrap();
        let mut request = Vec::new();
        while !request.ends_with(b"\r\n\r\n") {
            request.push(socket.read_u8().await.unwrap());
            assert!(request.len() < 16_384);
        }
        socket.write_all(response.as_bytes()).await.unwrap();
    });
    (client, task)
}

#[tokio::test]
async fn failed_station_requests_keep_existing_playback_and_show_safe_errors() {
    for (status, body, expected) in [
        (
            "401 Unauthorized",
            "<html>private server details</html>",
            "Sign in again",
        ),
        (
            "404 Not Found",
            "<html>private server details</html>",
            "could not find",
        ),
        ("200 OK", "not JSON", "invalid"),
    ] {
        let mut p = Player::new();
        let (client, server) = server_response(status, body).await;
        p.client = client;
        p.dispatch(RadioAction::PlayStation(
            station().source.station_key().unwrap().into(),
        ))
        .await;
        assert_eq!(p.state.current_track().unwrap().rating_key, "first");
        assert_eq!(p.state.playback.status, PlayStatus::Playing);
        assert!(p.state.station_starting.is_some());
        assert!(p.receive().await.is_empty());
        assert!(p.state.station_starting.is_none());
        assert_eq!(p.state.current_track().unwrap().rating_key, "first");
        assert_eq!(p.state.playback.status, PlayStatus::Playing);
        let error = p.state.notifications.last_error.as_ref().unwrap();
        assert!(error.contains(expected), "{error}");
        assert!(!error.contains("<html>") && !error.contains("private"));
        server.await.unwrap();
    }
}

#[tokio::test]
async fn stop_rejects_late_station_and_refill_completions() {
    let mut p = Player::new();
    p.state.station_starting = Some(textamp::app::state::StationStart {
        title: "Candidate".into(),
        continue_playback: None,
    });
    p.state.radio.refill = RadioRefill::Waiting;
    let generation = p.state.radio_generation;
    p.dispatch(PlaybackAction::Stop).await;
    for event in [loaded(), refill(&["new"])] {
        assert!(p
            .reduce(Event::RadioResult {
                generation,
                navigation_generation: None,
                event: Box::new(event),
            })
            .is_empty());
    }
    assert!(p.state.station_starting.is_none());
    assert_eq!(p.state.playback.status, PlayStatus::Stopped);
    assert_eq!(p.state.radio.tracks.len(), 2);
    assert_eq!(p.state.current_track().unwrap().rating_key, "first");
}

#[tokio::test]
async fn only_latest_station_can_replace_playback_and_empty_results_preserve_it() {
    let mut p = Player::new();
    // Invalid addresses finish asynchronously without issuing HTTP requests.
    p.dispatch(RadioAction::PlayStation("invalid-a".into()))
        .await;
    let old = p.state.radio_generation;
    p.dispatch(RadioAction::StartArtistRadio {
        key: "artist".into(),
        title: "Artist".into(),
    })
    .await;
    assert!(p
        .reduce(Event::RadioResult {
            generation: old,
            navigation_generation: None,
            event: Box::new(loaded()),
        })
        .is_empty());
    assert_eq!(p.state.current_track().unwrap().rating_key, "first");
    let mut event = loaded();
    if let Event::Radio(RadioEvent::StationTracksLoaded { tracks, .. }) = &mut event {
        tracks.clear();
    }
    assert!(p.reduce(event).is_empty());
    assert_eq!(p.state.current_track().unwrap().rating_key, "first");
    assert_eq!(p.state.playback.status, PlayStatus::Playing);
    assert!(matches!(
        p.reduce(loaded()).as_slice(),
        [Action::Radio(RadioAction::PlayCurrentRadioTrack)]
    ));
    assert_eq!(p.state.current_track().unwrap().rating_key, "replacement");
}

#[tokio::test]
async fn empty_station_category_does_not_start_playback_or_cancel_a_pending_start() {
    let mut p = Player::new();
    let (client, server) =
        server_response("200 OK", r#"{"MediaContainer":{"Directory":[]}}"#).await;
    p.client = client;
    p.state.station_starting = Some(textamp::app::state::StationStart {
        title: "Candidate".into(),
        continue_playback: None,
    });
    p.dispatch(RadioAction::DrillIntoStation(
        "/library/sections/5/mood".into(),
        "Mood".into(),
    ))
    .await;
    // A newer playback generation does not invalidate independent category navigation.
    p.state.radio_generation += 1;
    assert!(p.receive().await.is_empty());
    assert!(!p.state.station_nav.loading);
    assert!(p
        .state
        .station_nav
        .columns
        .last()
        .unwrap()
        .stations
        .is_empty());
    assert_eq!(
        p.state.station_starting.as_ref().map(|s| s.title.as_str()),
        Some("Candidate")
    );
    assert_eq!(p.state.current_track().unwrap().rating_key, "first");
    server.await.unwrap();
}

#[tokio::test]
async fn malformed_station_addresses_fail_before_any_network_request() {
    let mut client = PlexClient::new(Default::default()).unwrap();
    for key in [
        "",
        "plex_radio:123",
        "/library/sections//stations/library",
        "/library/sections/5/mood",
        "/library/sections/5/stations/",
        "/library/sections/5/stations/library/extra",
        "/library/sections/5/stations/mood?id=",
        "/library/sections/5/stations/library?id=42",
        "/library/sections/5/stations/library#fragment",
        "https://elsewhere/stations/library",
    ] {
        assert!(
            matches!(
                client.create_station_queue(key).await,
                Err(ApiError::ParseError(_))
            ),
            "{key}"
        );
    }
}

#[test]
fn server_errors_have_actionable_messages_without_server_bodies() {
    for (status, expected) in [
        (401, "Sign in"),
        (403, "denied"),
        (404, "could not find"),
        (429, "rate limiting"),
        (503, "Try again"),
        (418, "rejected"),
    ] {
        let error = ApiError::ServerError {
            status,
            message: "<html>private detail</html>".into(),
        };
        let message = error.user_message("Radio");
        assert!(message.contains(expected), "{message}");
        assert!(!message.contains("private") && !message.contains("html"));
        assert!(
            !error.is_connection_error(),
            "HTTP errors must not trigger route recovery"
        );
    }
}

#[tokio::test]
async fn pause_cancels_station_start_without_stopping_current_music_context() {
    let mut p = Player::new();
    p.state.station_starting = Some(textamp::app::state::StationStart {
        title: "Candidate".into(),
        continue_playback: None,
    });
    let generation = p.state.radio_generation;
    p.dispatch(PlaybackAction::TogglePlayPause).await;
    assert_eq!(p.state.playback.status, PlayStatus::Paused);
    assert!(p.state.station_starting.is_none());
    assert!(p
        .reduce(Event::RadioResult {
            generation,
            navigation_generation: None,
            event: Box::new(loaded()),
        })
        .is_empty());
    assert_eq!(p.state.current_track().unwrap().rating_key, "first");
}

#[tokio::test]
async fn stop_is_available_in_the_palette_and_cancels_station_loading() {
    let mut p = Player::new();
    p.state.station_starting = Some(textamp::app::state::StationStart {
        title: "Candidate".into(),
        continue_playback: None,
    });
    let entry = textamp::app::command_palette::materialize_entries(&p.state)
        .into_iter()
        .find(|entry| entry.label == "Stop Playback")
        .unwrap();
    let actions = textamp::app::command_palette::run(entry.command, &mut p.state);
    for action in actions {
        p.dispatch(action).await;
    }
    assert!(p.state.station_starting.is_none());
    assert_eq!(p.state.playback.status, PlayStatus::Stopped);
}

#[tokio::test]
async fn network_timeouts_finish_station_and_refill_loading_without_losing_tracks() {
    for refill_request in [false, true] {
        let listener = TcpListener::bind("127.0.0.1:0").await.unwrap();
        let mut p = Player::new();
        p.client = PlexClient::new_with_url_and_timeout(
            &format!("http://{}", listener.local_addr().unwrap()),
            Some("fixture-token"),
            "test",
            1,
        )
        .unwrap();
        let server = tokio::spawn(async move {
            let mut connections = Vec::new();
            loop {
                connections.push(listener.accept().await.unwrap().0);
                // Intentionally never respond, including to bounded GET retries.
            }
        });
        if refill_request {
            p.state.radio.active_station = Some(station());
            textamp::app::sources::radio::refill(&p.tx, &mut p.state, &p.client);
        } else {
            p.dispatch(RadioAction::PlayStation(
                station().source.station_key().unwrap().into(),
            ))
            .await;
        }
        let event = tokio::time::timeout(Duration::from_secs(12), p.rx.recv())
            .await
            .unwrap()
            .unwrap();
        let actions = p.reduce(event);
        assert!(matches!(
            actions.as_slice(),
            [Action::System(
                textamp::app::action::SystemAction::RecoverConnection
            )]
        ));
        assert!(p.state.station_starting.is_none());
        assert_eq!(p.state.radio.refill, RadioRefill::Idle);
        assert_eq!(p.state.current_track().unwrap().rating_key, "first");
        assert_eq!(p.state.playback.status, PlayStatus::Playing);
        assert!(p.state.notifications.last_error.is_some());
        server.abort();
        let _ = server.await;
    }
}

#[tokio::test]
async fn malformed_category_responses_are_not_successful_empty_categories() {
    for body in [r#"{}"#, r#"{"MediaContainer":{"Directory":{}}}"#] {
        let (client, server) = server_response("200 OK", body).await;
        assert!(matches!(
            client
                .get_station_children("/library/sections/5/mood")
                .await,
            Err(ApiError::ParseError(_))
        ));
        server.await.unwrap();
    }
}

#[test]
fn library_changes_clear_loading_for_requests_whose_results_will_be_discarded() {
    let mut p = Player::new();
    p.state.station_starting = Some(textamp::app::state::StationStart {
        title: "Candidate".into(),
        continue_playback: None,
    });
    p.state.station_nav.loading = true;
    p.state.radio.refill = RadioRefill::Waiting;
    p.state.advance_library_generation();
    assert!(p.state.station_starting.is_none());
    assert!(!p.state.station_nav.loading);
    assert_eq!(p.state.radio.refill, RadioRefill::Idle);
}

#[tokio::test]
async fn cached_category_drill_clears_loading_from_the_request_it_supersedes() {
    let mut p = Player::new();
    p.state.stations_loading = true;
    p.state.station_nav.loading = true;
    let key = "/library/sections/5/mood";
    p.state.station_children_cache.insert(key.into(), vec![]);
    p.dispatch(RadioAction::DrillIntoStation(key.into(), "Mood".into()))
        .await;
    assert!(!p.state.stations_loading);
    assert!(!p.state.station_nav.loading);
    assert!(p
        .state
        .station_nav
        .columns
        .last()
        .unwrap()
        .stations
        .is_empty());
}
