use std::time::Duration;
use textamp::app::action::{AsyncError, SearchAction};
use textamp::app::dispatch::handle_core_event;
use textamp::app::event::{CacheEvent, DataEvent, FolderEvent, PreloadEvent, TrackSearchTarget};
use textamp::app::handlers::{dispatch_search, helpers};
use textamp::app::state::{BrowseCategory, BrowseColumn, RefreshCategory, SearchTab, View};
use textamp::app::{AppState, Event};
use textamp::plex::models::Genre;
use textamp::plex::{CachedFolder, PlexClient, PlexClientInfo};
use tokio::sync::mpsc;

fn client() -> PlexClient {
    PlexClient::new(PlexClientInfo::default()).unwrap()
}

fn reduce(state: &mut AppState, event: impl Into<Event>) {
    let (tx, _rx) = mpsc::channel(8);
    handle_core_event(event.into(), state, &mut client(), &tx);
}

#[tokio::test]
async fn failed_refresh_does_not_make_stale_data_fresh() {
    let mut state = AppState::new();
    state.active_library = Some("1".into());
    state
        .cache_mgmt
        .category_timestamps
        .insert(RefreshCategory::Moods, 17);
    let (tx, mut rx) = mpsc::channel(8);
    helpers::spawn_category_refresh(&tx, RefreshCategory::Moods, "1", &mut state, &client());
    let event = tokio::time::timeout(Duration::from_secs(2), rx.recv())
        .await
        .unwrap()
        .unwrap();
    reduce(&mut state, event);
    assert_eq!(
        state.cache_mgmt.category_timestamps[&RefreshCategory::Moods],
        17
    );
    assert!(!state
        .cache_mgmt
        .background_refresh
        .contains(&RefreshCategory::Moods));
    assert!(!state.cache_mgmt.dirty);
    assert!(state.notifications.last_error.is_some());
}

#[test]
fn failed_cache_save_is_retryable_and_stale_completion_is_ignored() {
    let mut state = AppState::new();
    state.cache_mgmt.save_in_progress = true;
    reduce(
        &mut state,
        CacheEvent::CacheSaved {
            result: Err("disk full".into()),
        },
    );
    assert!(!state.cache_mgmt.save_in_progress);
    assert!(state.cache_mgmt.dirty);
    assert_eq!(state.notifications.last_error.as_deref(), Some("disk full"));

    let old_generation = state.library_generation;
    state.advance_library_generation();
    state.cache_mgmt.save_in_progress = true;
    reduce(
        &mut state,
        Event::for_library(old_generation, CacheEvent::CacheSaved { result: Ok(()) }),
    );
    assert!(state.cache_mgmt.save_in_progress);
    // A successful save must not clear edits made after its snapshot.
    reduce(&mut state, CacheEvent::CacheSaved { result: Ok(()) });
    assert!(state.cache_mgmt.dirty);
}

#[test]
fn tag_refresh_replaces_cached_values_without_resetting_navigation() {
    let mut state = AppState::new();
    state.active_library = Some("1".into());
    state.browse_category = BrowseCategory::Moods;
    let old: Genre = serde_json::from_str(r#"{"key":"old","title":"Old"}"#).unwrap();
    state.library.moods.push(old);
    state
        .tag_nav
        .columns
        .push(BrowseColumn::new("moods", vec![]));
    state
        .tag_nav
        .columns
        .push(BrowseColumn::new("albums", vec![]));
    state.tag_nav.focused_column = 1;
    let fresh: Genre = serde_json::from_str(r#"{"key":"new","title":"New"}"#).unwrap();
    reduce(
        &mut state,
        PreloadEvent::MoodsPreloaded {
            library_key: "1".into(),
            moods: vec![fresh],
        },
    );
    assert_eq!(state.library.moods[0].title, "New");
    assert_eq!(state.tag_nav.columns.len(), 2);
    assert_eq!(state.tag_nav.focused_column, 1);
    reduce(
        &mut state,
        PreloadEvent::MoodsPreloaded {
            library_key: "1".into(),
            moods: vec![],
        },
    );
    assert!(state.library.moods.is_empty());
    assert!(state.tag_nav.columns[0].items.is_empty());
}

#[tokio::test]
async fn incomplete_folder_crawl_preserves_unseen_cache_entries() {
    let mut state = AppState::new();
    state.active_library = Some("1".into());
    state.subfolder_preload = Some(pending_lease());
    state
        .folder_contents_cache
        .insert("unseen".into(), CachedFolder::new(vec![]));
    reduce(
        &mut state,
        FolderEvent::SubfoldersPreloaded {
            library_key: "1".into(),
            request_id: 0,
            entries: vec![],
            done: true,
        },
    );
    assert!(state.subfolder_preload.is_none());
    assert!(state.folder_contents_cache.contains_key("unseen"));
    state.subfolder_preload = Some(pending_lease());
    state.subfolder_preload_id = 1;
    reduce(
        &mut state,
        FolderEvent::SubfoldersPreloaded {
            library_key: "1".into(),
            request_id: 0,
            entries: vec![],
            done: true,
        },
    );
    assert!(state.subfolder_preload.is_some());
}

#[tokio::test]
async fn shortening_search_invalidates_pending_success_and_failure() {
    let mut state = AppState::new();
    state.search.tab = SearchTab::Tracks;
    state.search.query = "music".into();
    let (tx, _rx) = mpsc::channel(8);
    let mut client = client();
    dispatch_search::dispatch(
        &tx,
        SearchAction::ExecuteLocalSearch,
        &mut state,
        &mut client,
    )
    .await
    .unwrap();
    let old_version = state.search.track_version;
    assert!(state.search.track_loading);
    state.search.query = "m".into();
    dispatch_search::dispatch(
        &tx,
        SearchAction::ExecuteLocalSearch,
        &mut state,
        &mut client,
    )
    .await
    .unwrap();
    assert_ne!(state.search.track_version, old_version);
    for result in [
        Ok(vec![]),
        Err(AsyncError {
            message: "old error".into(),
            connection_error: false,
        }),
    ] {
        reduce(
            &mut state,
            DataEvent::TrackSearchCompleted {
                target: TrackSearchTarget::Main,
                version: old_version,
                result,
            },
        );
    }
    assert!(!state.search.track_loading);
    assert!(state.notifications.last_error.is_none());
}

#[tokio::test]
async fn reopened_adventure_rejects_old_search_and_surfaces_current_failure() {
    let mut state = AppState::new();
    let mut client = client();
    let (tx, _rx) = mpsc::channel(8);
    let mut versions = Vec::new();
    for _ in 0..2 {
        dispatch_search::dispatch(
            &tx,
            SearchAction::OpenAdventureLauncher,
            &mut state,
            &mut client,
        )
        .await
        .unwrap();
        state.popups.adventure_launcher.as_mut().unwrap().query = "music".into();
        dispatch_search::dispatch(
            &tx,
            SearchAction::AdventureLauncherSearch,
            &mut state,
            &mut client,
        )
        .await
        .unwrap();
        versions.push(
            state
                .popups
                .adventure_launcher
                .as_ref()
                .unwrap()
                .search_version,
        );
    }
    assert_ne!(versions[0], versions[1]);
    reduce(
        &mut state,
        DataEvent::TrackSearchCompleted {
            target: TrackSearchTarget::Adventure,
            version: versions[0],
            result: Ok(vec![]),
        },
    );
    assert!(state.popups.adventure_launcher.as_ref().unwrap().loading);
    reduce(
        &mut state,
        DataEvent::TrackSearchCompleted {
            target: TrackSearchTarget::Adventure,
            version: versions[1],
            result: Err(AsyncError {
                message: "search failed".into(),
                connection_error: false,
            }),
        },
    );
    assert!(!state.popups.adventure_launcher.as_ref().unwrap().loading);
    assert_eq!(
        state.notifications.last_error.as_deref(),
        Some("search failed")
    );
}

#[test]
fn principal_views_render_at_small_and_normal_terminal_sizes() {
    use ratatui::{backend::TestBackend, Terminal};
    for (width, height) in [(40, 10), (80, 24), (120, 40)] {
        let mut terminal = Terminal::new(TestBackend::new(width, height)).unwrap();
        let mut state = AppState::new();
        state.terminal_width = width;
        state.terminal_height = height;
        for view in [
            View::Browse,
            View::Queue,
            View::NowPlaying,
            View::Help,
            View::Settings,
        ] {
            state.view = view;
            terminal
                .draw(|frame| {
                    let _ = textamp::ui::render(frame, &state);
                })
                .unwrap();
        }
    }
}

#[tokio::test]
async fn refresh_applies_server_data_before_marking_it_fresh() {
    use tokio::io::{AsyncReadExt, AsyncWriteExt};
    let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
    let url = format!("http://{}", listener.local_addr().unwrap());
    let server = tokio::spawn(async move {
        let (mut socket, _) = listener.accept().await.unwrap();
        let mut request = [0; 4096];
        assert!(socket.read(&mut request).await.unwrap() > 0);
        let body = r#"{"MediaContainer":{"Directory":[{"key":"1","title":"Happy"}]}}"#;
        let response = format!("HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nContent-Length: {}\r\nConnection: close\r\n\r\n{}", body.len(), body);
        socket.write_all(response.as_bytes()).await.unwrap();
    });
    let mut state = AppState::new();
    state.active_library = Some("1".into());
    let client = PlexClient::new_with_url(&url, Some("test"), "test").unwrap();
    let (tx, mut rx) = mpsc::channel(8);
    helpers::spawn_category_refresh(&tx, RefreshCategory::Moods, "1", &mut state, &client);
    for _ in 0..1 {
        let event = tokio::time::timeout(Duration::from_secs(2), rx.recv())
            .await
            .unwrap()
            .unwrap();
        reduce(&mut state, event);
    }
    assert_eq!(state.library.moods[0].title, "Happy");
    assert!(state
        .cache_mgmt
        .category_timestamps
        .contains_key(&RefreshCategory::Moods));
    assert!(!state
        .cache_mgmt
        .background_refresh
        .contains(&RefreshCategory::Moods));
    server.await.unwrap();
}

#[tokio::test]
async fn absent_audio_device_returns_failure_without_starting_playback() {
    let mut audio = textamp::audio::AudioPlayer::new_without_audio();
    let (tx, _rx) = mpsc::channel(1);
    let error = audio
        .play_url("http://127.0.0.1:1/audio", tx, reqwest::Client::new())
        .unwrap_err();
    assert!(error.to_string().contains("No audio output device"));
    assert!(!audio.is_playing());
}

#[tokio::test]
async fn changing_library_cancels_owned_work_and_discards_old_progress() {
    let mut state = AppState::new();
    state.cache_mgmt.save_in_progress = true;
    state
        .cache_mgmt
        .background_refresh
        .insert(RefreshCategory::Moods);
    state.subfolder_preload = Some(pending_lease());
    state.advance_library_generation();
    assert!(state.subfolder_preload.is_none());
    assert!(!state.cache_mgmt.save_in_progress);
    assert!(state.cache_mgmt.background_refresh.is_empty());
}

fn pending_lease() -> textamp::app::tasks::TaskLease {
    textamp::app::tasks::TaskLease::new(&tokio::spawn(std::future::pending::<()>()))
}
