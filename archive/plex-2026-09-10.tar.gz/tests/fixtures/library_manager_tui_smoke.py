"""Opt-in live manager/WebDAV smoke in private, disposable user-data copies.

Usage: uv run --python 3.12 --with pyte python library_manager_tui_smoke.py /path/to/textamp --live
Starts in a disposable local folder; never selects Navidrome, plays audio, or
edits server data. Launching the app still initializes its normal audio backend.
"""
import fcntl
import codecs
import json
import os
import pathlib
import pty
import re
import select
import shutil
import signal
import struct
import subprocess
import sys
import tempfile
import termios
import time
import tomllib
import pyte

assert sys.argv[2:] == ["--live"], "Requires explicit --live"
with tempfile.TemporaryDirectory(prefix="textamp-library-manager-") as temporary:
    root = pathlib.Path(temporary)
    data = root / "data" / "textamp"
    data.mkdir(parents=True, mode=0o700)
    original = pathlib.Path.home() / "Library/Application Support/textamp"
    for name in ("config.toml", "auth.toml", "plex-libraries.json", "folder-credentials.toml"):
        shutil.copyfile(original / name, data / name)
        (data / name).chmod(0o600)
    shutil.copytree(original / "accounts", data / "accounts")
    # Force a disposable local startup without changing saved live sources.
    fixture_music = root / "Fixture music"
    fixture_music.mkdir()
    (fixture_music / "Smoke local").mkdir()  # Visible startup row; no audio files.
    config_path = data / "config.toml"
    config_text = config_path.read_text()
    config_text = re.sub(r'^default_folder_source\s*=.*\n', '', config_text, flags=re.M)
    config_text = re.sub(r'^\[default_navidrome\]\n[^\[]*', '', config_text, flags=re.M)
    config_text = 'default_folder_source = "smoke-local"\n' + config_text
    config_text += '\n[[folder_sources]]\nid = "smoke-local"\nname = "Smoke local"\nkind = "local"\npath = ' + json.dumps(str(fixture_music)) + '\n'
    parsed = tomllib.loads(config_text)
    assert "default_navidrome" not in parsed
    config_path.write_text(config_text)
    accounts = json.loads((data / "plex-libraries.json").read_text())
    assert accounts, "Live smoke requires a saved Plex account"
    env = os.environ.copy()
    # The command runner may set NO_COLOR even though this child has a PTY.
    # This smoke explicitly verifies the application's visible focus colors.
    env.pop("NO_COLOR", None)
    for name in ("XDG_CONFIG_HOME", "XDG_DATA_HOME"):
        env[name] = str(root / "data")
    for name in ("XDG_CACHE_HOME", "XDG_STATE_HOME"):
        env[name] = str(root / name)
    env["TERM"] = "xterm-256color"
    env["TERM_PROGRAM"] = "Apple_Terminal"
    master, slave = pty.openpty()
    fcntl.ioctl(slave, termios.TIOCSWINSZ, struct.pack("HHHH", 40, 150, 0, 0))
    before = termios.tcgetattr(slave)
    process = subprocess.Popen([sys.argv[1]], stdin=slave, stdout=slave, stderr=slave, env=env)
    output = bytearray()
    screen = pyte.Screen(150, 40)
    stream = pyte.Stream(screen)
    decoder = codecs.getincrementaldecoder("utf-8")("replace")

    def wait_for(text):
        def normalize(value):
            return re.sub(rb"\s+", b"", re.sub(rb"\x1b\[[0-9;?]*[a-zA-Z]", b"", value))
        deadline = time.monotonic() + 30
        def visible():
            return "\n".join(screen.display).encode()
        while normalize(text) not in normalize(visible()) and time.monotonic() < deadline:
            if select.select([master], [], [], 0.1)[0]:
                chunk = os.read(master, 65536)
                output.extend(chunk)
                stream.feed(decoder.decode(chunk))
            if process.poll() is not None:
                break
        assert normalize(text) in normalize(visible()), f"UI missing {text!r}; exit={process.poll()}; screen={screen.display!r}"

    def wait_until(predicate, description):
        deadline = time.monotonic() + 10
        while not predicate() and time.monotonic() < deadline:
            if select.select([master], [], [], 0.1)[0]:
                chunk = os.read(master, 65536)
                stream.feed(decoder.decode(chunk))
        assert predicate(), f"{description}; screen={screen.display!r}"

    def library_border_colors():
        # The switcher may retain category or folder-column focus. Both are
        # library input owners; do not assume the folder column is selected.
        return tuple(screen.buffer[0][x].fg for x in range(screen.columns))

    try:
        wait_for(b"Smoke local")
        os.write(master, b"\x1bOR")  # F3: compact switcher
        wait_for(b"Switch library")
        os.write(master, b"\x1bOQ")  # F2: embedded Settings manager
        for text in (b"Libraries", b"Accounts", b"Add library", b"Beatles", b"WebDAV", b"Navidrome", b"spoken", b"Plex"):
            wait_for(text)
        print("Settings: Plex libraries, Beatles WebDAV and Navidrome visible together")
        wait_for(b"Active: Smoke local")
        os.write(master, b"\t\x1b[B\t")  # Sidebar -> Textamp -> content
        wait_for(b"theme:")
        os.write(master, b"\x1b[Z\x1b[A\t")  # Shift+Tab -> sidebar -> Libraries -> content
        wait_for(b"Active: Smoke local")
        os.write(master, b"\x1b[C")  # Right changes library tabs, not pane focus
        wait_for(accounts[0]["name"].encode())
        os.write(master, b"\x1b[D\x1b[D\x1b[B\x1b[C")  # Accounts -> Libraries -> sidebar -> Textamp
        wait_for(b"theme:")
        os.write(master, b"\x1b[D\x1b[A\x1b[C\x1b[C")  # Sidebar -> Libraries -> Accounts
        wait_for(accounts[0]["name"].encode())
        os.write(master, b"\x1b[C")
        for text in (b"Local folder", b"WebDAV share", b"Plex library", b"Navidrome library"):
            wait_for(text)
        os.write(master, b"\x1b[H\x1b[B\r")  # WebDAV form, no entries saved
        for text in (b"Add WebDAV library", b"URL", b"Username", b"Password", b"Name (optional)", b"[ Cancel ]"):
            wait_for(text)
        os.write(master, b"\x1b")
        wait_for(b"WebDAV share")
        print("Accounts and Add library sections verified")
        os.write(master, b"\x1b[D")  # Add -> Accounts, never straight to the sidebar
        wait_for(accounts[0]["name"].encode())
        os.write(master, b"\r")
        wait_for(b"[ Sign out ]")
        wait_for(b"[ Cancel ]")
        os.write(master, b"\r")  # Cancel is initially selected; never sign out
        wait_for(b"Enter")
        os.write(master, b"\x1b[D")  # Accounts -> Libraries
        wait_for(b"[Active] Smoke local")
        # A single-folder Navidrome account no longer adds an All music row.
        aggregate_rows = sum(len(source.get("libraries", [])) != 1 for source in parsed.get("navidrome_sources", []))
        os.write(master, b"\x1b[H" + b"\x1b[B" * aggregate_rows + b"\r")
        wait_for(b"Albums - Official UK and US")
        print("Beatles WebDAV opened and listed through the TUI")
        if not parsed.get("ui", {}).get("tall_mode", False):
            os.write(master, b"|")
        wait_for(b"waveform")
        focused_library_colors = library_border_colors()
        assert len(set(focused_library_colors)) > 1, "PTY did not render focus colors"
        for _ in range(2):
            os.write(master, b"\t")
            wait_until(lambda: library_border_colors() != focused_library_colors, "Tab did not transfer visible focus away from WebDAV")
            os.write(master, b"\x1b[Z")
            wait_until(lambda: library_border_colors() == focused_library_colors, "Shift+Tab did not restore visible WebDAV focus")
        print("Split-mode Tab/Shift+Tab focus round trips verified on live WebDAV")
        output.clear()
        os.write(master, b"\x1bOR")
        for text in (b"spoken", b"WebDAV", b"Navidrome"):
            wait_for(text)
        print("All sources remain available after selecting WebDAV")
        # Exercise the corrected archive entry as well, not just the original share.
        archive = next((s for s in parsed["folder_sources"] if s["name"] == "beatles archive"), None)
        if archive:
            assert archive["url"].startswith("http://"), "Archive still uses HTTPS on the HTTP port"
            labels = [s["name"] for s in parsed["folder_sources"]]
            labels += [f'{lib["title"]} / {lib["server_name"]}' for account in accounts for lib in account["libraries"]]
            for source in parsed.get("navidrome_sources", []):
                names = [lib["name"] for lib in source.get("libraries", [])]
                if len(names) != 1:
                    names.append("All music")
                labels += [f'{name} / {source["name"]}' if name != source["name"] else name for name in names]
            archive_index = sorted(labels, key=str.lower).index(archive["name"])
            os.write(master, b"\x1b[H" + b"\x1b[B" * archive_index + b"\r")
            wait_for(b"Albums - Official UK and US")
            os.write(master, b"\x1bOQ")
            wait_for(b"Active: beatles archive")
            os.write(master, b"\x1b")
            wait_for(b"Albums - Official UK and US")
            print("Corrected beatles archive entry opened through the TUI")
        process.send_signal(signal.SIGTERM)
        deadline = time.monotonic() + 10
        while process.poll() is None and time.monotonic() < deadline:
            if select.select([master], [], [], 0.1)[0]:
                os.read(master, 65536)
        assert process.poll() == 0, "Unclean shutdown"
        after = termios.tcgetattr(slave)
        assert before == after, "Terminal settings not restored"
        print("Clean shutdown and terminal restoration verified")
    finally:
        if process.poll() is None:
            process.kill()
            process.wait()
        os.close(master)
        os.close(slave)
