use std::time::Duration;

use crossterm::event::{KeyCode, KeyEvent, KeyModifiers, MouseButton, MouseEvent, MouseEventKind};
use ratatui::{backend::TestBackend, Terminal};
use textamp::app::action::{QueueAction, RadioAction, SearchAction};
use textamp::app::command_palette::{self, PaletteOutcome};
use textamp::app::dispatch::{dispatch_action, handle_core_event};
use textamp::app::handlers::{helpers, key_input, mouse_input};
use textamp::app::state::{
    ActiveStation, BrowseCategory, BrowseColumn, BrowseItem, PaletteCommandKind, PlaybackMode,
    StationColumn, View,
};
use textamp::app::{Action, AppState};
use textamp::audio::AudioPlayer;
use textamp::config::Config;
use textamp::plex::models::{Station, Track};
use textamp::plex::PlexClient;
use tokio::io::{AsyncReadExt, AsyncWriteExt};
use tokio::net::TcpListener;
use tokio::sync::mpsc;

fn track(key: &str) -> Track {
    serde_json::from_value(serde_json::json!({"ratingKey":key,"title":key})).unwrap()
}

fn station(key: &str, title: &str, kind: &str) -> Station {
    serde_json::from_value(serde_json::json!({"key":key,"title":title,"type":kind})).unwrap()
}

fn column(keys: &[&str]) -> BrowseColumn {
    let tracks: Vec<_> = keys.iter().map(|key| track(key)).collect();
    BrowseColumn::new_with_tracks("tracks", BrowseItem::from_tracks(&tracks), tracks)
}

fn run_label(state: &mut AppState, label: &str) -> Vec<Action> {
    let entry = command_palette::materialize_entries(state)
        .into_iter()
        .find(|entry| entry.label == label)
        .unwrap_or_else(|| panic!("Missing command {label}"));
    command_palette::run(entry.command, state)
}

#[test]
fn track_context_and_palette_start_sonic_radio_from_the_focused_track() {
    let mut state = AppState::new();
    state.view = View::Queue;
    state.queue.tracks = vec![track("playing"), track("selected")];
    state.queue.index = Some(0);
    state.list_state.queue_index = 1;
    let entries =
        textamp::services::track_context::track_context_entries(&state, &track("selected"), false);
    assert!(entries.iter().any(|e| matches!(
        e.kind,
        textamp::services::track_context::ContextKind::SonicRadio
    )));
    let actions = run_label(&mut state, "Start Sonic Radio based on track");
    assert!(
        matches!(actions.as_slice(), [Action::Radio(RadioAction::StartSonicRadio(track))] if track.rating_key == "selected")
    );
    state.sources.active = textamp::app::sources::ActiveSource::Folder("local".into());
    assert!(!command_palette::materialize_entries(&state)
        .iter()
        .any(|e| e.label == "Start Sonic Radio based on track"));
}

fn keys(tracks: &[Track]) -> Vec<&str> {
    tracks
        .iter()
        .map(|track| track.rating_key.as_str())
        .collect()
}

#[test]
fn colon_q_enter_quits_from_browse_and_playback_views() {
    for view in [View::Browse, View::Queue, View::NowPlaying] {
        for query in ['q', 'Q'] {
            let mut state = AppState::new();
            state.view = view;
            let config = Config::default();
            for code in [KeyCode::Char(':'), KeyCode::Char(query)] {
                assert!(key_input::handle_key(
                    KeyEvent::new(code, KeyModifiers::NONE),
                    &mut state,
                    &config,
                )
                .is_empty());
            }
            assert!(state.palette.open);
            let first = state.palette.matches[0];
            assert!(matches!(
                state.palette.entries[first].command,
                PaletteCommandKind::Quit
            ));
            let actions = key_input::handle_key(
                KeyEvent::new(KeyCode::Enter, KeyModifiers::NONE),
                &mut state,
                &config,
            );
            assert!(matches!(
                actions.as_slice(),
                [Action::System(textamp::app::action::SystemAction::Quit)]
            ));
            assert!(!state.palette.open);
        }
    }
}

#[test]
fn queue_query_still_ranks_queue_first() {
    let mut state = AppState::new();
    for query in ["queue", "Queue"] {
        command_palette::open_with_query(&mut state, query);
        let first = state.palette.matches[0];
        assert_eq!(state.palette.entries[first].label, "Queue");
    }
}

#[test]
fn every_browse_track_list_plays_its_visible_tail_not_a_hidden_library_column() {
    for &category in BrowseCategory::all() {
        if category == BrowseCategory::Folders {
            continue; // Folder items do not carry full Track objects.
        }
        let mut state = AppState::new();
        state.view = View::Browse;
        state.category_column_focused = false;
        state.browse_category = category;
        state.artist_nav.columns.push(column(&["hidden-library"]));
        let mut visible = column(&["before", "selected", "after"]);
        visible.selected_index = 1;
        state.browse_nav_mut().unwrap().columns = vec![visible];
        let actions = run_label(&mut state, "Play track and following");
        assert!(
            matches!(actions.as_slice(), [Action::Queue(QueueAction::PlayTracksNow(tracks))]
            if keys(tracks) == ["selected", "after"]),
            "{category:?}: {actions:?}"
        );
    }
}

#[test]
fn queue_and_radio_contexts_ignore_retained_browse_and_similar_selections() {
    for view in [View::Queue, View::NowPlaying] {
        for mode in [PlaybackMode::Queue, PlaybackMode::Radio] {
            let mut state = AppState::new();
            state.view = view;
            state.playback_mode = mode;
            state.artist_nav.columns.push(column(&["hidden-library"]));
            state.track_pane_focused = true;
            state.track_pane_index = 1;
            state
                .track_pane_similar
                .insert("hidden-library".into(), Ok(vec![track("hidden-similar")]));
            state.queue.tracks = vec![track("queue-0"), track("queue-1"), track("queue-2")];
            state.radio.tracks = vec![track("radio-0"), track("radio-1"), track("radio-2")];
            state.list_state.queue_index = 1;
            let expected = if mode == PlaybackMode::Radio {
                ["radio-1", "radio-2"]
            } else {
                ["queue-1", "queue-2"]
            };
            assert!(!state.palette_target_is_similar());
            assert_eq!(
                state.palette_target_track().unwrap().rating_key,
                expected[0]
            );
            let actions = run_label(&mut state, "Play track and following");
            assert!(
                matches!(actions.as_slice(), [Action::Queue(QueueAction::PlayTracksNow(tracks))]
                if keys(tracks) == expected)
            );
            let actions = run_label(&mut state, "Play track");
            assert!(
                matches!(actions.as_slice(), [Action::Queue(QueueAction::PlayTrack(track))]
                if track.rating_key == expected[0])
            );
        }
    }
}

#[test]
fn unrelated_views_and_invalid_rows_do_not_offer_hidden_track_or_album_commands() {
    let mut state = AppState::new();
    state.artist_nav.columns.push(column(&["hidden"]));
    for view in [
        View::Search,
        View::Help,
        View::Settings,
        View::Similar,
        View::Related,
    ] {
        state.view = view;
        assert!(state.palette_target_track().is_none());
        assert!(!command_palette::materialize_entries(&state)
            .iter()
            .any(|e| e.label == "Play track"));
    }
    state.view = View::Queue;
    state.queue.tracks = vec![track("only")];
    state.list_state.queue_index = 99;
    assert!(state.palette_target_track().is_none());
    assert!(
        command_palette::run(PaletteCommandKind::PlayFocusedTrackAndFollowing, &mut state)
            .is_empty()
    );
}

#[test]
fn refresh_palette_matches_f5_in_every_category() {
    for &category in BrowseCategory::all() {
        let mut state = AppState::new();
        state.view = View::Browse;
        state.browse_category = category;
        let palette = command_palette::run(PaletteCommandKind::Refresh, &mut state);
        let key = key_input::handle_key(
            KeyEvent::new(KeyCode::F(5), KeyModifiers::NONE),
            &mut state,
            &Config::default(),
        );
        assert_eq!(format!("{palette:?}"), format!("{key:?}"), "{category:?}");
    }
}

#[test]
fn utility_rows_are_native_commands_not_station_urls_in_both_playback_views() {
    for view in [View::Queue, View::NowPlaying] {
        let mut state = AppState::new();
        state.view = view;
        state.stations.push(station(
            "/library/sections/5/stations/randomAlbum",
            "Random Album Radio",
            "station",
        ));
        helpers::append_station_action_items(&mut state.stations, false);
        let entries = command_palette::materialize_entries(&state);
        assert_eq!(
            entries
                .iter()
                .filter(|e| matches!(e.command, PaletteCommandKind::ToggleDj(_)))
                .count(),
            6
        );
        for entry in entries {
            if let PaletteCommandKind::PlayStation(key) = entry.command {
                assert_eq!(key, "/library/sections/5/stations/randomAlbum");
            }
        }
        assert!(matches!(
            run_label(&mut state, "Artist Radio").as_slice(),
            [Action::Search(SearchAction::OpenArtistRadioPicker)]
        ));
        assert!(command_palette::materialize_entries(&state)
            .iter()
            .any(|e| matches!(e.command, PaletteCommandKind::RemixGemini)));
        assert!(!command_palette::materialize_entries(&state)
            .iter()
            .any(|e| e.label.contains("Friendg")));
    }
}

#[tokio::test]
async fn radio_removal_uses_the_active_list_even_when_the_old_queue_is_empty() {
    let mut state = AppState::new();
    state.view = View::Queue;
    state.playback_mode = PlaybackMode::Radio;
    state.radio.tracks = vec![track("keep"), track("remove")];
    state.radio.track_index = Some(0);
    state.list_state.queue_index = 1;
    let actions = command_palette::run(PaletteCommandKind::RemoveFocusedFromQueue, &mut state);
    assert!(matches!(
        actions.as_slice(),
        [Action::Queue(QueueAction::RemoveFromQueue(1))]
    ));
    let mut client = PlexClient::new(Default::default()).unwrap();
    let mut audio = AudioPlayer::new_without_audio();
    let mut config = Config::default();
    let (tx, _) = mpsc::channel(8);
    for action in actions {
        dispatch_action(
            action,
            &mut state,
            &mut client,
            &mut audio,
            &mut config,
            &tx,
        )
        .await
        .unwrap();
    }
    assert_eq!(keys(&state.queue.tracks), ["keep"]);
    assert_eq!(state.current_track().unwrap().rating_key, "keep");
    assert!(state.queue.undo_snapshot.is_some());
}

async fn reply(listener: &TcpListener, body: &str) -> String {
    let (mut stream, _) = listener.accept().await.unwrap();
    let mut request = Vec::new();
    while !request.ends_with(b"\r\n\r\n") {
        request.push(stream.read_u8().await.unwrap());
        assert!(request.len() < 16_384);
    }
    let response = format!("HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nContent-Length: {}\r\nConnection: close\r\n\r\n{body}", body.len());
    stream.write_all(response.as_bytes()).await.unwrap();
    String::from_utf8(request).unwrap()
}

#[tokio::test]
async fn artist_radio_refill_uses_metadata_not_a_synthetic_station_url() {
    let listener = TcpListener::bind("127.0.0.1:0").await.unwrap();
    let mut client = PlexClient::new_with_url(
        &format!("http://{}", listener.local_addr().unwrap()),
        Some("test"),
        "test",
    )
    .unwrap();
    let server = tokio::spawn(async move {
        assert!(reply(
            &listener,
            r#"{"MediaContainer":{"machineIdentifier":"server"}}"#
        )
        .await
        .starts_with("GET / HTTP"));
        let request = reply(
            &listener,
            r#"{"MediaContainer":{"Metadata":[{"ratingKey":"next","title":"Next"}]}}"#,
        )
        .await;
        assert!(request.starts_with("POST /playQueues?"));
        assert!(request.contains("%2Flibrary%2Fmetadata%2Fartist-123"));
        assert!(!request.contains("plex_radio"));
    });
    let mut state = AppState::new();
    state.playback_mode = PlaybackMode::Radio;
    state.radio.active_station = Some(ActiveStation {
        source: textamp::plex::models::RadioSource::Artist("artist-123".into()),
        title: "Artist".into(),
    });
    state.radio.tracks = vec![track("first")];
    let (tx, mut rx) = mpsc::channel(8);
    textamp::app::sources::radio::refill(&tx, &mut state, &client);
    let event = tokio::time::timeout(Duration::from_secs(3), rx.recv())
        .await
        .unwrap()
        .unwrap();
    handle_core_event(event, &mut state, &mut client, &tx);
    assert_eq!(keys(&state.radio.tracks), ["first", "next"]);
    assert!(state.radio.refill == textamp::app::state::RadioRefill::Idle);
    server.await.unwrap();
}

#[tokio::test]
async fn station_category_mouse_drill_loads_playable_choices_and_supports_back() {
    let listener = TcpListener::bind("127.0.0.1:0").await.unwrap();
    let mut client = PlexClient::new_with_url(
        &format!("http://{}", listener.local_addr().unwrap()),
        Some("test"),
        "test",
    )
    .unwrap();
    let server = tokio::spawn(async move {
        assert!(reply(
            &listener,
            r#"{"MediaContainer":{"Directory":[{"key":"42","title":"Happy"}]}}"#
        )
        .await
        .starts_with("GET /library/sections/5/mood HTTP"));
    });
    let mut state = AppState::new();
    state.view = View::Queue;
    state.stations = vec![station(
        "/library/sections/5/mood",
        "Mood Radio",
        "station.category",
    )];
    state.station_nav.columns.push(StationColumn::new(
        None,
        "Radio".into(),
        state.stations.clone(),
    ));
    state.playback_mode = PlaybackMode::Radio;
    state.radio.tracks = vec![track("still-playing")];
    state.radio.track_index = Some(0);
    command_palette::open_with_query(&mut state, "Mood Radio");
    let mut terminal = Terminal::new(TestBackend::new(120, 40)).unwrap();
    let mut feedback = None;
    terminal
        .draw(|frame| feedback = Some(textamp::ui::render(frame, &state)))
        .unwrap();
    state.apply_render_feedback(feedback.unwrap());
    let row = state.hit_regions.command_palette.as_ref().unwrap().rows[0].0;
    let actions = mouse_input::handle_mouse(
        MouseEvent {
            kind: MouseEventKind::Down(MouseButton::Left),
            column: row.x,
            row: row.y,
            modifiers: KeyModifiers::NONE,
        },
        &mut state,
    );
    assert!(matches!(
        actions.as_slice(),
        [Action::Radio(RadioAction::DrillIntoStation(_, _))]
    ));
    let mut audio = AudioPlayer::new_without_audio();
    let mut config = Config::default();
    let (tx, mut rx) = mpsc::channel(8);
    for action in actions {
        dispatch_action(
            action,
            &mut state,
            &mut client,
            &mut audio,
            &mut config,
            &tx,
        )
        .await
        .unwrap();
    }
    assert!(state.palette.open);
    let event = tokio::time::timeout(Duration::from_secs(3), rx.recv())
        .await
        .unwrap()
        .unwrap();
    handle_core_event(event, &mut state, &mut client, &tx);
    assert_eq!(state.current_track().unwrap().rating_key, "still-playing");
    assert!(state
        .palette
        .entries
        .iter()
        .any(|e| e.label == "Radio: Happy"));
    let choice = run_label(&mut state, "Radio: Happy");
    assert!(
        matches!(choice.as_slice(), [Action::Radio(RadioAction::PlayStation(key))] if key.contains("/stations/mood?id=42"))
    );
    let back = run_label(&mut state, "Radio: Back");
    for action in back {
        dispatch_action(
            action,
            &mut state,
            &mut client,
            &mut audio,
            &mut config,
            &tx,
        )
        .await
        .unwrap();
    }
    assert_eq!(state.station_nav.focused_column, 0);
    assert!(state
        .palette
        .entries
        .iter()
        .any(|e| e.label == "Radio: Mood Radio"));
    // The second drill uses the cache; no second HTTP request is available.
    let actions = run_label(&mut state, "Radio: Mood Radio");
    for action in actions {
        dispatch_action(
            action,
            &mut state,
            &mut client,
            &mut audio,
            &mut config,
            &tx,
        )
        .await
        .unwrap();
    }
    assert!(state
        .palette
        .entries
        .iter()
        .any(|e| e.label == "Radio: Happy"));
    assert!(matches!(
        command_palette::handle_key(&mut state, KeyEvent::new(KeyCode::Esc, KeyModifiers::NONE)),
        PaletteOutcome::Cancel
    ));
    server.await.unwrap();
}

#[test]
fn closing_the_palette_before_station_choices_arrive_does_not_reopen_it() {
    let mut state = AppState::new();
    command_palette::open_with_query(&mut state, "Radio");
    state.palette.close();
    let mut client = PlexClient::new(Default::default()).unwrap();
    let (tx, _) = mpsc::channel(8);
    handle_core_event(
        textamp::app::event::RadioEvent::StationChildrenLoaded {
            station_key: "/library/sections/5/mood".into(),
            station_title: "Mood Radio".into(),
            children: vec![station(
                "/library/sections/5/stations/mood?id=42",
                "Happy",
                "mood",
            )],
        }
        .into(),
        &mut state,
        &mut client,
        &tx,
    );
    assert!(!state.palette.open);
}

#[test]
fn filtered_station_choices_are_leaves_regardless_of_their_identifiers() {
    for kind in ["mood", "style", "decade"] {
        let mut choice = station(
            &format!("/library/sections/5/stations/{kind}?id=42&title=Choice"),
            "Choice",
            kind,
        );
        choice.identifier = Some(kind.into());
        assert!(!choice.is_category());
        let mut state = AppState::new();
        state.stations = vec![choice];
        assert!(matches!(
            run_label(&mut state, "Radio: Choice").as_slice(),
            [Action::Radio(RadioAction::PlayStation(_))]
        ));
    }
}
