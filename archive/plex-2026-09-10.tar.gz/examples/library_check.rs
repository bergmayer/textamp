//! Read-only Plex library discovery; --save updates Textamp's local directory.
use anyhow::Result;
use textamp::plex::library_directory;

#[tokio::main]
async fn main() -> Result<()> {
    let mut accounts = library_directory::load()?;
    for account in &mut accounts {
        let (updated, warnings) = library_directory::discover(account.clone()).await?;
        println!(
            "{}: {} music libraries",
            updated.name,
            updated.libraries.len()
        );
        for library in &updated.libraries {
            println!("  {} / {}", library.server_name, library.title);
        }
        for warning in warnings {
            eprintln!("{warning}");
        }
        *account = updated;
    }
    if std::env::args().any(|arg| arg == "--save") {
        library_directory::save(&accounts)?;
        println!("Saved local library directory; account selection unchanged.");
    }
    Ok(())
}
